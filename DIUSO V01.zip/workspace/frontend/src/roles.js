export function isStaff(user) {
  return user?.role === "admin" || user?.role === "master";
}

export function isMaster(user) {
  return user?.role === "master";
}
