import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../auth.jsx";
import { availabilityLabel, formatDate, formatMoneyInput, money, parseMoney, statusMeta } from "../visuals.js";

function formFrom(request) {
  return {
    title: request.title || "",
    category: request.category || "",
    city: request.city || "",
    neighborhood: request.neighborhood || "",
    street: request.street || "",
    streetNumber: request.streetNumber || "",
    owner: request.owner || "",
    ownerEmail: request.ownerEmail || "",
    ownerPhone: request.ownerPhone || "",
    description: request.description || "",
    specs: Array.isArray(request.specs) ? request.specs.join(", ") : (request.specs || ""),
    condition: request.condition || "",
    usageRules: request.usageRules || "",
    quantity: String(request.quantity || 1),
    pricePerDay: formatMoneyInput(Math.round(Number(request.pricePerDay || 0) * 100)),
    weeklyPrice: formatMoneyInput(Math.round(Number(request.weeklyPrice || 0) * 100)),
    monthlyPrice: formatMoneyInput(Math.round(Number(request.monthlyPrice || 0) * 100)),
    deposit: formatMoneyInput(Math.round(Number(request.deposit || 0) * 100)),
    estimatedValue: formatMoneyInput(Math.round(Number(request.estimatedValue || 0) * 100))
  };
}

function photosFrom(request) {
  return (request.photos || []).map((photo, index) => ({
    key: photo.filename || `saved-${index}`,
    filename: photo.filename || "",
    url: photo.url || (photo.filename ? `/uploads/listings/${photo.filename}` : ""),
    file: null
  }));
}

export default function Owner() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [categories, setCategories] = useState([]);
  const [cities, setCities] = useState([]);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(null);
  const [photos, setPhotos] = useState([]);
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [sending, setSending] = useState(false);
  const [itemRemove, setItemRemove] = useState(null);
  const [itemRemovePassword, setItemRemovePassword] = useState("");
  const [itemRemoveError, setItemRemoveError] = useState("");
  const gallery = useRef(null);

  function load() {
    return api.ownerDashboard().then(setData);
  }

  useEffect(() => {
    if (!user) return;
    load().catch(console.error);
    api.categories().then(setCategories).catch(console.error);
    api.cities().then((res) => setCities(res.active || [])).catch(console.error);
  }, [user]);

  function openEdit(request) {
    photos.forEach((photo) => {
      if (photo.url?.startsWith("blob:")) URL.revokeObjectURL(photo.url);
    });
    setEditing(request);
    setForm(formFrom(request));
    setPhotos(photosFrom(request));
    setError("");
    setOk("");
  }

  function closeEdit() {
    photos.forEach((photo) => {
      if (photo.url?.startsWith("blob:")) URL.revokeObjectURL(photo.url);
    });
    setEditing(null);
    setForm(null);
    setPhotos([]);
    setError("");
    setSending(false);
  }

  function setField(key, value) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function addPhotos(fileList) {
    const incoming = Array.from(fileList || []).filter((file) => file.type.startsWith("image/"));
    if (!incoming.length) return;
    setPhotos((prev) => [
      ...prev,
      ...incoming.map((file) => ({
        key: `new-${file.name}-${file.lastModified}-${Math.random().toString(16).slice(2)}`,
        filename: "",
        url: URL.createObjectURL(file),
        file
      }))
    ].slice(0, 12));
  }

  function movePhoto(index, dir) {
    setPhotos((prev) => {
      const next = [...prev];
      const target = index + dir;
      if (target < 0 || target >= next.length) return prev;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  function removePhoto(index) {
    setPhotos((prev) => {
      const photo = prev[index];
      if (photo?.url?.startsWith("blob:")) URL.revokeObjectURL(photo.url);
      return prev.filter((_, i) => i !== index);
    });
  }

  function payload() {
    let newIndex = 0;
    const photoOrder = photos.map((photo) => {
      if (photo.file) {
        const token = `new:${newIndex}`;
        newIndex += 1;
        return token;
      }
      return photo.filename;
    });
    return {
      ...form,
      pricePerDay: String(parseMoney(form.pricePerDay) || ""),
      weeklyPrice: String(parseMoney(form.weeklyPrice) || 0),
      monthlyPrice: String(parseMoney(form.monthlyPrice) || 0),
      deposit: String(parseMoney(form.deposit) || 0),
      estimatedValue: String(parseMoney(form.estimatedValue) || 0),
      photoOrder,
      photos: photos.map((photo) => photo.file).filter(Boolean)
    };
  }

  async function resubmit() {
    if (!form?.title?.trim()) return setError("Informe o nome do item.");
    if (!form.category) return setError("Selecione a categoria.");
    if (!form.description?.trim() || !form.specs?.trim()) return setError("Preencha descricao e destaques.");
    if (!(parseMoney(form.pricePerDay) > 0)) return setError("Informe o preço por dia.");
    if (!form.quantity || Number(form.quantity) <= 0) return setError("Informe a quantidade.");
    if (!form.condition) return setError("Informe a condicao.");
    if (!form.city?.trim() || !form.neighborhood?.trim() || !form.street?.trim() || !form.streetNumber?.trim()) {
      return setError("Informe município, bairro, logradouro e número.");
    }
    if (!form.usageRules?.trim()) return setError("Informe as regras de utilizacao.");
    if (!(parseMoney(form.deposit) >= 0) || !(parseMoney(form.estimatedValue) > 0)) {
      return setError("Informe caução e valor estimado.");
    }
    if (photos.length < 6) return setError("O anúncio precisa de no mínimo 6 fotos.");
    setSending(true);
    setError("");
    try {
      await api.resubmitListing(editing.id, payload());
      setOk("Anúncio reenviado para análise.");
      closeEdit();
      await load();
    } catch (err) {
      setError(err.message);
      setSending(false);
    }
  }

  if (!user) {
    return (
      <div className="shell" style={{ padding: "32px 0 50px" }}>
        <h1>Painel do proprietário</h1>
        <p>Entre para ver receita, itens e locações.</p>
        <Link className="btn green" to="/entrar?next=/proprietario">Entrar</Link>
      </div>
    );
  }

  const requests = data?.listingRequests || [];
  const published = (data?.items || []).filter((item) => item.listingStatus !== "excluido");

  return (
    <div className="shell" style={{ padding: "32px 0 50px" }}>
      <h1>Minha receita</h1>
      {ok && <div className="ok">{ok}</div>}
      {data && (
        <>
          <div className="dash">
            <div className="dash-card"><span>Receita bruta</span><strong>{money(data.gross)}</strong></div>
            <div className="dash-card"><span>Comissão Diuso</span><strong>-{money(data.commission)}</strong></div>
            <div className="dash-card"><span>Receita líquida</span><strong>{money(data.net)}</strong></div>
            <div className="dash-card"><span>Disponível para saque</span><strong>{money(data.available)}</strong></div>
            <div className="dash-card"><span>Em processamento</span><strong>{money(data.processing)}</strong></div>
            <div className="dash-card"><span>Retido por locação</span><strong>{money(data.held)}</strong></div>
            <div className="dash-card"><span>Locações</span><strong>{data.rentals}</strong></div>
            <div className="dash-card"><span>Itens ativos</span><strong>{data.activeItems}</strong></div>
            <div className="dash-card"><span>Itens alugados</span><strong>{data.rentedItems}</strong></div>
            <div className="dash-card"><span>Cancelamentos</span><strong>{data.cancellations}</strong></div>
            <div className="dash-card"><span>Ocorrências</span><strong>{data.incidents}</strong></div>
          </div>

          <section className="section">
            <div className="section-head">
              <h2>Meus anúncios</h2>
              <Link className="btn green" to="/anunciar">Novo anúncio</Link>
            </div>
            {requests.length === 0 && published.length === 0 && (
              <div className="panel empty-state">
                <strong>Nenhum anúncio enviado ainda.</strong>
                <p>Quando você cadastrar um item, o pedido aparece aqui até a análise da DIUSO.</p>
              </div>
            )}
            {published.length > 0 && (
              <div style={{ display: "grid", gap: 12, marginBottom: 16 }}>
                {published.map((item) => {
                  const paused = item.listingStatus === "pausado";
                  const cover = item.photos?.[0]?.url;
                  return (
                    <article className="panel" key={item.id}>
                      <div className="listing-preview">
                        {cover ? <img src={cover} alt="" /> : <div className="listing-review-empty">Sem capa</div>}
                        <div>
                          <strong>{item.title}</strong>
                          <p>{item.city} · {item.neighborhood} · {money(item.pricePerDay)}/dia</p>
                          <div className="status-cell" style={{ marginTop: 8 }}>
                            <span className={`status ${paused ? "warn" : "ok"}`}>
                              {paused ? "Pausado" : (availabilityLabel[item.availability] || "Publicado")}
                            </span>
                          </div>
                          {paused && (
                            <p style={{ marginTop: 8, color: "var(--muted)" }}>
                              Novas reservas estão bloqueadas. Locações já feitas seguem ativas até a devolução.
                            </p>
                          )}
                          <div className="menu-form-actions" style={{ marginTop: 12 }}>
                            {paused ? (
                              <button
                                type="button"
                                className="btn green"
                                onClick={async () => {
                                  await api.resumeListing(item.id);
                                  setOk(`Anúncio “${item.title}” reativado.`);
                                  await load();
                                }}
                              >
                                Reativar
                              </button>
                            ) : (
                              <button
                                type="button"
                                className="btn ghost-btn"
                                onClick={async () => {
                                  const res = await api.pauseListing(item.id);
                                  setOk(res.message || `Anúncio “${item.title}” pausado.`);
                                  await load();
                                }}
                              >
                                Pausar
                              </button>
                            )}
                            <button
                              type="button"
                              className="ghost"
                              onClick={() => {
                                setItemRemove(item);
                                setItemRemovePassword("");
                                setItemRemoveError("");
                              }}
                            >
                              Excluir
                            </button>
                          </div>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
            <div style={{ display: "grid", gap: 12 }}>
              {requests.map((request) => {
                const meta = statusMeta[request.status] || statusMeta.aguardando_analise;
                const cover = request.photos?.[0]?.url;
                return (
                  <article className="panel" key={request.id}>
                    <div className="listing-preview">
                      {cover ? <img src={cover} alt="" /> : <div className="listing-review-empty">Sem capa</div>}
                      <div>
                        <strong>{request.title}</strong>
                        <p>{[request.street, request.streetNumber].filter(Boolean).join(", ")} · {request.neighborhood} · {request.city} · {money(request.pricePerDay)}/dia</p>
                        <div className="status-cell" style={{ marginTop: 8 }}>
                          <span className={`status ${meta.tone}`}>{meta.label}</span>
                        </div>
                        {request.status === "rejeitado" && request.rejectionComment && (
                          <p style={{ marginTop: 10 }}><strong>O que precisa alterar:</strong> {request.rejectionComment}</p>
                        )}
                        {request.status === "rejeitado" && (
                          <button type="button" className="btn green" style={{ marginTop: 12 }} onClick={() => openEdit(request)}>
                            Corrigir e reenviar
                          </button>
                        )}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          </section>

          <section className="section">
            <div className="section-head"><h2>Locações dos meus itens</h2></div>
            <div className="panel" style={{ overflowX: "auto" }}>
              <table className="table">
                <thead>
                  <tr><th>Item</th><th>Período</th><th>Líquido</th><th>Status</th></tr>
                </thead>
                <tbody>
                  {(data.bookings || []).map((b) => {
                    const meta = statusMeta[b.status] || statusMeta.aguardando_confirmacao;
                    return (
                      <tr key={b.id}>
                        <td><Link to={`/locação/${b.id}`}>{b.item?.title || b.itemId}</Link></td>
                        <td>{formatDate(b.startDate)} — {formatDate(b.endDate)}</td>
                        <td>{money(b.ownerPayout)}</td>
                        <td>
                          <div className="status-cell">
                            <span className={`status ${meta.tone}`}>{meta.label}</span>
                            {b.status === "atrasado" && b.lateReason && <span className="status-desc">{b.lateReason}</span>}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}

      {editing && form && (
        <div className="late-dialog-backdrop" onClick={closeEdit}>
          <div className="late-dialog listing-review-dialog" onClick={(e) => e.stopPropagation()}>
            <div className="listing-review-head">
              <div>
                <h2>Corrigir anúncio</h2>
                <p style={{ color: "var(--muted)", margin: "4px 0 0" }}>Ajuste o que foi pedido e reenvie para análise.</p>
              </div>
              <button type="button" className="ghost" onClick={closeEdit}>Fechar</button>
            </div>
            {editing.rejectionComment && (
              <div className="alert" style={{ marginTop: 12 }}>{editing.rejectionComment}</div>
            )}
            {error && <div className="alert" style={{ marginTop: 12 }}>{error}</div>}

            <div className="field" style={{ marginTop: 16 }}>
              <label>Fotos (mínimo 6). A primeira é a capa.</label>
              <input ref={gallery} type="file" accept="image/*" multiple hidden onChange={(e) => { addPhotos(e.target.files); e.target.value = ""; }} />
              <div className="photo-actions">
                <button className="btn ghost-btn" type="button" onClick={() => gallery.current?.click()}>Adicionar fotos</button>
                <p className={`photo-hint ${photos.length >= 6 ? "ok-text" : ""}`} style={{ margin: 0 }}>{photos.length} de 6 fotos</p>
              </div>
              {photos.length > 0 && (
                <div className="photo-grid photo-grid-edit">
                  {photos.map((photo, index) => (
                    <figure key={photo.key} className="photo-tile">
                      <img src={photo.url} alt={`Foto ${index + 1}`} />
                      <span className="photo-order">{index === 0 ? "Capa" : index + 1}</span>
                      <div className="photo-tile-actions">
                        <button type="button" disabled={index === 0} onClick={() => movePhoto(index, -1)}>‹</button>
                        <button type="button" disabled={index === photos.length - 1} onClick={() => movePhoto(index, 1)}>›</button>
                        <button type="button" onClick={() => removePhoto(index)}>×</button>
                      </div>
                    </figure>
                  ))}
                </div>
              )}
            </div>

            <div className="form-grid" style={{ marginTop: 16 }}>
              <div className="field" style={{ gridColumn: "1 / -1" }}>
                <label>Nome do produto</label>
                <input value={form.title} onChange={(e) => setField("title", e.target.value)} />
              </div>
              <div className="field">
                <label>Categoria</label>
                <select value={form.category} onChange={(e) => setField("category", e.target.value)}>
                  <option value="">Selecione</option>
                  {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="field">
                <label>Condição</label>
                <select value={form.condition} onChange={(e) => setField("condition", e.target.value)}>
                  <option value="">Selecione</option>
                  <option>Como novo</option>
                  <option>Excelente</option>
                  <option>Muito bom</option>
                  <option>Bom</option>
                </select>
              </div>
              <div className="field">
                <label>Quantidade</label>
                <input type="number" min="1" value={form.quantity} onChange={(e) => setField("quantity", e.target.value)} />
              </div>
              <div className="field">
                <label>Município</label>
                <select value={form.city} onChange={(e) => setField("city", e.target.value)}>
                  <option value="">Selecione</option>
                  {cities.map((city) => <option key={city} value={city}>{city}</option>)}
                  {form.city && !cities.includes(form.city) && <option value={form.city}>{form.city}</option>}
                </select>
              </div>
              <div className="field">
                <label>Bairro</label>
                <input value={form.neighborhood} onChange={(e) => setField("neighborhood", e.target.value)} />
              </div>
              <div className="field">
                <label>Logradouro (Rua/Avenida)</label>
                <input value={form.street} onChange={(e) => setField("street", e.target.value)} />
              </div>
              <div className="field">
                <label>Número</label>
                <input value={form.streetNumber} onChange={(e) => setField("streetNumber", e.target.value)} />
              </div>
              <div className="field">
                <label>Diária (R$)</label>
                <input inputMode="numeric" value={form.pricePerDay} onChange={(e) => setField("pricePerDay", formatMoneyInput(e.target.value))} />
              </div>
              <div className="field">
                <label>Semanal (R$)</label>
                <input inputMode="numeric" value={form.weeklyPrice} onChange={(e) => setField("weeklyPrice", formatMoneyInput(e.target.value))} />
              </div>
              <div className="field">
                <label>Mensal (R$)</label>
                <input inputMode="numeric" value={form.monthlyPrice} onChange={(e) => setField("monthlyPrice", formatMoneyInput(e.target.value))} />
              </div>
              <div className="field">
                <label>Caução (R$)</label>
                <input inputMode="numeric" value={form.deposit} onChange={(e) => setField("deposit", formatMoneyInput(e.target.value))} />
              </div>
              <div className="field">
                <label>Valor estimado (R$)</label>
                <input inputMode="numeric" value={form.estimatedValue} onChange={(e) => setField("estimatedValue", formatMoneyInput(e.target.value))} />
              </div>
              <div className="field" style={{ gridColumn: "1 / -1" }}>
                <label>Destaques</label>
                <input value={form.specs} onChange={(e) => setField("specs", e.target.value)} />
              </div>
              <div className="field" style={{ gridColumn: "1 / -1" }}>
                <label>Descrição</label>
                <textarea rows="3" value={form.description} onChange={(e) => setField("description", e.target.value)} />
              </div>
              <div className="field" style={{ gridColumn: "1 / -1" }}>
                <label>Regras de utilização</label>
                <textarea rows="3" value={form.usageRules} onChange={(e) => setField("usageRules", e.target.value)} />
              </div>
            </div>

            <div className="late-dialog-actions">
              <button type="button" className="ghost" onClick={closeEdit}>Cancelar</button>
              <button type="button" className="btn green" disabled={sending} onClick={resubmit}>
                {sending ? "Reenviando..." : "Reenviar para análise"}
              </button>
            </div>
          </div>
        </div>
      )}
      {itemRemove && (
        <div className="late-dialog-backdrop" onClick={() => setItemRemove(null)}>
          <div className="late-dialog" onClick={(e) => e.stopPropagation()}>
            <h2>Excluir anúncio</h2>
            <p style={{ color: "var(--muted)", margin: "8px 0 12px" }}>
              Excluir “{itemRemove.title}” do catálogo. Informe a senha da sua conta. Reservas já feitas continuam no perfil do locatário até a devolução. Estorno, se necessário, só o administrador pode fazer.
            </p>
            <input type="password" value={itemRemovePassword} onChange={(e) => setItemRemovePassword(e.target.value)} placeholder="Senha da conta" autoFocus />
            {itemRemoveError && <div className="alert" style={{ marginTop: 10 }}>{itemRemoveError}</div>}
            <div className="late-dialog-actions">
              <button type="button" className="ghost" onClick={() => setItemRemove(null)}>Cancelar</button>
              <button
                type="button"
                className="btn green"
                onClick={async () => {
                  const password = itemRemovePassword.trim();
                  if (!password) {
                    setItemRemoveError("Informe a senha da conta.");
                    return;
                  }
                  try {
                    const res = await api.removeListing(itemRemove.id, { password });
                    setOk(res.message || `Anúncio “${itemRemove.title}” excluído.`);
                    setItemRemove(null);
                    setItemRemovePassword("");
                    setItemRemoveError("");
                    await load();
                  } catch (err) {
                    setItemRemoveError(err.message);
                  }
                }}
              >
                Excluir anúncio
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
