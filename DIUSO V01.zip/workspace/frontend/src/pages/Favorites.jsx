import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import { money, palettes } from "../visuals.js";

export default function Favorites() {
  const [items, setItems] = useState([]);

  async function load() {
    setItems(await api.favorites());
  }

  useEffect(() => { load().catch(console.error); }, []);

  async function remove(id) {
    await api.removeFavorite(id);
    await load();
  }

  return (
    <div className="shell" style={{ padding: "32px 0 50px" }}>
      <h1>Favoritos</h1>
      <p style={{ color: "var(--muted)" }}>Itens que você quer usar depois. Sem comprar.</p>
      {items.length === 0 && (
        <div className="panel" style={{ marginTop: 18 }}>
          <p>Nenhum favorito ainda. Explore a DIUSO e salve o que quiser usar.</p>
          <Link to="/" className="btn green">Encontrar o que preciso</Link>
        </div>
      )}
      <div className="grid" style={{ marginTop: 18 }}>
        {items.map((item) => {
          const [a, b] = palettes[item.category] || ["#0f766e", "#134e4a"];
          return (
            <article className="card" key={item.id}>
              <Link to={`/item/${item.id}`}>
                <div className="thumb" style={{ background: `linear-gradient(135deg, ${a}, ${b})` }}>
                  <span>{item.city} · {item.neighborhood}</span>
                  {item.title.split(" ").slice(0, 2).join(" ")}
                </div>
              </Link>
              <div className="card-body">
                <strong>{item.title}</strong>
                <div className="meta">
                  <span>{item.rating} · {item.reviewCount || item.reviews || 0} avaliações</span>
                  <span>{item.city}{item.neighborhood ? ` · ${item.neighborhood}` : ""}</span>
                </div>
                <div className="price">{money(item.pricePerDay)} <small>/dia</small></div>
                <div className="card-actions">
                  <button className="ghost" onClick={() => remove(item.id)}>Remover</button>
                  <Link to={`/item/${item.id}`} className="btn green">Ver detalhes</Link>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
