import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { api } from "../api.js";

export default function ResetPassword() {
  const [params] = useSearchParams();
  const token = params.get("token") || "";
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [ready, setReady] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!token) {
      setError("Link inválido. Peça um novo em Esqueci a senha.");
      return;
    }
    api.resetPasswordInfo(token)
      .then((data) => {
        setEmail(data.email);
        setReady(true);
      })
      .catch((err) => setError(err.message));
  }, [token]);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setOk("");
    if (password.length < 6) {
      setError("A senha precisa ter no mínimo 6 caracteres.");
      return;
    }
    if (password !== confirm) {
      setError("A confirmação não confere com a nova senha.");
      return;
    }
    setSaving(true);
    try {
      await api.resetPassword({ token, newPassword: password });
      setOk("Senha redefinida. Entre com a nova senha.");
      setTimeout(() => navigate("/entrar"), 900);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="shell" style={{ padding: "32px 0 50px", maxWidth: 520 }}>
      <h1>Redefinir senha</h1>
      <p style={{ color: "var(--muted)" }}>
        {email ? `Conta ${email}.` : "Crie uma nova senha para locador ou locatário."}
      </p>
      <form className="panel" style={{ marginTop: 18 }} onSubmit={submit}>
        {error && <div className="alert">{error}</div>}
        {ok && <div className="ok">{ok}</div>}
        <div className="field">
          <label>Nova senha</label>
          <input type="password" minLength="6" value={password} onChange={(e) => setPassword(e.target.value)} required disabled={!ready} />
        </div>
        <div className="field">
          <label>Confirmar nova senha</label>
          <input type="password" minLength="6" value={confirm} onChange={(e) => setConfirm(e.target.value)} required disabled={!ready} />
        </div>
        <button className="btn green wide" type="submit" disabled={!ready || saving}>
          {saving ? "Salvando..." : "Salvar nova senha"}
        </button>
        <p style={{ color: "var(--muted)", marginTop: 12 }}>
          <Link to="/esqueci-a-senha">Pedir outro link</Link>
        </p>
      </form>
    </div>
  );
}
