import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../auth.jsx";
import { isStaff } from "../roles.js";

export default function ForcePassword() {
  const { user, setUser, logout } = useAuth();
  const navigate = useNavigate();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    if (newPassword.length < 6) {
      setError("A senha precisa ter no mínimo 6 caracteres.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("A confirmação não confere com a nova senha.");
      return;
    }
    if (currentPassword === newPassword) {
      setError("A nova senha precisa ser diferente da atual.");
      return;
    }
    setSaving(true);
    try {
      const data = await api.changePassword({ currentPassword, newPassword });
      if (data.user) setUser(data.user);
      else setUser({ ...user, mustChangePassword: false });
      const next = sessionStorage.getItem("diuso_next");
      sessionStorage.removeItem("diuso_next");
      navigate(next || (isStaff(user) ? "/admin" : "/conta"));
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="shell" style={{ padding: "32px 0 50px", maxWidth: 520 }}>
      <h1>Crie uma nova senha</h1>
      <p style={{ color: "var(--muted)" }}>
        No primeiro acesso, ou depois de um reset, você precisa criar uma senha própria para continuar.
      </p>
      <form className="panel" style={{ marginTop: 18 }} onSubmit={submit}>
        {error && <div className="alert">{error}</div>}
        <div className="field">
          <label>Senha atual</label>
          <input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required autoFocus />
        </div>
        <div className="field">
          <label>Nova senha</label>
          <input type="password" minLength="6" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
        </div>
        <div className="field">
          <label>Confirmar nova senha</label>
          <input type="password" minLength="6" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
        </div>
        <button className="btn green wide" type="submit" disabled={saving}>
          {saving ? "Salvando..." : "Salvar nova senha"}
        </button>
        <p style={{ color: "var(--muted)", marginTop: 12 }}>
          <button type="button" className="ghost" onClick={async () => { await logout(); navigate("/entrar"); }}>Sair</button>
        </p>
      </form>
    </div>
  );
}
