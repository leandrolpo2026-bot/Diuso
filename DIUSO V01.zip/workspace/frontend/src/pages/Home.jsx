import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import { money, palettes } from "../visuals.js";
import { IconBox, IconCalendar, IconExplore, IconGear, IconHouse, IconParty, IconReturn, IconSpeaker, IconWrench } from "../icons.jsx";

const quickCats = [
  { id: "ferramentas", name: "Ferramentas", Icon: IconWrench },
  { id: "festas", name: "Festas e eventos", Icon: IconParty },
  { id: "casa", name: "Casa", Icon: IconHouse },
  { id: "eletrônicos", name: "Eletrônicos", Icon: IconSpeaker },
  { id: "construção", name: "Equipamentos", Icon: IconGear },
  { id: "todos", name: "Ver tudo", Icon: IconBox }
];

const searchHints = ["Furadeira", "Caixa de som", "Máquina de lavar", "Geladeira", "Projetor", "Equipamentos para festa"];

const simpleSteps = [
  { n: "01", title: "Encontre", text: "Procure o que você precisa.", Icon: IconExplore },
  { n: "02", title: "Alugue", text: "Escolha o item e o período.", Icon: IconCalendar },
  { n: "03", title: "Use", text: "Receba ou retire o produto.", Icon: IconHouse },
  { n: "04", title: "Devolva", text: "Terminou? Devolva e pronto.", Icon: IconReturn }
];

const showcaseCats = [
  { id: "festas", name: "Festas e Eventos", mark: "FT" },
  { id: "eletrônicos", name: "Som e Eletrônicos", mark: "SE" },
  { id: "ferramentas", name: "Ferramentas", mark: "FR" },
  { id: "casa", name: "Casa", mark: "CA" },
  { id: "automotivo", name: "Automotivo", mark: "AU" },
  { id: "esportes", name: "Esportes e Lazer", mark: "EL" },
  { id: "cameras", name: "Foto e Vídeo", mark: "FV" },
  { id: "construção", name: "Construção", mark: "CO" },
  { id: "móveis", name: "Móveis", mark: "MO" },
  { id: "outros", name: "Outros", mark: "OU" }
];

const journey = [
  { n: "01", title: "Encontre", text: "Escolha o que precisa." },
  { n: "02", title: "Solicite", text: "Informe quando precisa e por quanto tempo." },
  { n: "03", title: "Confirme", text: "Locador e locatário são identificados." },
  { n: "04", title: "Pague", text: "Pagamento e caução ficam registrados." },
  { n: "05", title: "Receba", text: "Combine retirada ou entrega." },
  { n: "06", title: "Devolva", text: "Finalize a locação e avalie a experiência." }
];

const trustCards = [
  { title: "Identidade verificada", text: "Cadastro com documento para alugar." },
  { title: "Contrato digital", text: "Aceite registrado na reserva." },
  { title: "Pagamento registrado", text: "Comprovante anexado na locação. Gateway em breve." },
  { title: "Caução quando necessario", text: "Valor temporario, devolvido apos a inspecao." },
  { title: "Registro da entrega", text: "Status acompanhado ate a devolução." },
  { title: "Avaliação dos usuários", text: "Apos locações finalizadas." },
  { title: "Histórico de locações", text: "Pedidos, status e comprovantes na conta." },
  { title: "Comunicação organizada", text: "Em breve: mensagens dentro da plataforma." }
];

function itemPhoto(item) {
  const first = item.photos?.[0];
  if (!first) return item.image || "";
  return first.url || first;
}

function ItemCard({ item }) {
  const [a, b] = palettes[item.category] || ["#0f766e", "#134e4a"];
  const photo = itemPhoto(item);
  return (
    <article className="card">
      <Link to={`/item/${item.id}`}>
        <div className="thumb" style={{ background: `linear-gradient(135deg, ${a}, ${b})` }}>
          {photo ? <img src={photo} alt={item.title} /> : item.title.split(" ").slice(0, 2).join(" ")}
          <span>{item.city}{item.neighborhood ? ` · ${item.neighborhood}` : ""}</span>
          {item.protectionLabel && <em className="protect-tag">{item.protectionLabel}</em>}
        </div>
      </Link>
      <div className="card-body">
        <strong>{item.title}</strong>
        <div className="meta">
          <span>{item.city}{item.neighborhood ? ` · ${item.neighborhood}` : ""}</span>
        </div>
        <div className="price">{money(item.pricePerDay)} <small>/dia</small></div>
        <div className="card-actions">
          <span style={{ color: "var(--muted)", fontSize: 12 }}>{item.city}</span>
          <Link to={`/item/${item.id}`} className="btn green">Alugar</Link>
        </div>
      </div>
    </article>
  );
}

export default function Home() {
  const [q, setQ] = useState("");
  const [location, setLocation] = useState("");
  const [category, setCategory] = useState("todos");
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [stats, setStats] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function load(overrides = {}) {
    const nextCategory = overrides.category ?? category;
    const nextQ = overrides.q ?? q;
    const nextLocation = overrides.location ?? location;
    setError("");
    setLoading(true);
    try {
      const [list, cats, st, revs] = await Promise.all([
        api.items({ q: nextQ, category: nextCategory, location: nextLocation }),
        api.categories(),
        api.stats(),
        api.reviews().catch(() => [])
      ]);
      setItems(list);
      setCategories(cats);
      setStats(st);
      setReviews(revs || []);
    } catch (err) {
      setError(err.message || "Não foi possível carregar o catálogo.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load().catch(console.error); }, []);

  useEffect(() => {
    function goHash() {
      const id = String(window.location.hash || "").replace("#", "");
      if (!id) return;
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    if (!loading) goHash();
    window.addEventListener("hashchange", goHash);
    return () => window.removeEventListener("hashchange", goHash);
  }, [loading]);

  const catMap = useMemo(() => Object.fromEntries((categories || []).map((c) => [c.id, c])), [categories]);

  function scrollToItems() {
    const el = document.getElementById("disponiveis");
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function setCat(next) {
    setCategory(next);
    load({ category: next }).catch(console.error);
    scrollToItems();
  }

  function search(e) {
    e.preventDefault();
    load({ q }).catch(console.error);
    scrollToItems();
  }

  function searchHint(term) {
    setQ(term);
    load({ q: term }).catch(console.error);
    scrollToItems();
  }

  return (
    <div className="shell">
      <section className="hero hero-entry">
        <div className="hero-copy">
          <h1>Alugue o que você precisa.</h1>
          <p className="subhead">
            Encontre ferramentas, equipamentos, eletrodomésticos, itens para festas e muito mais para alugar perto de você.
          </p>
          <form id="buscar" className="searchbar searchbar-hero searchbar-main" onSubmit={search}>
            <input
              placeholder="O que você precisa?"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              aria-label="O que você precisa?"
            />
            <button className="btn green" type="submit">Buscar</button>
          </form>
          <p className="search-examples">
            {searchHints.map((hint) => (
              <button key={hint} type="button" className="search-hint" onClick={() => searchHint(hint)}>
                {hint}
              </button>
            ))}
          </p>
          <div className="quick-cats" id="categorias">
            {quickCats.map((c) => (
              <button
                key={c.id}
                type="button"
                className={`quick-cat ${category === c.id ? "on" : ""}`}
                onClick={() => setCat(c.id)}
              >
                <c.Icon />
                <span>{c.name}</span>
              </button>
            ))}
          </div>
          <p className="microcopy">Precisou? Alugou. Usou? Devolveu.</p>
        </div>
      </section>

      <section className="section" id="como-funciona-rapido">
        <div className="section-head">
          <div>
            <h2>É simples assim.</h2>
            <p className="section-lead">Quatro passos para usar o que precisa, sem comprar.</p>
          </div>
        </div>
        <div className="simple-steps">
          {simpleSteps.map((step) => (
            <article className="simple-step" key={step.n}>
              <div className="simple-step-icon"><step.Icon /></div>
              <span className="simple-step-n">{step.n}</span>
              <strong>{step.title}</strong>
              <p>{step.text}</p>
            </article>
          ))}
        </div>
        <p className="brand-sign">DIUSO — Você precisa. A gente resolve.</p>
        {stats && (
          <div className="stats stats-inline">
            <div className="stat"><b>{stats.items}</b><span>itens para alugar</span></div>
            <div className="stat"><b>{stats.activeBookings}</b><span>locações ativas</span></div>
            <div className="stat"><b>{money(stats.avgPrice)}</b><span>a partir de /dia</span></div>
          </div>
        )}
      </section>

      <section className="section" id="disponiveis">
        <div className="section-head">
          <div>
            <h2>Disponível para alugar</h2>
            <p className="section-lead">Itens reais, perto de você. Escolha, alugue e devolva.</p>
          </div>
          <span style={{ color: "var(--muted)" }}>{items.length} resultados</span>
        </div>
        <div className="chips">
          <button className={`chip ${category === "todos" ? "on" : ""}`} onClick={() => setCat("todos")}>Todas</button>
          {categories.filter((c) => c.featured).map((c) => (
            <button
              key={c.id}
              className={`chip ${category === c.id ? "on" : ""}`}
              onClick={() => setCat(c.id)}
            >
              {c.name} ({c.count})
            </button>
          ))}
        </div>
        {error && <div className="alert">{error}</div>}
        {loading && <div className="panel empty-state">Carregando itens...</div>}
        {!loading && items.length === 0 && (
          <div className="panel empty-state">
            <strong>Nenhum resultado agora.</strong>
            <p>Tente outro termo, outra cidade ou veja todas as categorias.</p>
            <button className="btn green" type="button" onClick={() => { setQ(""); setLocation(""); setCat("todos"); }}>Ver tudo</button>
          </div>
        )}
        <div className="grid">
          {items.map((item) => <ItemCard key={item.id} item={item} />)}
        </div>
      </section>

      <section className="section" id="categorias-todas">
        <div className="section-head">
          <div>
            <h2>O que você pode alugar?</h2>
            <p className="section-lead">Use quando precisar. Devolva quando terminar.</p>
          </div>
          <a className="ghost" href="#disponiveis">Ver tudo</a>
        </div>
        <div className="cat-grid">
          {showcaseCats.map((c) => {
            const [a, b] = palettes[c.id] || ["#0f766e", "#134e4a"];
            const count = catMap[c.id]?.count || 0;
            return (
              <button
                key={c.id}
                type="button"
                className={`cat-card ${category === c.id ? "on" : ""}`}
                onClick={() => setCat(c.id)}
              >
                <span className="cat-mark" style={{ background: `linear-gradient(135deg, ${a}, ${b})` }}>{c.mark}</span>
                <strong>{c.name}</strong>
                <span>{count} {count === 1 ? "item" : "itens"}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="section" id="renda">
        <div className="panel owner-cta owner-cta-strong">
          <h2>Tem algo parado? Faça isso virar renda.</h2>
          <p>
            Aquela caixa de som que você usa duas vezes por ano. A furadeira que fica meses guardada. As mesas da sua festa. A máquina que está parada.
          </p>
          <p>Na Diuso, você pode colocar seus objetos para trabalhar por você.</p>
          <div className="owner-points">
            <span>Você define o preço.</span>
            <span>Você escolhe quando disponibilizar.</span>
            <span>Você decide para quem alugar.</span>
            <span>Você acompanha suas locações.</span>
          </div>
          <Link className="btn green" to="/anunciar">Começar a alugar</Link>
        </div>
      </section>

      <section className="section" id="como-funciona">
        <div className="section-head">
          <div>
            <h2>Do anúncio a devolução. Tudo organizado.</h2>
            <p className="section-lead">Uma infraestrutura para a locação, não um classificado.</p>
          </div>
        </div>
        <div className="journey">
          {journey.map((step, index) => (
            <div className="journey-step" key={step.n}>
              <div className="journey-node">{step.n}</div>
              {index < journey.length - 1 && <span className="journey-line" aria-hidden="true" />}
              <strong>{step.title}</strong>
              <p>{step.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <h2>Alugue com mais segurança.</h2>
        </div>
        <div className="trust-grid">
          {trustCards.map((card) => (
            <article className="trust-card" key={card.title}>
              <strong>{card.title}</strong>
              <p>{card.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <h2>Alugar não deveria ser uma confusão.</h2>
        </div>
        <div className="compare">
          <div className="compare-col">
            <h3>Antes</h3>
            <ul>
              <li>Mensagens perdidas em conversas soltas</li>
              <li>Não sabe se o produto está disponível</li>
              <li>Negociação espalhada</li>
              <li>Sem histórico</li>
              <li>Sem contrato organizado</li>
              <li>Difícil controlar datas e caução</li>
              <li>Difícil saber com quem está alugando</li>
            </ul>
          </div>
          <div className="compare-col on">
            <h3>Com a Diuso</h3>
            <ul>
              <li>Produto organizado</li>
              <li>Informações centralizadas</li>
              <li>Datas controladas</li>
              <li>Usuários identificados</li>
              <li>Histórico</li>
              <li>Avaliações</li>
              <li>Processo mais organizado</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="section how-split">
        <div className="panel">
          <h2>Precisa de alguma coisa?</h2>
          <ol className="how-list">
            <li>Pesquise</li>
            <li>Escolha</li>
            <li>Informe o período</li>
            <li>Solicite</li>
            <li>Combine a retirada ou entrega</li>
            <li>Use</li>
            <li>Devolva</li>
          </ol>
          <a className="btn green" href="#disponiveis">Encontrar o que preciso</a>
        </div>
        <div className="panel">
          <h2>Quer transformar objetos parados em renda?</h2>
          <ol className="how-list">
            <li>Cadastre seu objeto</li>
            <li>Defina preço e disponibilidade</li>
            <li>Receba solicitações</li>
            <li>Confirme a locação</li>
            <li>Entregue ou combine retirada</li>
            <li>Receba</li>
            <li>Avalie</li>
          </ol>
          <Link className="btn green" to="/anunciar">Quero anunciar</Link>
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <div>
            <h2>Quem usa, conta.</h2>
            <p className="section-lead">Avaliações reais de locações finalizadas.</p>
          </div>
        </div>
        {reviews.length === 0 ? (
          <div className="panel empty-state">
            <strong>Ainda não há avaliações públicas.</strong>
            <p>Quando as primeiras locações forem finalizadas e avaliadas, elas aparecem aqui.</p>
          </div>
        ) : (
          <div className="review-grid">
            {reviews.map((r) => (
              <article className="panel" key={r.id}>
                <strong>{r.stars} / 5</strong>
                <p>{r.comment || "Avaliação sem comentário."}</p>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
