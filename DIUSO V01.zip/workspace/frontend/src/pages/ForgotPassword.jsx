import { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [sending, setSending] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setOk("");
    setSending(true);
    try {
      const data = await api.forgotPassword({ email });
      setOk(data.message || "Se este e-mail estiver cadastrado, enviamos as instruções.");
    } catch (err) {
      setError(err.message);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="shell" style={{ padding: "32px 0 50px", maxWidth: 520 }}>
      <h1>Esqueci a senha</h1>
      <p style={{ color: "var(--muted)" }}>
        Informe o e-mail da conta de locador ou locatário. Enviamos um link para criar uma nova senha.
      </p>
      <form className="panel" style={{ marginTop: 18 }} onSubmit={submit}>
        {error && <div className="alert">{error}</div>}
        {ok && <div className="ok">{ok}</div>}
        <div className="field">
          <label>E-mail</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <button className="btn green wide" type="submit" disabled={sending}>
          {sending ? "Enviando..." : "Enviar link"}
        </button>
        <p style={{ color: "var(--muted)", marginTop: 12 }}>
          Lembrou a senha? <Link to="/entrar">Entrar</Link>
        </p>
      </form>
    </div>
  );
}
