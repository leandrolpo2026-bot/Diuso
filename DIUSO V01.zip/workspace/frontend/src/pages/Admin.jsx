import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../auth.jsx";
import ProofAttach from "../ProofAttach.jsx";
import { availabilityLabel, compareBookings, formatDate, formatMoneyInput, hasDeposit, localIsoDate, money, nextBookingStatus, nextStatusLabel, parseMoney, prevBookingStatus, sortBy, statusLegend, statusMeta } from "../visuals.js";
import { isMaster, isStaff } from "../roles.js";
import FinanceDashboard from "./FinanceDashboard.jsx";
import AnalyticsDashboard from "./AnalyticsDashboard.jsx";
import StaffPanel from "./StaffPanel.jsx";

const incidentNext = {
  aberto: "em_analise",
  em_analise: "aprovado",
  aprovado: "cobrado",
  cobrado: "resolvido"
};

export default function Admin() {
  const { user, ready } = useAuth();
  const [overview, setOverview] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [items, setItems] = useState([]);
  const [requests, setRequests] = useState([]);
  const [users, setUsers] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [ok, setOk] = useState("");
  const [tableSort, setTableSort] = useState({
    bookings: { key: "period", dir: "asc" },
    requests: { key: "item", dir: "asc" },
    incidents: { key: "booking", dir: "asc" },
    catalog: { key: "product", dir: "asc" },
    users: { key: "client", dir: "asc" }
  });
  const [filterDate, setFilterDate] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [lateDialog, setLateDialog] = useState(null);
  const [lateReason, setLateReason] = useState("");
  const [lateError, setLateError] = useState("");
  const [tab, setTab] = useState("operação");
  const [cityCatalog, setCityCatalog] = useState([]);
  const [activeCities, setActiveCities] = useState([]);
  const [cityError, setCityError] = useState("");
  const [newCity, setNewCity] = useState("");
  const [cityPassword, setCityPassword] = useState("");
  const [userReset, setUserReset] = useState(null);
  const [userResetPassword, setUserResetPassword] = useState("");
  const [userResetError, setUserResetError] = useState("");
  const [userRemove, setUserRemove] = useState(null);
  const [userRemovePassword, setUserRemovePassword] = useState("");
  const [userRemoveError, setUserRemoveError] = useState("");
  const [listingReview, setListingReview] = useState(null);
  const [listingForm, setListingForm] = useState(null);
  const [listingPhotos, setListingPhotos] = useState([]);
  const [listingError, setListingError] = useState("");
  const [listingSaving, setListingSaving] = useState(false);
  const [listingRejectComment, setListingRejectComment] = useState("");
  const [itemRemove, setItemRemove] = useState(null);
  const [itemRemovePassword, setItemRemovePassword] = useState("");
  const [itemRemoveError, setItemRemoveError] = useState("");
  const [categories, setCategories] = useState([]);
  const [revenuePeriod, setRevenuePeriod] = useState("30");
  const listingGallery = useRef(null);
  const master = isMaster(user);
  const revenuePeriods = master
    ? [
        { id: "7", label: "7 dias" },
        { id: "30", label: "30 dias" },
        { id: "90", label: "90 dias" },
        { id: "180", label: "180 dias" },
        { id: "all", label: "Todo o período" }
      ]
    : [
        { id: "7", label: "7 dias" },
        { id: "30", label: "30 dias" }
      ];

  const today = localIsoDate(0);
  const tomorrow = localIsoDate(1);

  const sortedBookings = useMemo(() => {
    const list = bookings.filter((b) => {
      if (filterStatus && b.status !== filterStatus) return false;
      if (!filterDate) return true;
      return (b.startDate || "") <= filterDate && filterDate <= (b.endDate || "");
    });
    list.sort((a, b) => compareBookings(a, b, tableSort.bookings.key, tableSort.bookings.dir));
    return list;
  }, [bookings, tableSort.bookings, filterDate, filterStatus]);

  function toggleSort(table, key) {
    setTableSort((current) => {
      const prev = current[table] || { key, dir: "asc" };
      if (prev.key === key) return { ...current, [table]: { key, dir: prev.dir === "asc" ? "desc" : "asc" } };
      return { ...current, [table]: { key, dir: "asc" } };
    });
  }

  function sortMark(table, key) {
    const sort = tableSort[table];
    if (sort?.key !== key) return "";
    return sort.dir === "asc" ? " ↑" : " ↓";
  }

  function SortTh({ table, k, children }) {
    return (
      <th>
        <button type="button" className={`sort-head ${tableSort[table]?.key === k ? "on" : ""}`} onClick={() => toggleSort(table, k)}>
          {children}{sortMark(table, k)}
        </button>
      </th>
    );
  }

  async function load() {
    const [ov, list, catalog, pending, people, occ] = await Promise.all([
      api.overview(revenuePeriod),
      api.bookings(),
      api.items(),
      api.listingRequests(),
      api.adminUsers(),
      api.incidents()
    ]);
    setOverview(ov);
    setBookings(list);
    setItems(catalog);
    setRequests(pending);
    setUsers(people);
    setIncidents(occ);
  }

  useEffect(() => {
    if (!ready || !isStaff(user)) return;
    load().catch(console.error);
    api.cities().then(applyCities).catch(console.error);
    api.categories().then(setCategories).catch(console.error);
  }, [ready, user]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [tab]);

  useEffect(() => {
    if (!master && tab === "municipios") setTab("operação");
  }, [master, tab]);

  function applyCities(data) {
    setCityCatalog(data.all || []);
    setActiveCities(data.active || []);
  }

  function toggleCity(city) {
    setActiveCities((prev) => prev.includes(city) ? prev.filter((c) => c !== city) : [...prev, city]);
  }

  async function createCity() {
    setCityError("");
    const name = newCity.trim();
    if (name.length < 2) {
      setCityError("Informe o nome do município.");
      return;
    }
    try {
      applyCities(await api.createCity(name));
      setNewCity("");
      setOk(`Município “${name}” cadastrado. Ative-o com a senha master para aparecer na plataforma.`);
    } catch (err) {
      setCityError(err.message);
    }
  }

  async function saveCities() {
    setCityError("");
    if (!activeCities.length) {
      setCityError("Selecione pelo menos um município.");
      return;
    }
    if (!cityPassword.trim()) {
      setCityError("Informe a senha da conta master para ativar municípios.");
      return;
    }
    try {
      applyCities(await api.saveCities(activeCities, cityPassword.trim()));
      setCityPassword("");
      setOk("Municípios de atuação atualizados.");
    } catch (err) {
      setCityError(err.message);
    }
  }

  async function update(id, status) {
    await api.updateBooking(id, status);
    await load();
  }

  async function attachPayment(id, file) {
    await api.uploadPaymentProof(id, file);
    await load();
  }

  async function attachRefund(id, file) {
    await api.uploadDepositRefundProof(id, file);
    await load();
  }

  function openLate(id) {
    setLateDialog(id);
    setLateReason("");
    setLateError("");
  }

  async function confirmLate() {
    const reason = lateReason.trim();
    if (!reason) {
      setLateError("Informe a justificativa do atraso");
      return;
    }
    await api.markLate(lateDialog, 1, reason);
    setLateDialog(null);
    setLateReason("");
    setLateError("");
    await load();
  }

  function listingFormFrom(request) {
    return {
      title: request.title || "",
      category: request.category || "",
      city: request.city || "",
      neighborhood: request.neighborhood || "",
      street: request.street || "",
      streetNumber: request.streetNumber || "",
      owner: request.owner || "",
      ownerEmail: request.ownerEmail || "",
      ownerPhone: request.ownerPhone || "",
      description: request.description || "",
      specs: Array.isArray(request.specs) ? request.specs.join(", ") : (request.specs || ""),
      condition: request.condition || "",
      usageRules: request.usageRules || "",
      quantity: String(request.quantity || 1),
      pricePerDay: formatMoneyInput(Math.round(Number(request.pricePerDay || 0) * 100)),
      weeklyPrice: formatMoneyInput(Math.round(Number(request.weeklyPrice || 0) * 100)),
      monthlyPrice: formatMoneyInput(Math.round(Number(request.monthlyPrice || 0) * 100)),
      deposit: formatMoneyInput(Math.round(Number(request.deposit || 0) * 100)),
      estimatedValue: formatMoneyInput(Math.round(Number(request.estimatedValue || 0) * 100))
    };
  }

  function openListingReview(request) {
    setListingReview(request);
    setListingForm(listingFormFrom(request));
    setListingPhotos((request.photos || []).map((photo, index) => ({
      key: photo.filename || `saved-${index}`,
      filename: photo.filename || "",
      url: photo.url || (photo.filename ? `/uploads/listings/${photo.filename}` : ""),
      file: null
    })));
    setListingError("");
    setListingRejectComment("");
  }

  function closeListingReview() {
    listingPhotos.forEach((photo) => {
      if (photo.url?.startsWith("blob:")) URL.revokeObjectURL(photo.url);
    });
    setListingReview(null);
    setListingForm(null);
    setListingPhotos([]);
    setListingError("");
    setListingSaving(false);
    setListingRejectComment("");
  }

  function setListingField(key, value) {
    setListingForm((prev) => ({ ...prev, [key]: value }));
  }

  function setListingMoney(key, value) {
    setListingField(key, formatMoneyInput(value));
  }

  function addListingPhotos(fileList) {
    const incoming = Array.from(fileList || []).filter((file) => file.type.startsWith("image/"));
    if (!incoming.length) return;
    setListingPhotos((prev) => [
      ...prev,
      ...incoming.map((file) => ({
        key: `new-${file.name}-${file.lastModified}-${Math.random().toString(16).slice(2)}`,
        filename: "",
        url: URL.createObjectURL(file),
        file
      }))
    ].slice(0, 12));
    setListingError("");
  }

  function moveListingPhoto(index, dir) {
    setListingPhotos((prev) => {
      const next = [...prev];
      const target = index + dir;
      if (target < 0 || target >= next.length) return prev;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  function removeListingPhoto(index) {
    setListingPhotos((prev) => {
      const photo = prev[index];
      if (photo?.url?.startsWith("blob:")) URL.revokeObjectURL(photo.url);
      return prev.filter((_, i) => i !== index);
    });
  }

  function listingPayload() {
    let newIndex = 0;
    const photoOrder = listingPhotos.map((photo) => {
      if (photo.file) {
        const token = `new:${newIndex}`;
        newIndex += 1;
        return token;
      }
      return photo.filename;
    });
    return {
      ...listingForm,
      pricePerDay: String(parseMoney(listingForm.pricePerDay) || ""),
      weeklyPrice: String(parseMoney(listingForm.weeklyPrice) || 0),
      monthlyPrice: String(parseMoney(listingForm.monthlyPrice) || 0),
      deposit: String(parseMoney(listingForm.deposit) || 0),
      estimatedValue: String(parseMoney(listingForm.estimatedValue) || 0),
      photoOrder,
      photos: listingPhotos.map((photo) => photo.file).filter(Boolean)
    };
  }

  function validateListingForm() {
    if (!listingForm?.title?.trim()) return "Informe o nome do item.";
    if (!listingForm.category) return "Selecione a categoria.";
    if (!listingForm.description?.trim() || !listingForm.specs?.trim()) return "Preencha descricao e destaques.";
    if (!(parseMoney(listingForm.pricePerDay) > 0)) return "Informe o preço por dia.";
    if (!listingForm.quantity || Number(listingForm.quantity) <= 0) return "Informe a quantidade.";
    if (!listingForm.condition) return "Informe a condicao.";
    if (!listingForm.city?.trim() || !listingForm.neighborhood?.trim() || !listingForm.street?.trim() || !listingForm.streetNumber?.trim()) {
      return "Informe município, bairro, logradouro e número.";
    }
    if (!listingForm.usageRules?.trim()) return "Informe as regras de utilizacao.";
    if (!(parseMoney(listingForm.deposit) >= 0) || !(parseMoney(listingForm.estimatedValue) > 0)) {
      return "Informe caução e valor estimado.";
    }
    if (!listingForm.owner?.trim() || !listingForm.ownerEmail?.trim() || !listingForm.ownerPhone?.trim()) {
      return "Informe nome, e-mail e telefone do anunciante.";
    }
    if (listingPhotos.length < 6) return "O anúncio precisa de no mínimo 6 fotos.";
    return "";
  }

  async function saveListingEdits() {
    const msg = validateListingForm();
    if (msg) {
      setListingError(msg);
      return;
    }
    setListingSaving(true);
    setListingError("");
    try {
      const res = await api.updateListingRequest(listingReview.id, listingPayload());
      setListingReview(res.request);
      setListingForm(listingFormFrom(res.request));
      listingPhotos.forEach((photo) => {
        if (photo.url?.startsWith("blob:")) URL.revokeObjectURL(photo.url);
      });
      setListingPhotos((res.request.photos || []).map((photo, index) => ({
        key: photo.filename || `saved-${index}`,
        filename: photo.filename || "",
        url: photo.url || (photo.filename ? `/uploads/listings/${photo.filename}` : ""),
        file: null
      })));
      setOk("Dados do anúncio atualizados. Ainda não publicado.");
      await load();
    } catch (err) {
      setListingError(err.message);
    } finally {
      setListingSaving(false);
    }
  }

  async function approveListingFromPreview() {
    const msg = validateListingForm();
    if (msg) {
      setListingError(msg);
      return;
    }
    setListingSaving(true);
    setListingError("");
    try {
      await api.approveListing(listingReview.id, listingPayload());
      setOk(`Anúncio “${listingForm.title}” aprovado e publicado.`);
      closeListingReview();
      await load();
    } catch (err) {
      setListingError(err.message);
      setListingSaving(false);
    }
  }

  async function rejectListingFromPreview() {
    const comment = listingRejectComment.trim();
    if (comment.length < 8) {
      setListingError("Descreva o que o anunciante precisa alterar.");
      return;
    }
    setListingSaving(true);
    setListingError("");
    try {
      await api.rejectListing(listingReview.id, { comment });
      setOk(`Anúncio “${listingReview.title}” devolvido ao anunciante para correção.`);
      closeListingReview();
      await load();
    } catch (err) {
      setListingError(err.message);
      setListingSaving(false);
    }
  }

  const clients = users.length ? users : [...new Set(bookings.map((b) => b.renterName))].map((name) => ({ name }));
  const requestValue = {
    item: (r) => String(r.title || "").toLowerCase(),
    owner: (r) => String(r.owner || "").toLowerCase(),
    price: (r) => Number(r.pricePerDay || 0),
    photos: (r) => Number(r.photos?.length || 0),
    status: (r) => String(r.status || "")
  };
  const incidentValue = {
    booking: (i) => String(i.bookingId || ""),
    type: (i) => String(i.type || ""),
    amount: (i) => Number(i.amount || 0),
    status: (i) => String(i.status || "")
  };
  const catalogValue = {
    product: (item) => String(item.title || "").toLowerCase(),
    owner: (item) => String(item.owner || "").toLowerCase(),
    price: (item) => Number(item.pricePerDay || 0),
    availability: (item) => String(availabilityLabel[item.availability] || item.availability || ""),
    quantity: (item) => Number(item.quantity || 1)
  };
  const userValue = {
    client: (c) => String(c.name || "").toLowerCase(),
    document: (c) => String(c.documentType ? `${c.documentType} ${c.documentNumber || ""}` : ""),
    city: (c) => String(c.city || "").toLowerCase(),
    level: (c) => `${c.renterLevel || "bronze"} ${Number(c.renterSpent || 0)}`,
    reputation: (c) => String(c.reputation || "regular"),
    photo: (c) => (c.documentPhoto?.url ? "1" : "0")
  };
  const sortedRequests = sortBy(requests, requestValue[tableSort.requests.key] || requestValue.item, tableSort.requests.dir);
  const sortedIncidents = sortBy(incidents, incidentValue[tableSort.incidents.key] || incidentValue.booking, tableSort.incidents.dir);
  const sortedItems = sortBy(items, catalogValue[tableSort.catalog.key] || catalogValue.product, tableSort.catalog.dir);
  const sortedClients = sortBy(clients, userValue[tableSort.users.key] || userValue.client, tableSort.users.dir);

  return (
    <div className="shell" style={{ padding: "32px 0 50px" }}>
      <h1>Painel DIUSO</h1>
      <p style={{ color: "var(--muted)" }}>{master ? "Operação e dashboard financeiro master." : "Usuários, anúncios, contratos, check-in/out e ocorrências."}</p>
      {ok && <div className="ok">{ok}</div>}
      <div className="chips" style={{ margin: "12px 0 8px" }}>
        <button type="button" className={`chip ${tab === "operação" ? "on" : ""}`} onClick={() => setTab("operação")}>Operação</button>
        <button type="button" className={`chip ${tab === "acessos" ? "on" : ""}`} onClick={() => setTab("acessos")}>Acessos</button>
        {master && (
          <>
            <button type="button" className={`chip ${tab === "municipios" ? "on" : ""}`} onClick={() => setTab("municipios")}>Municípios</button>
            <button type="button" className={`chip ${tab === "equipe" ? "on" : ""}`} onClick={() => setTab("equipe")}>Equipe</button>
            <button type="button" className={`chip ${tab === "financeiro" ? "on" : ""}`} onClick={() => setTab("financeiro")}>Dashboard financeiro</button>
          </>
        )}
      </div>

      {master && tab === "financeiro" && <FinanceDashboard />}
      {master && tab === "equipe" && <StaffPanel onMessage={setOk} />}
      {tab === "acessos" && <AnalyticsDashboard />}

      {master && tab === "municipios" && (
        <section className="section">
          <div className="section-head">
            <h2>Municípios de atuação</h2>
          </div>
          <p style={{ color: "var(--muted)" }}>
            Cadastre novos municípios e ative-os com a senha master. Só os ativos aparecem no catálogo e no anúncio. A plataforma inicia com Corinto.
          </p>
          {cityError && <div className="alert">{cityError}</div>}
          <div className="panel" style={{ marginBottom: 16 }}>
            <h3>Novo município</h3>
            <div className="form-grid" style={{ marginTop: 12 }}>
              <div className="field">
                <label>Nome do município</label>
                <input
                  value={newCity}
                  onChange={(e) => setNewCity(e.target.value)}
                  placeholder="Ex.: Curvelo"
                />
              </div>
            </div>
            <div className="menu-form-actions" style={{ marginTop: 12 }}>
              <button type="button" className="btn green" onClick={createCity}>Cadastrar município</button>
            </div>
          </div>
          <div className="panel">
            <h3>Ativar na plataforma</h3>
            <p style={{ color: "var(--muted)" }}>Marque os municípios e confirme com a senha da conta master.</p>
            <div className="city-grid">
              {cityCatalog.map((city) => (
                <label key={city} className={`city-option ${activeCities.includes(city) ? "on" : ""}`}>
                  <input
                    type="checkbox"
                    checked={activeCities.includes(city)}
                    onChange={() => toggleCity(city)}
                  />
                  <span>{city}</span>
                </label>
              ))}
            </div>
            <div className="form-grid" style={{ marginTop: 16 }}>
              <div className="field">
                <label>Senha master</label>
                <input
                  type="password"
                  value={cityPassword}
                  onChange={(e) => setCityPassword(e.target.value)}
                  placeholder="Senha da conta master"
                />
              </div>
            </div>
            <div className="menu-form-actions" style={{ marginTop: 12 }}>
              <button type="button" className="btn green" onClick={saveCities}>Ativar municípios</button>
            </div>
          </div>
        </section>
      )}

      {tab === "operação" && overview && (
        <>
          <div className="section-head">
            <h2>Receita do Diuso</h2>
            <div className="chips" style={{ margin: 0 }}>
              {revenuePeriods.map((period) => (
                <button
                  key={period.id}
                  type="button"
                  className={`chip ${revenuePeriod === period.id ? "on" : ""}`}
                  onClick={async () => {
                    setRevenuePeriod(period.id);
                    try {
                      setOverview(await api.overview(period.id));
                    } catch (err) {
                      console.error(err);
                    }
                  }}
                >
                  {period.label}
                </button>
              ))}
            </div>
          </div>
          <p style={{ color: "var(--muted)", margin: "0 0 12px" }}>
            {revenuePeriod === "all"
              ? "Histórico completo da receita."
              : `De ${formatDate(overview.periodFrom)} a ${formatDate(overview.periodTo)}.`}
            {!master ? " Perfil administrador: no máximo os últimos 30 dias." : ""}
          </p>
          <div className="dash">
            <div className="dash-card"><span>Comissões</span><strong>{money(overview.commissions)}</strong></div>
            <div className="dash-card"><span>Taxas de proteção</span><strong>{money(overview.protectionFees)}</strong></div>
            <div className="dash-card"><span>Taxas de atraso</span><strong>{money(overview.lateFees)}</strong></div>
            <div className="dash-card"><span>Receita total</span><strong>{money(overview.revenue)}</strong></div>
            <div className="dash-card"><span>Cauções de clientes</span><strong>{money(overview.heldDeposits)}</strong><div style={{ color: "var(--muted)" }}>Não é receita</div></div>
            <div className="dash-card"><span>Repasses retidos</span><strong>{money(overview.payoutsHeld)}</strong></div>
            <div className="dash-card"><span>Repasses em processamento</span><strong>{money(overview.payoutsProcessing)}</strong></div>
            <div className="dash-card"><span>Aluguéis ativos</span><strong>{overview.activeRentals}</strong></div>
            <div className="dash-card"><span>Atrasados</span><strong>{overview.late}</strong></div>
            <div className="dash-card"><span>Ocorrências abertas</span><strong>{overview.incidentsOpen || 0}</strong></div>
            <div className="dash-card"><span>Anúncios pendentes</span><strong>{overview.pendingListings || 0}</strong></div>
          </div>
        </>
      )}

      {tab === "operação" && (
      <>
      <section className="section">
        <div className="section-head"><h2>Solicitações de anúncio</h2></div>
        <div className="panel" style={{ overflowX: "auto" }}>
          {requests.length === 0 && <p style={{ color: "var(--muted)" }}>Nenhuma solicitacao aguardando análise.</p>}
          {requests.length > 0 && (
            <table className="table">
              <thead>
                <tr>
                  <SortTh table="requests" k="item">Item</SortTh>
                  <SortTh table="requests" k="owner">Anunciante</SortTh>
                  <SortTh table="requests" k="price">Diaria</SortTh>
                  <SortTh table="requests" k="photos">Fotos</SortTh>
                  <SortTh table="requests" k="status">Status</SortTh>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {sortedRequests.map((r) => (
                  <tr key={r.id}>
                    <td>
                      <button type="button" className="listing-name" onClick={() => openListingReview(r)}>
                        <strong>{r.title}</strong>
                      </button>
                      <div style={{ color: "var(--muted)" }}>{[r.street, r.streetNumber].filter(Boolean).join(", ")}{r.neighborhood ? ` · ${r.neighborhood}` : ""} · {r.city}</div>
                    </td>
                    <td>
                      {r.owner}
                      <div style={{ color: "var(--muted)" }}>{r.ownerEmail}</div>
                    </td>
                    <td>{money(r.pricePerDay)}/dia</td>
                    <td>{r.photos?.length || 0}</td>
                    <td>
                      <span className={`status ${(statusMeta[r.status] || statusMeta.aguardando_analise).tone}`}>
                        {(statusMeta[r.status] || {}).label || r.status}
                      </span>
                      {r.status === "rejeitado" && r.rejectionComment && (
                        <div className="status-desc">{r.rejectionComment}</div>
                      )}
                    </td>
                    <td>
                      <button type="button" className="ghost" onClick={() => openListingReview(r)}>Ver</button>
                      {r.status === "aguardando_analise" && (
                        <button className="ghost" onClick={() => openListingReview(r)}>Revisar</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>

      <section className="section">
        <div className="section-head"><h2>Pedidos</h2></div>
        <div className="panel" style={{ overflowX: "auto" }}>
          <div className="table-toolbar">
            <div className="status-legend">
              {statusLegend.map((key) => {
                const meta = statusMeta[key];
                return (
                  <button
                    type="button"
                    key={key}
                    className={`status ${meta.tone} ${filterStatus === key ? "on" : ""}`}
                    onClick={() => setFilterStatus((current) => (current === key ? "" : key))}
                  >
                    {meta.label}
                  </button>
                );
              })}
            </div>
            <div className="date-filter">
              <button type="button" className={`chip-mini ${filterDate === today ? "on" : ""}`} onClick={() => setFilterDate(today)}>Hoje</button>
              <button type="button" className={`chip-mini ${filterDate === tomorrow ? "on" : ""}`} onClick={() => setFilterDate(tomorrow)}>Amanhã</button>
              <input type="date" value={filterDate} onChange={(e) => setFilterDate(e.target.value)} />
              {filterDate && (
                <button type="button" className="chip-mini" onClick={() => setFilterDate("")}>Limpar</button>
              )}
            </div>
          </div>
          <table className="table">
            <thead>
              <tr>
                <SortTh table="bookings" k="item">Item</SortTh>
                <SortTh table="bookings" k="client">Cliente</SortTh>
                <SortTh table="bookings" k="period">Período</SortTh>
                <SortTh table="bookings" k="money">Locação / caução</SortTh>
                <SortTh table="bookings" k="status">Status</SortTh>
                <SortTh table="bookings" k="refund">Reembolso caução</SortTh>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {sortedBookings.map((b) => {
                const meta = statusMeta[b.status] || statusMeta.aguardando_confirmacao;
                const next = nextBookingStatus(b);
                const prev = prevBookingStatus(b);
                return (
                  <tr key={b.id}>
                    <td><Link to={`/locação/${b.id}`}><strong>{b.item?.title || b.itemId}</strong></Link></td>
                    <td>
                      {b.renterName}
                      <div style={{ color: "var(--muted)" }}>{b.renterCpf ? `CPF ${b.renterCpf}` : b.renterEmail}</div>
                    </td>
                    <td>{formatDate(b.startDate)} — {formatDate(b.endDate)}</td>
                    <td>{money(b.rentalDue || b.total)} · caução {money(b.deposit)}</td>
                    <td>
                      <div className="status-cell">
                        <span className={`status ${meta.tone}`}>{meta.label}</span>
                        {b.status === "atrasado" && b.lateReason && <span className="status-desc">{b.lateReason}</span>}
                      </div>
                    </td>
                    <td>
                      {hasDeposit(b) ? (
                        <ProofAttach file={b.depositRefundProof} onFile={(file) => attachRefund(b.id, file)} label="Anexar reembolso" />
                      ) : (
                        <span className="status-desc">Sem caução</span>
                      )}
                    </td>
                    <td>
                      <div className="table-actions">
                        {prev && (
                          <button className="ghost" onClick={() => update(b.id, prev)}>Voltar status</button>
                        )}
                        {next && (
                          <button className="ghost" onClick={() => update(b.id, next)}>{nextStatusLabel[next] || "Avancar"}</button>
                        )}
                        {b.status !== "atrasado" && !["finalizado", "cancelado", "reembolsado"].includes(b.status) && (
                          <button className="ghost" onClick={() => openLate(b.id)}>Atrasado</button>
                        )}
                        <a className="ghost" href={api.serviceOrderUrl(b.id)} target="_blank" rel="noreferrer">Ordem de serviço</a>
                        <a className="btn green" href={api.chargeNoteUrl(b.id)} target="_blank" rel="noreferrer">Nota de cobrança</a>
                        <label className="chip-mini proof-upload">
                          Anexar comprovante
                          <input
                            type="file"
                            accept="image/*,application/pdf"
                            onChange={(e) => {
                              const picked = e.target.files?.[0];
                              if (picked) attachPayment(b.id, picked);
                              e.target.value = "";
                            }}
                          />
                        </label>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      <section className="section">
        <div className="section-head"><h2>Ocorrências</h2></div>
        <div className="panel" style={{ overflowX: "auto" }}>
          {incidents.length === 0 && <p style={{ color: "var(--muted)" }}>Nenhuma ocorrência.</p>}
          {incidents.length > 0 && (
            <table className="table">
              <thead>
                <tr>
                  <SortTh table="incidents" k="booking">Locação</SortTh>
                  <SortTh table="incidents" k="type">Tipo</SortTh>
                  <SortTh table="incidents" k="amount">Valor</SortTh>
                  <SortTh table="incidents" k="status">Status</SortTh>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {sortedIncidents.map((i) => (
                  <tr key={i.id}>
                    <td><Link to={`/locação/${i.bookingId}`}>{i.bookingId}</Link></td>
                    <td>{i.type}</td>
                    <td>{money(i.amount)}</td>
                    <td>{i.status}</td>
                    <td>
                      {incidentNext[i.status] && (
                        <button className="ghost" onClick={async () => { await api.updateIncident(i.id, { status: incidentNext[i.status] }); await load(); }}>
                          {incidentNext[i.status]}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>

      <section className="section">
        <div className="section-head"><h2>Catalogo</h2></div>
        <div className="panel" style={{ overflowX: "auto" }}>
          <table className="table">
            <thead>
              <tr>
                <SortTh table="catalog" k="product">Produto</SortTh>
                <SortTh table="catalog" k="owner">Proprietario</SortTh>
                <SortTh table="catalog" k="price">Diaria</SortTh>
                <SortTh table="catalog" k="availability">Disponibilidade</SortTh>
                 <SortTh table="catalog" k="quantity">Unidades</SortTh>
                 <th></th>
               </tr>
             </thead>
             <tbody>
               {sortedItems.filter((item) => item.listingStatus !== "excluido").map((item) => (
                 <tr key={item.id}>
                   <td><Link to={`/item/${item.id}`}>{item.title}</Link></td>
                   <td>{item.owner}</td>
                   <td>{money(item.pricePerDay)}/dia</td>
                   <td>{availabilityLabel[item.availability] || item.availability}</td>
                   <td>{item.quantity || 1}</td>
                   <td>
                     <div className="table-actions">
                       {item.listingStatus === "pausado" ? (
                         <button
                           type="button"
                           className="ghost"
                           onClick={async () => {
                             await api.resumeListing(item.id);
                             setOk(`Anúncio “${item.title}” reativado.`);
                             await load();
                           }}
                         >
                           Reativar
                         </button>
                       ) : (
                         <button
                           type="button"
                           className="ghost"
                           onClick={async () => {
                             const res = await api.pauseListing(item.id);
                             setOk(res.message || `Anúncio “${item.title}” pausado.`);
                             await load();
                           }}
                         >
                           Pausar
                         </button>
                       )}
                       <button type="button" className="ghost" onClick={() => { setItemRemove(item); setItemRemovePassword(""); setItemRemoveError(""); }}>
                         Excluir
                       </button>
                     </div>
                   </td>
                 </tr>
               ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="section">
        <div className="section-head"><h2>Usuários</h2></div>
        <div className="panel" style={{ overflowX: "auto" }}>
          <table className="table">
            <thead>
              <tr>
                <SortTh table="users" k="client">Cliente</SortTh>
                <SortTh table="users" k="document">Documento</SortTh>
                <SortTh table="users" k="city">Cidade</SortTh>
                <SortTh table="users" k="level">Nível</SortTh>
                <SortTh table="users" k="reputation">Reputação</SortTh>
                 <SortTh table="users" k="photo">Foto</SortTh>
                 <th></th>
               </tr>
             </thead>
            <tbody>
              {sortedClients.map((c) => (
                <tr key={c.id || c.name}>
                  <td>
                    <strong>{c.name}</strong>
                    <div style={{ color: "var(--muted)" }}>{c.email || c.phone || ""}</div>
                    {c.mustChangePassword ? <div style={{ color: "var(--muted)" }}>Pendente criar senha</div> : null}
                    {c.quarantined ? <div style={{ color: "var(--rose)" }}>{c.quarantineReason || "Em quarentena até reavaliação"}</div> : null}
                  </td>
                  <td>{c.documentType ? `${c.documentType} ${c.documentNumber || ""}` : "—"}</td>
                  <td>{c.city || "—"}</td>
                  <td>{(c.renterLevel || "bronze").toUpperCase()}{c.renterSpent != null ? ` · ${money(c.renterSpent)}` : ""}{c.renterPaidCount != null ? ` · ${c.renterPaidCount} pagas` : ""}</td>
                  <td>{c.reputation || "regular"}{c.blocked ? " · bloqueado" : ""}{c.quarantined ? " · quarentena" : ""}</td>
                  <td>
                     {c.documentPhoto?.url ? (
                       <a href={c.documentPhoto.url} target="_blank" rel="noreferrer">Ver documento</a>
                     ) : "—"}
                   </td>
                   <td>
                     {c.id && (
                       <div className="table-actions">
                         {c.quarantined && (
                           <button
                             className="ghost"
                             type="button"
                             onClick={async () => {
                               await api.reviewQuarantine(c.id, { action: "release" });
                               setOk(`${c.name} saiu da quarentena e pode alugar novamente.`);
                               await load();
                             }}
                           >
                             Liberar quarentena
                           </button>
                         )}
                         {master && (
                           <>
                             <button
                               className="ghost"
                               type="button"
                               onClick={() => { setUserReset(c); setUserResetPassword(""); setUserResetError(""); }}
                             >
                               Resetar senha
                             </button>
                             <button
                               className="ghost"
                               type="button"
                               onClick={() => { setUserRemove(c); setUserRemovePassword(""); setUserRemoveError(""); }}
                             >
                               Excluir
                             </button>
                           </>
                         )}
                       </div>
                     )}
                   </td>
                 </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      </>
      )}
      {userRemove && (
        <div className="late-dialog-backdrop" onClick={() => setUserRemove(null)}>
          <div className="late-dialog" onClick={(e) => e.stopPropagation()}>
            <h2>Excluir locador ou locatário</h2>
            <p style={{ color: "var(--muted)", margin: "8px 0 12px" }}>
              Excluir {userRemove.name}. Informe a senha do administrador master para confirmar.
            </p>
            <input type="password" value={userRemovePassword} onChange={(e) => setUserRemovePassword(e.target.value)} placeholder="Senha master" autoFocus />
            {userRemoveError && <div className="alert" style={{ marginTop: 10 }}>{userRemoveError}</div>}
            <div className="late-dialog-actions">
              <button type="button" className="ghost" onClick={() => setUserRemove(null)}>Cancelar</button>
              <button
                type="button"
                className="btn green"
                onClick={async () => {
                  const password = userRemovePassword.trim();
                  if (!password) {
                    setUserRemoveError("Informe a senha do administrador master.");
                    return;
                  }
                  try {
                    await api.removeUser(userRemove.id, { password });
                    setOk(`Perfil de ${userRemove.name} excluído.`);
                    setUserRemove(null);
                    setUserRemovePassword("");
                    setUserRemoveError("");
                    await load();
                  } catch (err) {
                    setUserRemoveError(err.message);
                  }
                }}
              >
                Excluir perfil
              </button>
            </div>
          </div>
        </div>
      )}
      {userReset && (
        <div className="late-dialog-backdrop" onClick={() => setUserReset(null)}>
          <div className="late-dialog" onClick={(e) => e.stopPropagation()}>
            <h2>Resetar senha do usuário</h2>
            <p style={{ color: "var(--muted)", margin: "8px 0 12px" }}>
              Nova senha para {userReset.name}. As sessoes abertas dessa conta serao encerradas.
            </p>
            <input type="password" minLength="6" value={userResetPassword} onChange={(e) => setUserResetPassword(e.target.value)} placeholder="Nova senha" autoFocus />
            {userResetError && <div className="alert" style={{ marginTop: 10 }}>{userResetError}</div>}
            <div className="late-dialog-actions">
              <button type="button" className="ghost" onClick={() => setUserReset(null)}>Cancelar</button>
              <button
                type="button"
                className="btn green"
                onClick={async () => {
                  const password = userResetPassword.trim();
                  if (password.length < 6) {
                    setUserResetError("A senha precisa ter no mínimo 6 caracteres.");
                    return;
                  }
                  try {
                    await api.resetUserPassword(userReset.id, { newPassword: password });
                    setOk(`Senha de ${userReset.name} redefinida. No próximo acesso, a pessoa cria uma senha nova.`);
                    setUserReset(null);
                    setUserResetPassword("");
                    setUserResetError("");
                    await load();
                  } catch (err) {
                    setUserResetError(err.message);
                  }
                }}
              >
                Salvar senha
              </button>
            </div>
          </div>
        </div>
      )}
      {listingReview && listingForm && (
        <div className="late-dialog-backdrop" onClick={closeListingReview}>
          <div className="late-dialog listing-review-dialog" onClick={(e) => e.stopPropagation()}>
            <div className="listing-review-head">
              <div>
                <h2>Prévia do anúncio</h2>
                <p style={{ color: "var(--muted)", margin: "4px 0 0" }}>
                  {listingReview.status === "aguardando_analise"
                    ? "Revise fotos e dados. Edite o que for necessário antes de aprovar a publicação."
                    : `Status: ${listingReview.status}.`}
                </p>
              </div>
              <button type="button" className="ghost" onClick={closeListingReview}>Fechar</button>
            </div>

            <div className="listing-preview listing-review-hero">
              {listingPhotos[0]?.url ? <img src={listingPhotos[0].url} alt="" /> : <div className="listing-review-empty">Sem capa</div>}
              <div>
                <strong>{listingForm.title || "Sem título"}</strong>
                <p>{categories.find((c) => c.id === listingForm.category)?.name || listingForm.category} · {[listingForm.street, listingForm.streetNumber].filter(Boolean).join(", ")} · {listingForm.neighborhood} · {listingForm.city}</p>
                <p>{parseMoney(listingForm.pricePerDay) > 0 ? `${money(parseMoney(listingForm.pricePerDay))}/dia` : "Preço pendente"} · caução {listingForm.deposit || "—"}</p>
                <p>{listingForm.description || "Descrição pendente"}</p>
              </div>
            </div>

            {listingError && <div className="alert" style={{ marginTop: 12 }}>{listingError}</div>}

            <div className="field" style={{ marginTop: 16 }}>
              <label>Fotos (mínimo 6). A primeira é a capa.</label>
              <input ref={listingGallery} type="file" accept="image/*" multiple hidden onChange={(e) => { addListingPhotos(e.target.files); e.target.value = ""; }} />
              <div className="photo-actions">
                <button className="btn ghost-btn" type="button" onClick={() => listingGallery.current?.click()}>Adicionar fotos</button>
                <p className={`photo-hint ${listingPhotos.length >= 6 ? "ok-text" : ""}`} style={{ margin: 0 }}>
                  {listingPhotos.length} de 6 fotos
                </p>
              </div>
              {listingPhotos.length > 0 && (
                <div className="photo-grid photo-grid-edit">
                  {listingPhotos.map((photo, index) => (
                    <figure key={photo.key} className="photo-tile">
                      <img src={photo.url} alt={`Foto ${index + 1}`} />
                      <span className="photo-order">{index === 0 ? "Capa" : index + 1}</span>
                      {listingReview.status === "aguardando_analise" && (
                        <div className="photo-tile-actions">
                          <button type="button" disabled={index === 0} onClick={() => moveListingPhoto(index, -1)} aria-label="Mover para a esquerda">‹</button>
                          <button type="button" disabled={index === listingPhotos.length - 1} onClick={() => moveListingPhoto(index, 1)} aria-label="Mover para a direita">›</button>
                          <button type="button" onClick={() => removeListingPhoto(index)} aria-label="Remover foto">×</button>
                        </div>
                      )}
                    </figure>
                  ))}
                </div>
              )}
            </div>

            <div className="form-grid" style={{ marginTop: 16 }}>
              <div className="field" style={{ gridColumn: "1 / -1" }}>
                <label>Nome do produto</label>
                <input value={listingForm.title} onChange={(e) => setListingField("title", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field">
                <label>Categoria</label>
                <select value={listingForm.category} onChange={(e) => setListingField("category", e.target.value)} disabled={listingReview.status !== "aguardando_analise"}>
                  <option value="">Selecione</option>
                  {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="field">
                <label>Condição</label>
                <select value={listingForm.condition} onChange={(e) => setListingField("condition", e.target.value)} disabled={listingReview.status !== "aguardando_analise"}>
                  <option value="">Selecione</option>
                  <option>Como novo</option>
                  <option>Excelente</option>
                  <option>Muito bom</option>
                  <option>Bom</option>
                </select>
              </div>
              <div className="field">
                <label>Quantidade</label>
                <input type="number" min="1" value={listingForm.quantity} onChange={(e) => setListingField("quantity", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field">
                <label>Município</label>
                <select value={listingForm.city} onChange={(e) => setListingField("city", e.target.value)} disabled={listingReview.status !== "aguardando_analise"}>
                  <option value="">Selecione</option>
                  {(activeCities.length ? activeCities : cityCatalog).map((city) => <option key={city} value={city}>{city}</option>)}
                  {listingForm.city && !(activeCities.includes(listingForm.city) || cityCatalog.includes(listingForm.city)) && (
                    <option value={listingForm.city}>{listingForm.city}</option>
                  )}
                </select>
              </div>
              <div className="field">
                <label>Bairro</label>
                <input value={listingForm.neighborhood} onChange={(e) => setListingField("neighborhood", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field">
                <label>Logradouro (Rua/Avenida)</label>
                <input value={listingForm.street} onChange={(e) => setListingField("street", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field">
                <label>Número</label>
                <input value={listingForm.streetNumber} onChange={(e) => setListingField("streetNumber", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field">
                <label>Diária (R$)</label>
                <input inputMode="numeric" value={listingForm.pricePerDay} onChange={(e) => setListingMoney("pricePerDay", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field">
                <label>Semanal (R$)</label>
                <input inputMode="numeric" value={listingForm.weeklyPrice} onChange={(e) => setListingMoney("weeklyPrice", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field">
                <label>Mensal (R$)</label>
                <input inputMode="numeric" value={listingForm.monthlyPrice} onChange={(e) => setListingMoney("monthlyPrice", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field">
                <label>Caução (R$)</label>
                <input inputMode="numeric" value={listingForm.deposit} onChange={(e) => setListingMoney("deposit", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field">
                <label>Valor estimado (R$)</label>
                <input inputMode="numeric" value={listingForm.estimatedValue} onChange={(e) => setListingMoney("estimatedValue", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field" style={{ gridColumn: "1 / -1" }}>
                <label>Destaques</label>
                <input value={listingForm.specs} onChange={(e) => setListingField("specs", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field" style={{ gridColumn: "1 / -1" }}>
                <label>Descrição</label>
                <textarea rows="3" value={listingForm.description} onChange={(e) => setListingField("description", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field" style={{ gridColumn: "1 / -1" }}>
                <label>Regras de utilização</label>
                <textarea rows="3" value={listingForm.usageRules} onChange={(e) => setListingField("usageRules", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field">
                <label>Anunciante</label>
                <input value={listingForm.owner} onChange={(e) => setListingField("owner", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field">
                <label>E-mail</label>
                <input type="email" value={listingForm.ownerEmail} onChange={(e) => setListingField("ownerEmail", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
              <div className="field" style={{ gridColumn: "1 / -1" }}>
                <label>Telefone</label>
                <input value={listingForm.ownerPhone} onChange={(e) => setListingField("ownerPhone", e.target.value)} disabled={listingReview.status !== "aguardando_analise"} />
              </div>
            </div>

            {listingReview.status === "aguardando_analise" && (
              <div className="field" style={{ marginTop: 16 }}>
                <label>Comentário para o anunciante (obrigatório para devolver)</label>
                <textarea
                  rows="3"
                  value={listingRejectComment}
                  onChange={(e) => setListingRejectComment(e.target.value)}
                  placeholder="Descreva o que precisa ser alterado. O anúncio volta para o anunciante corrigir e reenviar."
                />
              </div>
            )}
            {listingReview.rejectionComment && (
              <p className="ok" style={{ marginTop: 12 }}>Último comentário enviado: {listingReview.rejectionComment}</p>
            )}

            <div className="late-dialog-actions">
              <button type="button" className="ghost" onClick={closeListingReview}>Fechar</button>
              {listingReview.status === "aguardando_analise" && (
                <>
                  <button type="button" className="ghost" disabled={listingSaving} onClick={rejectListingFromPreview}>Devolver para correção</button>
                  <button type="button" className="btn ghost-btn" disabled={listingSaving} onClick={saveListingEdits}>
                    {listingSaving ? "Salvando..." : "Salvar alterações"}
                  </button>
                  <button type="button" className="btn green" disabled={listingSaving} onClick={approveListingFromPreview}>
                    {listingSaving ? "Publicando..." : "Aprovar e publicar"}
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
      {itemRemove && (
        <div className="late-dialog-backdrop" onClick={() => setItemRemove(null)}>
          <div className="late-dialog" onClick={(e) => e.stopPropagation()}>
            <h2>Excluir anúncio</h2>
            <p style={{ color: "var(--muted)", margin: "8px 0 12px" }}>
              Excluir “{itemRemove.title}” do catálogo. Informe a senha da sua conta. Reservas já feitas continuam no perfil do locatário até a devolução. Estorno, se necessário, só o administrador pode fazer.
            </p>
            <input type="password" value={itemRemovePassword} onChange={(e) => setItemRemovePassword(e.target.value)} placeholder="Senha da conta" autoFocus />
            {itemRemoveError && <div className="alert" style={{ marginTop: 10 }}>{itemRemoveError}</div>}
            <div className="late-dialog-actions">
              <button type="button" className="ghost" onClick={() => setItemRemove(null)}>Cancelar</button>
              <button
                type="button"
                className="btn green"
                onClick={async () => {
                  const password = itemRemovePassword.trim();
                  if (!password) {
                    setItemRemoveError("Informe a senha da conta.");
                    return;
                  }
                  try {
                    const res = await api.removeListing(itemRemove.id, { password });
                    setOk(res.message || `Anúncio “${itemRemove.title}” excluído.`);
                    setItemRemove(null);
                    setItemRemovePassword("");
                    setItemRemoveError("");
                    await load();
                  } catch (err) {
                    setItemRemoveError(err.message);
                  }
                }}
              >
                Excluir anúncio
              </button>
            </div>
          </div>
        </div>
      )}
      {lateDialog && (
        <div className="late-dialog-backdrop" onClick={() => setLateDialog(null)}>
          <div className="late-dialog" onClick={(e) => e.stopPropagation()}>
            <h2>Justificativa do atraso</h2>
            <p style={{ color: "var(--muted)", margin: "8px 0 12px" }}>Obrigatorio para marcar o pedido como atrasado. A descricao aparece na coluna Status.</p>
            <textarea value={lateReason} onChange={(e) => setLateReason(e.target.value)} placeholder="Ex.: locatário não devolveu no horario combinado" />
            {lateError && <div className="alert" style={{ marginTop: 10 }}>{lateError}</div>}
            <div className="late-dialog-actions">
              <button type="button" className="ghost" onClick={() => setLateDialog(null)}>Cancelar</button>
              <button type="button" className="btn green" onClick={confirmLate}>Marcar atrasado</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
