import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../auth.jsx";
import ProofAttach from "../ProofAttach.jsx";
import { formatDate, hasDeposit, money, renterLevelMeta, statusMeta } from "../visuals.js";

export default function BookingDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [booking, setBooking] = useState(null);
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [contractOpen, setContractOpen] = useState(false);
  const [check, setCheck] = useState({ notes: "", accessories: "", condition: "", serialNumber: "", checklist: "", photos: [] });
  const [incident, setIncident] = useState({ type: "pequeno_dano", description: "", budget: "", photos: [] });
  const [review, setReview] = useState({ stars: 5, reliability: 5, conservation: 5, communication: 5, punctuality: 5, comment: "" });

  async function load() {
    const data = await api.booking(id);
    setBooking(data);
  }

  useEffect(() => { load().catch((err) => setError(err.message)); }, [id]);

  async function run(action) {
    setError("");
    setOk("");
    try {
      await action();
      await load();
      setOk("Atualizado.");
    } catch (err) {
      setError(err.message);
    }
  }

  if (!booking) return <div className="shell" style={{ padding: 40 }}>{error || "Carregando..."}</div>;
  const meta = statusMeta[booking.status] || statusMeta.aguardando_confirmacao;
  const item = booking.item || {};

  return (
    <div className="shell" style={{ padding: "32px 0 50px" }}>
      <p><Link to="/conta">Voltar para minhas locações</Link></p>
      <h1>{item.title || booking.itemId}</h1>
      <p style={{ color: "var(--muted)" }}>
        {formatDate(booking.startDate)} {booking.startTime || ""} — {formatDate(booking.endDate)} {booking.endTime || ""} · <span className={`status ${meta.tone}`}>{meta.label}</span>
        {booking.status === "atrasado" && booking.lateReason ? ` · ${booking.lateReason}` : ""}
      </p>
      {error && <div className="alert">{error}</div>}
      {ok && <div className="ok">{ok}</div>}

      <div className="dash">
        <div className="dash-card"><span>Aluguel</span><strong>{money(booking.rentalAmount)}</strong></div>
        <div className="dash-card"><span>Proteção Diuso</span><strong>{money(booking.protectionFee)}</strong></div>
        <div className="dash-card">
          <span>Caução retida</span>
          <strong>{money(booking.deposit)}</strong>
          <div style={{ color: "var(--muted)" }}>
            {booking.depositStatus}
            {booking.renterLevel ? ` · ${renterLevelMeta[booking.renterLevel]?.label || booking.renterLevel} (${renterLevelMeta[booking.renterLevel]?.deposit || ""})` : ""}
          </div>
        </div>
        <div className="dash-card"><span>Locação a pagar</span><strong>{money(booking.rentalDue)}</strong></div>
        <div className="dash-card"><span>Pagamento</span><strong>{booking.paymentStatus}</strong><div style={{ color: "var(--muted)" }}>{booking.paymentProof?.originalname || "Gateway ainda não conectado"}</div></div>
        <div className="dash-card"><span>Repasse</span><strong>{booking.payoutStatus}</strong></div>
      </div>

      <section className="section">
        <div className="panel">
          <h2>Comprovantes</h2>
          <div className="form-grid">
            <div className="field">
              <label>Comprovante de pagamento</label>
              <ProofAttach file={booking.paymentProof} onFile={(file) => run(() => api.uploadPaymentProof(booking.id, file))} label="Anexar comprovante" />
            </div>
            <div className="field">
              <label>Reembolso da caução</label>
              {hasDeposit(booking) ? (
                <ProofAttach file={booking.depositRefundProof} onFile={(file) => run(() => api.uploadDepositRefundProof(booking.id, file))} label="Anexar reembolso" />
              ) : (
                <span className="status-desc">Sem caução</span>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="panel">
          <h2>Contrato digital</h2>
          <p>Aceite em {booking.contractAcceptedAt ? new Date(booking.contractAcceptedAt).toLocaleString("pt-BR") : "pendente"}.</p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button className="ghost" type="button" onClick={() => setContractOpen((v) => !v)}>Visualizar contrato</button>
            {user && !booking.contract?.acceptedAt && (
              <button className="btn green" type="button" onClick={() => run(() => api.acceptContract(booking.id))}>Aceitar contrato</button>
            )}
          </div>
          {contractOpen && booking.contract && (
            <div className="calc" style={{ marginTop: 12 }}>
              <p><strong>Locador:</strong> {booking.contract.locador}</p>
              <p><strong>Locatário:</strong> {booking.contract.locatario}</p>
              <p><strong>Produto:</strong> {booking.contract.product}</p>
              <p><strong>Período:</strong> {booking.contract.period?.start} a {booking.contract.period?.end}</p>
              <p><strong>Aluguel:</strong> {money(booking.contract.rentalAmount)} · Proteção {money(booking.contract.protectionFee)} · Caução {money(booking.contract.deposit)}</p>
              <p><strong>Retirada:</strong> {booking.contract.pickupWindow} · <strong>Devolução:</strong> {booking.contract.returnWindow}</p>
              <p><strong>Atraso:</strong> {booking.contract.latePolicy}</p>
              <p><strong>Danos:</strong> {booking.contract.damagePolicy}</p>
              <p><strong>Regras:</strong> {booking.contract.usageRules}</p>
            </div>
          )}
        </div>
      </section>

      <section className="section layout">
        <div className="panel">
          <h2>Estado na retirada</h2>
          {booking.checkIn ? (
            <div>
              <p>{booking.checkIn.condition} · {new Date(booking.checkIn.at).toLocaleString("pt-BR")}</p>
              <p>{booking.checkIn.notes}</p>
              <p>Acessórios: {booking.checkIn.accessories || "—"}</p>
              <div className="photo-grid">
                {(booking.checkIn.photos || []).map((p) => <img key={p.url} src={p.url} alt="Check-in" />)}
              </div>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); run(() => api.checkIn(booking.id, check)); }}>
              <div className="field"><label>Estado</label><input value={check.condition} onChange={(e) => setCheck({ ...check, condition: e.target.value })} /></div>
              <div className="field"><label>Acessórios</label><input value={check.accessories} onChange={(e) => setCheck({ ...check, accessories: e.target.value })} /></div>
              <div className="field"><label>Número de série</label><input value={check.serialNumber} onChange={(e) => setCheck({ ...check, serialNumber: e.target.value })} /></div>
              <div className="field"><label>Observações</label><textarea rows="3" value={check.notes} onChange={(e) => setCheck({ ...check, notes: e.target.value })} /></div>
              <div className="field"><label>Fotos</label><input type="file" accept="image/*" multiple onChange={(e) => setCheck({ ...check, photos: Array.from(e.target.files || []) })} /></div>
              <button className="btn green" type="submit">Registrar check-in</button>
            </form>
          )}
        </div>
        <div className="panel">
          <h2>Estado na devolução</h2>
          {booking.checkOut ? (
            <div>
              <p>{booking.checkOut.condition} · {new Date(booking.checkOut.at).toLocaleString("pt-BR")}</p>
              <p>{booking.checkOut.notes}</p>
              <div className="photo-grid">
                {(booking.checkOut.photos || []).map((p) => <img key={p.url} src={p.url} alt="Check-out" />)}
              </div>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); run(() => api.checkOut(booking.id, check)); }}>
              <div className="field"><label>Estado</label><input value={check.condition} onChange={(e) => setCheck({ ...check, condition: e.target.value })} /></div>
              <div className="field"><label>Checklist</label><input value={check.checklist} onChange={(e) => setCheck({ ...check, checklist: e.target.value })} /></div>
              <div className="field"><label>Observações</label><textarea rows="3" value={check.notes} onChange={(e) => setCheck({ ...check, notes: e.target.value })} /></div>
              <div className="field"><label>Fotos</label><input type="file" accept="image/*" multiple onChange={(e) => setCheck({ ...check, photos: Array.from(e.target.files || []) })} /></div>
              <button className="btn green" type="submit">Registrar check-out</button>
            </form>
          )}
        </div>
      </section>

      <section className="section">
        <div className="panel">
          <h2>Ocorrência de dano</h2>
          {(booking.incidents || []).map((i) => (
            <p key={i.id}>{i.type} · {i.status} · {money(i.amount)} — {i.description}</p>
          ))}
          <form onSubmit={(e) => { e.preventDefault(); run(() => api.openIncident({ ...incident, bookingId: booking.id })); }}>
            <div className="form-grid">
              <div className="field">
                <label>Tipo</label>
                <select value={incident.type} onChange={(e) => setIncident({ ...incident, type: e.target.value })}>
                  <option value="desgaste_normal">Desgaste normal</option>
                  <option value="pequeno_dano">Pequeno dano</option>
                  <option value="dano_relevante">Dano relevante</option>
                  <option value="perda_ou_destruicao">Perda ou destruição</option>
                </select>
              </div>
              <div className="field"><label>Orçamento</label><input type="number" value={incident.budget} onChange={(e) => setIncident({ ...incident, budget: e.target.value })} /></div>
              <div className="field" style={{ gridColumn: "1 / -1" }}><label>Descrição</label><textarea rows="3" value={incident.description} onChange={(e) => setIncident({ ...incident, description: e.target.value })} /></div>
              <div className="field" style={{ gridColumn: "1 / -1" }}><label>Fotos</label><input type="file" accept="image/*" multiple onChange={(e) => setIncident({ ...incident, photos: Array.from(e.target.files || []) })} /></div>
            </div>
            <button className="ghost" type="submit">Abrir ocorrência de dano</button>
          </form>
        </div>
      </section>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {booking.status !== "cancelado" && booking.status !== "finalizado" && (
          <button className="ghost" onClick={() => run(() => api.cancelBooking(booking.id))}>Cancelar locação</button>
        )}
        {booking.checkOut && booking.inspectionStatus !== "aprovada" && (
          <button className="btn green" onClick={() => run(() => api.inspectBooking(booking.id, "aprovada"))}>
            {hasDeposit(booking) ? "Aprovar inspeção" : "Aprovar inspeção e finalizar"}
          </button>
        )}
      </div>

      {booking.status === "finalizado" && (
        <section className="section">
          <div className="panel">
            <h2>Avaliar</h2>
            <div className="form-grid">
              {["stars", "reliability", "conservation", "communication", "punctuality"].map((key) => (
                <div className="field" key={key}>
                  <label>{key}</label>
                  <input type="number" min="1" max="5" value={review[key]} onChange={(e) => setReview({ ...review, [key]: e.target.value })} />
                </div>
              ))}
            </div>
            <div className="field"><label>Comentário</label><textarea rows="3" value={review.comment} onChange={(e) => setReview({ ...review, comment: e.target.value })} /></div>
            <button className="btn green" onClick={() => run(() => api.review({ ...review, bookingId: booking.id, targetUserId: booking.ownerUserId, role: "locatário" }))}>Enviar avaliação</button>
          </div>
        </section>
      )}
    </div>
  );
}
