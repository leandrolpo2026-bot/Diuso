import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../auth.jsx";

const empty = {
  name: "",
  email: "",
  phone: "",
  cpf: "",
  birthDate: "",
  address: "",
  city: "",
  neighborhood: "",
  documentType: "RG",
  documentNumber: "",
  password: ""
};

function onlyDigits(value) {
  return String(value || "").replace(/\D/g, "");
}

function formatCpf(value) {
  const digits = onlyDigits(value).slice(0, 11);
  if (digits.length <= 3) return digits;
  if (digits.length <= 6) return `${digits.slice(0, 3)}.${digits.slice(3)}`;
  if (digits.length <= 9) return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6)}`;
  return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9)}`;
}

function isAdult(birthDate) {
  if (!birthDate) return false;
  const birth = new Date(`${birthDate}T00:00:00`);
  if (Number.isNaN(birth.getTime())) return false;
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) age -= 1;
  return age >= 18;
}

function maxAdultBirthDate() {
  const date = new Date();
  date.setFullYear(date.getFullYear() - 18);
  return date.toISOString().slice(0, 10);
}

export default function Register() {
  const { setSession } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const next = new URLSearchParams(location.search).get("next") || "/conta";
  const [form, setForm] = useState(empty);
  const [documentPhoto, setDocumentPhoto] = useState(null);
  const [preview, setPreview] = useState("");
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);

  function set(key, value) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function onDoc(e) {
    const file = e.target.files?.[0] || null;
    setDocumentPhoto(file);
    setPreview(file ? URL.createObjectURL(file) : "");
  }

  async function submit(e) {
    e.preventDefault();
    setError("");
    const missing = Object.entries(form).filter(([, value]) => !String(value || "").trim());
    if (missing.length) {
      setError("Preencha todos os dados pessoais.");
      return;
    }
    if (onlyDigits(form.cpf).length !== 11) {
      setError("Informe um CPF com 11 dígitos.");
      return;
    }
    if (!isAdult(form.birthDate)) {
      setError("O cadastro é permitido apenas para maiores de 18 anos.");
      return;
    }
    if (!onlyDigits(form.documentNumber)) {
      setError("Informe o número do documento apenas com números.");
      return;
    }
    if (!documentPhoto) {
      setError("Envie a foto do documento.");
      return;
    }
    setSending(true);
    try {
      const session = await api.register({ ...form, documentPhoto });
      setSession(session);
      if (next && next !== "/conta") sessionStorage.setItem("diuso_next", next);
      navigate("/criar-senha");
    } catch (err) {
      setError(err.message);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="shell" style={{ padding: "32px 0 50px", maxWidth: 820 }}>
      <h1>Criar perfil DIUSO</h1>
      <p style={{ color: "var(--muted)" }}>
        Você pode navegar sem cadastro. Para alugar, precisamos dos seus dados e da foto do documento.
      </p>
      <form className="panel" style={{ marginTop: 18 }} onSubmit={submit}>
        {error && <div className="alert">{error}</div>}
        <div className="form-grid">
          <div className="field" style={{ gridColumn: "1 / -1" }}>
            <label>Nome completo *</label>
            <input value={form.name} onChange={(e) => set("name", e.target.value)} required />
          </div>
          <div className="field">
            <label>E-mail *</label>
            <input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} required />
          </div>
          <div className="field">
            <label>Telefone *</label>
            <input value={form.phone} onChange={(e) => set("phone", e.target.value)} required />
          </div>
          <div className="field">
            <label>CPF *</label>
            <input
              value={form.cpf}
              onChange={(e) => set("cpf", formatCpf(e.target.value))}
              inputMode="numeric"
              autoComplete="off"
              maxLength={14}
              placeholder="000.000.000-00"
              required
            />
          </div>
          <div className="field">
            <label>Data de nascimento *</label>
            <input
              type="date"
              value={form.birthDate}
              onChange={(e) => set("birthDate", e.target.value)}
              max={maxAdultBirthDate()}
              required
            />
          </div>
          <div className="field" style={{ gridColumn: "1 / -1" }}>
            <label>Rua/Avenida *</label>
            <input value={form.address} onChange={(e) => set("address", e.target.value)} required />
          </div>
          <div className="field">
            <label>Cidade *</label>
            <input value={form.city} onChange={(e) => set("city", e.target.value)} required />
          </div>
          <div className="field">
            <label>Bairro *</label>
            <input value={form.neighborhood} onChange={(e) => set("neighborhood", e.target.value)} required />
          </div>
          <div className="field">
            <label>Tipo de documento *</label>
            <select value={form.documentType} onChange={(e) => set("documentType", e.target.value)} required>
              <option value="RG">RG</option>
              <option value="CNH">CNH</option>
              <option value="Passaporte">Passaporte</option>
            </select>
          </div>
          <div className="field">
            <label>Número do documento *</label>
            <input
              value={form.documentNumber}
              onChange={(e) => set("documentNumber", onlyDigits(e.target.value))}
              inputMode="numeric"
              autoComplete="off"
              required
            />
          </div>
          <div className="field">
            <label>Senha *</label>
            <input type="password" minLength="6" value={form.password} onChange={(e) => set("password", e.target.value)} required />
          </div>
          <div className="field" style={{ gridColumn: "1 / -1" }}>
            <label>Foto do documento *</label>
            <input type="file" accept="image/*" onChange={onDoc} required />
            {preview && <img className="doc-preview" src={preview} alt="Documento" />}
          </div>
        </div>
        <button className="btn green" type="submit" disabled={sending}>
          {sending ? "Criando perfil..." : "Criar perfil e continuar"}
        </button>
        <p style={{ color: "var(--muted)", marginTop: 12 }}>
          Já tem perfil? <Link to={`/entrar?next=${encodeURIComponent(next)}`}>Entrar</Link>
        </p>
      </form>
    </div>
  );
}
