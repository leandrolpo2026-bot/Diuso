import { useEffect, useState } from "react";
import { api } from "../api.js";

const deviceLabel = {
  mobile: "Celular",
  desktop: "Computador",
  tablet: "Tablet",
  bot: "Robo",
  Outro: "Outro"
};

function Bars({ rows, color = "var(--brand)", emptyLabel = "Sem dados no período." }) {
  const list = (rows || []).filter((row) => row.count);
  if (list.length === 0) return <p style={{ color: "var(--muted)" }}>{emptyLabel}</p>;
  const max = Math.max(1, ...list.map((row) => Number(row.count || 0)));
  return (
    <div className="chart-bars">
      {list.map((row) => (
        <div className="chart-bar-row" key={row.label}>
          <span title={row.label}>{row.label}</span>
          <div className="chart-bar-track">
            <div className="chart-bar-fill" style={{ width: `${(Number(row.count) / max) * 100}%`, background: color }} />
          </div>
          <b>{row.count}</b>
        </div>
      ))}
    </div>
  );
}

function Timeline({ rows }) {
  const max = Math.max(1, ...(rows || []).map((row) => row.visits));
  const step = rows.length > 45 ? 10 : rows.length > 20 ? 5 : rows.length > 10 ? 2 : 1;
  return (
    <div className="timeline">
      {rows.map((row, index) => (
        <div className="timeline-col" key={row.date} title={`${row.label}: ${row.visits} acessos · ${row.visitors} visitantes`}>
          <div
            className="timeline-bar"
            style={{ height: `${Math.max(2, (row.visits / max) * 100)}%` }}
            data-empty={row.visits ? undefined : "1"}
          />
          <span className="timeline-tick">{(rows.length - 1 - index) % step === 0 ? row.label : ""}</span>
        </div>
      ))}
    </div>
  );
}

function GeoChart({ rows, color = "var(--brand)", emptyLabel, countLabel = "acessos" }) {
  const list = (rows || []).filter((row) => row.count);
  if (list.length === 0) return <p style={{ color: "var(--muted)" }}>{emptyLabel}</p>;
  const max = Math.max(1, ...list.map((row) => Number(row.count || 0)));
  const total = list.reduce((sum, row) => sum + Number(row.count || 0), 0) || 1;
  return (
    <ul className="geo-list">
      {list.map((row, index) => (
        <li className="geo-row" key={`${row.label}-${index}`}>
          <span className="geo-pos">{index + 1}</span>
          <div className="geo-body">
            <div className="geo-head">
              <span className="geo-name">{row.label}</span>
              <span className="geo-count">
                {row.count} {countLabel} · {Math.round((Number(row.count) / total) * 1000) / 10}%
              </span>
            </div>
            <div className="chart-bar-track">
              <div className="chart-bar-fill" style={{ width: `${(Number(row.count) / max) * 100}%`, background: color }} />
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}

function searchTrendSummary(topSearches, searchStats) {
  const top = (topSearches || []).slice(0, 3);
  if (!top.length) {
    return "Ainda não há pesquisas no período. Quando as buscas começarem, este resumo destacará os três termos mais procurados e a tendência de demanda.";
  }
  const total = Number(searchStats?.total || 0) || top.reduce((sum, row) => sum + Number(row.count || 0), 0);
  const share = (count) => (total ? Math.round((Number(count) / total) * 1000) / 10 : 0);
  const ranked = top
    .map((row, index) => `${index + 1}º “${row.title || row.label}” (${row.count} buscas, ${share(row.count)}% do volume)`)
    .join("; ");
  const [first, second] = top;
  let trend = " Os três termos lideram a procura e indicam interesse recorrente nesses itens.";
  if (top.length === 1) {
    trend = ` Quase toda a procura gira em torno de “${first.title || first.label}”.`;
  } else if (second && Number(first.count) >= Number(second.count) * 1.5) {
    trend = ` A demanda está concentrada em “${first.title || first.label}”, bem à frente dos demais.`;
  } else if (top.length === 2) {
    trend = ` “${first.title || first.label}” e “${second.title || second.label}” concentram a procura no período.`;
  }
  const zero = Number(searchStats?.zeroResults || 0);
  const zeroNote = zero > 0
    ? ` Há ${zero} busca(s) sem resultado — vale revisar o catálogo desses termos.`
    : "";
  return `Tendência do período: ${ranked}.${trend}${zeroNote}`;
}

function RankTable({ rows, label, countLabel = "Acessos", emptyLabel }) {
  if (!rows?.length) return <p style={{ color: "var(--muted)" }}>{emptyLabel}</p>;
  return (
    <table className="table">
      <thead>
        <tr>
          <th>#</th>
          <th>{label}</th>
          <th>{countLabel}</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((row, index) => (
          <tr key={`${row.itemId || row.label}-${index}`}>
            <td>{index + 1}</td>
            <td>{row.title || row.label}</td>
            <td><strong>{row.count}</strong></td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default function AnalyticsDashboard() {
  const [days, setDays] = useState(30);
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    api.analytics(days)
      .then((res) => { if (active) setData(res); })
      .catch((err) => { if (active) setError(err.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [days]);

  const totals = data?.totals || {};
  const funnelMax = Math.max(1, ...(data?.funnel || []).map((f) => f.count));

  return (
    <>
      <div className="analytics-toolbar">
        <div>
          <h2>Leitura de acessos</h2>
          <p style={{ color: "var(--muted)", margin: "4px 0 0" }}>
            Registro de visitas, origem, buscas, itens vistos e curtidos. Atualizado em {data ? new Date(data.generatedAt).toLocaleString("pt-BR") : "—"}.
          </p>
          <p style={{ color: "var(--muted)", margin: "4px 0 0", fontSize: "var(--fs-xs)" }}>
            Localizacao aproximada estimada por IP (cidade/regiao), sem GPS. IPs aparecem mascarados.
          </p>
        </div>
        <div className="analytics-actions">
          <div className="chips">
            {[7, 30, 90, 180].map((value) => (
              <button key={value} type="button" className={`chip ${days === value ? "on" : ""}`} onClick={() => setDays(value)}>
                {value} dias
              </button>
            ))}
          </div>
          <a className="btn green" href={api.analyticsExportUrl(days)} download>
            Exportar relatorio em Excel
          </a>
        </div>
      </div>

      {error && <div className="alert">{error}</div>}
      {loading && !data && <div className="panel empty-state">Carregando acessos...</div>}

      {data && (
        <>
          <div className="dash">
            <div className="dash-card"><span>Acessos no período</span><strong>{totals.visits}</strong><div style={{ color: "var(--muted)" }}>{totals.visitsTotal} no total</div></div>
            <div className="dash-card"><span>Visitantes unicos</span><strong>{totals.uniqueVisitors}</strong><div style={{ color: "var(--muted)" }}>{totals.newVisitors} novos · {totals.returningVisitors} recorrentes</div></div>
            <div className="dash-card"><span>Hoje</span><strong>{totals.today}</strong></div>
            <div className="dash-card"><span>Ultimos 7 dias</span><strong>{totals.last7}</strong></div>
            <div className="dash-card"><span>Acessos por visitante</span><strong>{totals.viewsPerVisitor}</strong></div>
            <div className="dash-card"><span>Anúncios vistos</span><strong>{totals.views}</strong></div>
            <div className="dash-card"><span>Buscas</span><strong>{totals.searches}</strong></div>
            <div className="dash-card"><span>Itens curtidos</span><strong>{totals.likes}</strong></div>
            <div className="dash-card"><span>Cadastros</span><strong>{totals.registrations}</strong></div>
            <div className="dash-card"><span>Logins</span><strong>{totals.logins}</strong></div>
            <div className="dash-card"><span>Reservas solicitadas</span><strong>{totals.bookings}</strong></div>
            <div className="dash-card"><span>Acessos de robo</span><strong>{totals.botVisits}</strong><div style={{ color: "var(--muted)" }}>{totals.humanVisits} humanos</div></div>
          </div>

          <div className="panel">
            <h3>Acessos por dia</h3>
            <Timeline rows={data.timeline || []} />
          </div>

          <div className="chart-grid">
            <div className="panel">
              <h3>Funil de conversao</h3>
              <div className="funnel">
                {(data.funnel || []).map((step) => (
                  <div className="funnel-row" key={step.id}>
                    <span>{step.label}</span>
                    <div className="chart-bar-track">
                      <div className="chart-bar-fill" style={{ width: `${(step.count / funnelMax) * 100}%`, background: "var(--brand)" }} />
                    </div>
                    <b>{step.count}</b>
                  </div>
                ))}
              </div>
              <p style={{ color: "var(--muted)", marginTop: 10, fontSize: "var(--fs-xs)" }}>
                Vistas por reserva: {totals.viewToBooking}% · Acessos por reserva: {totals.visitToBooking}%
              </p>
            </div>
            <div className="panel">
              <h3>Dispositivos</h3>
              <Bars rows={(data.devices || []).map((d) => ({ label: deviceLabel[d.label] || d.label, count: d.count }))} />
              <h3 style={{ marginTop: 18 }}>Navegadores</h3>
              <Bars rows={data.browsers} color="var(--navy)" />
            </div>
            <div className="panel">
              <h3>Sistemas operacionais</h3>
              <Bars rows={data.operatingSystems} color="#0ea5e9" />
              <h3 style={{ marginTop: 18 }}>Horarios de pico</h3>
              <Bars rows={(data.byHour || []).filter((h) => h.count)} color="#d97706" emptyLabel="Sem acessos registrados." />
            </div>
            <div className="panel">
              <h3>Origem do acesso</h3>
              <Bars rows={data.sources} color="#64748b" />
              <h3 style={{ marginTop: 18 }}>Paginas mais visitadas</h3>
              <Bars rows={(data.pages || []).slice(0, 12)} />
            </div>
          </div>

          <section className="section">
            <div className="section-head">
              <div>
                <h2>De onde estao acessando</h2>
                <p className="section-lead">
                  Localizacao aproximada por IP. {data.geography?.located || 0} acessos localizados
                  {data.geography?.unknown ? ` · ${data.geography.unknown} sem localizacao (rede local ou privada)` : ""}.
                </p>
              </div>
            </div>
            <div className="geo-grid">
              <div className="panel geo-panel">
                <h3>Por pais</h3>
                <GeoChart rows={data.geography?.countries} color="#0f766e" emptyLabel="Nenhum acesso localizado no período." />
              </div>
              <div className="panel geo-panel">
                <h3>Por estado / regiao</h3>
                <GeoChart rows={data.geography?.regions} color="#d97706" emptyLabel="Nenhum estado identificado." />
              </div>
              <div className="panel geo-panel">
                <h3>Por cidade</h3>
                <GeoChart rows={data.geography?.cities} color="#0ea5e9" emptyLabel="Nenhuma cidade identificada." />
              </div>
            </div>
            <div className="panel" style={{ marginTop: "var(--sp-4)" }}>
              <h3>Provedores de internet</h3>
              <GeoChart rows={data.geography?.networks} color="#64748b" emptyLabel="Nenhum provedor identificado." />
            </div>
          </section>

          <section className="section">
            <div className="section-head"><h2>Pesquisas</h2></div>
            <div className="dash">
              <div className="dash-card"><span>Buscas registradas</span><strong>{data.searchStats?.total || 0}</strong></div>
              <div className="dash-card"><span>Termos unicos</span><strong>{data.searchStats?.uniqueTerms || 0}</strong></div>
              <div className="dash-card"><span>Sem resultado</span><strong>{data.searchStats?.zeroResults || 0}</strong></div>
              <div className="dash-card"><span>Media de resultados</span><strong>{data.searchStats?.avgResults || 0}</strong></div>
            </div>
            <div className="panel insight-card">
              <h3>Resumo de tendência</h3>
              <p>{searchTrendSummary(data.topSearches, data.searchStats)}</p>
            </div>
            <div className="chart-grid">
              <div className="panel">
                <h3>Itens mais pesquisados</h3>
                <RankTable rows={data.topSearches} label="Termo" countLabel="Buscas" emptyLabel="Nenhuma busca no período." />
              </div>
              <div className="panel">
                <h3>Cidades mais buscadas</h3>
                <RankTable rows={data.topLocations} label="Cidade / bairro" countLabel="Buscas" emptyLabel="Nenhuma busca por local." />
              </div>
            </div>
          </section>

          <section className="section">
            <div className="section-head"><h2>Catalogo</h2></div>
            <div className="chart-grid">
              <div className="panel">
                <h3>Anúncios mais vistos</h3>
                <RankTable rows={data.topItems} label="Anúncio" countLabel="Visualizações" emptyLabel="Nenhuma visualizacao no período." />
              </div>
              <div className="panel">
                <h3>Itens mais curtidos</h3>
                <RankTable rows={data.topLiked} label="Anúncio" countLabel="Curtidas" emptyLabel="Nenhuma curtida no período." />
              </div>
              <div className="panel">
                <h3>Categorias mais procuradas</h3>
                <Bars rows={data.topCategories} color="#14b8a6" emptyLabel="Sem categorias no período." />
              </div>
              <div className="panel">
                <h3>Eventos registrados</h3>
                <Bars rows={data.events} color="#312e81" emptyLabel="Sem eventos no período." />
              </div>
            </div>
          </section>

          <section className="section">
            <div className="section-head"><h2>Acessos recentes</h2></div>
            <div className="panel" style={{ overflowX: "auto" }}>
              <table className="table">
                <thead>
                  <tr>
                    <th>Quando</th>
                    <th>De onde</th>
                    <th>Pagina</th>
                    <th>Dispositivo</th>
                    <th>Navegador</th>
                    <th>Sistema</th>
                    <th>Origem</th>
                    <th>Provedor</th>
                    <th>IP</th>
                    <th>Visitante</th>
                  </tr>
                </thead>
                <tbody>
                  {(data.recent || []).map((visit, index) => (
                    <tr key={`${visit.at}-${index}`}>
                      <td>{new Date(visit.at).toLocaleString("pt-BR")}</td>
                      <td>{visit.location || "Não identificado"}</td>
                      <td>{visit.path}</td>
                      <td>{deviceLabel[visit.device] || visit.device}</td>
                      <td>{visit.browser}</td>
                      <td>{visit.os}</td>
                      <td>{visit.source}</td>
                      <td>{visit.network || "—"}</td>
                      <td>{visit.ip || "—"}</td>
                      <td>{visit.visitorId ? `…${visit.visitorId}` : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {(!data.recent || data.recent.length === 0) && <p style={{ color: "var(--muted)" }}>Nenhum acesso registrado ainda.</p>}
            </div>
          </section>
        </>
      )}
    </>
  );
}
