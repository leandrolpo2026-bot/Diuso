import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../auth.jsx";
import { renterLevelMeta } from "../visuals.js";
import { isMaster, isStaff } from "../roles.js";

function isAdult(birthDate) {
  if (!birthDate) return false;
  const birth = new Date(`${birthDate}T00:00:00`);
  if (Number.isNaN(birth.getTime())) return false;
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) age -= 1;
  return age >= 18;
}

function maxAdultBirthDate() {
  const date = new Date();
  date.setFullYear(date.getFullYear() - 18);
  return date.toISOString().slice(0, 10);
}

const rentProcess = [
  {
    id: "buscar",
    title: "Encontre",
    text: "Busque por nome, cidade ou categoria e abra o item.",
    art: "search"
  },
  {
    id: "perfil",
    title: "Cadastre",
    text: "Crie o perfil com CPF, endereco e foto do documento.",
    art: "id"
  },
  {
    id: "reservar",
    title: "Reserve",
    text: "Escolha as datas, confira valores e aceite o contrato.",
    art: "calendar"
  },
  {
    id: "pagar",
    title: "Pague",
    text: "Pagamento intermediado. Caução não e receita e volta depois.",
    art: "pay"
  },
  {
    id: "receber",
    title: "Receba",
    text: "A entrega e do administrador. Status ate ativo.",
    art: "truck"
  },
  {
    id: "devolver",
    title: "Devolva",
    text: "Use no prazo. Inspecao libera a caução antes do fim.",
    art: "return"
  },
  {
    id: "niveis",
    title: "Nível",
    text: "Bronze 100%, Prata 50%, Ouro isento, a partir da 3a paga.",
    art: "levels"
  }
];

const ownerProcess = [
  {
    id: "anunciar",
    title: "Anuncie",
    text: "Formulario com no mínimo 6 fotos do item parado.",
    art: "box"
  },
  {
    id: "análise",
    title: "Análise",
    text: "O administrador aprova ou rejeita o anúncio.",
    art: "id"
  },
  {
    id: "catálogo",
    title: "Catalogo",
    text: "Item aprovado entra no catálogo para locação.",
    art: "search"
  }
];

function GuideArt({ type }) {
  return (
    <div className={`guide-art guide-art-${type}`} aria-hidden="true">
      {type === "search" && (
        <>
          <span className="ga-circle" />
          <span className="ga-handle" />
        </>
      )}
      {type === "id" && (
        <>
          <span className="ga-card" />
          <span className="ga-face" />
          <span className="ga-line" />
          <span className="ga-line short" />
        </>
      )}
      {type === "calendar" && (
        <>
          <span className="ga-sheet" />
          <span className="ga-dot d1" />
          <span className="ga-dot d2" />
          <span className="ga-dot d3" />
        </>
      )}
      {type === "pay" && (
        <>
          <span className="ga-wallet" />
          <span className="ga-coin" />
        </>
      )}
      {type === "truck" && (
        <>
          <span className="ga-cabin" />
          <span className="ga-body" />
          <span className="ga-wheel w1" />
          <span className="ga-wheel w2" />
        </>
      )}
      {type === "return" && (
        <>
          <span className="ga-box" />
          <span className="ga-arrow" />
        </>
      )}
      {type === "levels" && (
        <>
          <span className="ga-bar b1" />
          <span className="ga-bar b2" />
          <span className="ga-bar b3" />
        </>
      )}
      {type === "box" && (
        <>
          <span className="ga-crate" />
          <span className="ga-lid" />
        </>
      )}
    </div>
  );
}

export default function Menu() {
  const { user, logout, setUser } = useAuth();
  const navigate = useNavigate();
  const admin = isStaff(user);
  const master = isMaster(user);

  const [profile, setProfile] = useState({
    name: "",
    email: "",
    phone: "",
    birthDate: "",
    address: "",
    city: "",
    neighborhood: ""
  });
  const [profileMsg, setProfileMsg] = useState("");
  const [profileErr, setProfileErr] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);

  const [passwords, setPasswords] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });
  const [passMsg, setPassMsg] = useState("");
  const [passErr, setPassErr] = useState("");
  const [savingPass, setSavingPass] = useState(false);
  const [openForm, setOpenForm] = useState("");

  useEffect(() => {
    if (!user) return;
    setProfile({
      name: user.name || "",
      email: user.email || "",
      phone: user.phone || "",
      birthDate: user.birthDate || "",
      address: user.address || "",
      city: user.city || "",
      neighborhood: user.neighborhood || ""
    });
  }, [user]);

  async function leave() {
    await logout();
    navigate("/");
  }

  function setField(key, value) {
    setProfile((prev) => ({ ...prev, [key]: value }));
  }

  async function saveProfile(e) {
    e.preventDefault();
    setProfileErr("");
    setProfileMsg("");
    const missing = Object.entries(profile).filter(([, value]) => !String(value || "").trim());
    if (missing.length) {
      setProfileErr("Preencha todos os dados pessoais.");
      return;
    }
    if (!isAdult(profile.birthDate)) {
      setProfileErr("O cadastro é permitido apenas para maiores de 18 anos.");
      return;
    }
    setSavingProfile(true);
    try {
      const data = await api.updateProfile(profile);
      setUser(data.user);
      setProfileMsg("Perfil atualizado.");
    } catch (err) {
      setProfileErr(err.message);
    } finally {
      setSavingProfile(false);
    }
  }

  async function savePassword(e) {
    e.preventDefault();
    setPassErr("");
    setPassMsg("");
    if (!passwords.currentPassword || !passwords.newPassword || !passwords.confirmPassword) {
      setPassErr("Preencha senha atual, nova senha e confirmação.");
      return;
    }
    if (passwords.newPassword.length < 6) {
      setPassErr("A senha precisa ter no mínimo 6 caracteres.");
      return;
    }
    if (passwords.newPassword !== passwords.confirmPassword) {
      setPassErr("A confirmação não confere com a nova senha.");
      return;
    }
    setSavingPass(true);
    try {
      const data = await api.changePassword({
        currentPassword: passwords.currentPassword,
        newPassword: passwords.newPassword
      });
      if (data.user) setUser(data.user);
      setPasswords({ currentPassword: "", newPassword: "", confirmPassword: "" });
      setPassMsg("Senha alterada.");
    } catch (err) {
      setPassErr(err.message);
    } finally {
      setSavingPass(false);
    }
  }

  if (!user) {
    return (
      <div className="shell" style={{ padding: "32px 0 50px" }}>
        <h1>Menu</h1>
        <div className="panel" style={{ marginTop: 18 }}>
          <p>Entre na conta para ver suas funcionalidades.</p>
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <Link className="btn green" to="/entrar?next=/menu">Entrar</Link>
            <Link className="ghost" to="/cadastrar?next=/menu">Criar perfil</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="shell" style={{ padding: "32px 0 50px" }}>
      <h1>Menu</h1>
      <p style={{ color: "var(--muted)" }}>
        {user.name}
        {master ? " · Administrador master" : admin ? " · Administrador" : ` · Nível ${renterLevelMeta[user.renterLevel || "bronze"]?.label || "Bronze"}`}
      </p>

      {admin && (
        <div className="menu-grid">
          <Link className="menu-card" to="/admin">
            <strong>Painel</strong>
            <span>{master ? "Operação, dashboard financeiro e configurações" : "Pedidos, anúncios, usuários e ocorrências"}</span>
          </Link>
        </div>
      )}

      <section className="section" style={{ paddingTop: 28 }}>
        <div className="section-head">
          <h2>Fluxo de utilização</h2>
        </div>
        <div className="process-board">
          <div className="process-terminal">Início</div>
          <div className="process-down" aria-hidden="true" />
          <div className="process-decision">
            <span>Alugar ou anunciar?</span>
          </div>
          <div className="process-split" aria-hidden="true">
            <span>Alugar</span>
            <span>Anunciar</span>
          </div>
          <div className="process-lanes">
            <div className="process-lane">
              <ol className="process-steps">
                {rentProcess.map((step, index) => (
                  <li key={step.id}>
                    {index > 0 && <span className="process-arrow" aria-hidden="true" />}
                    <article className="process-node">
                      <GuideArt type={step.art} />
                      <div className="process-num">{index + 1}</div>
                      <strong>{step.title}</strong>
                      <p>{step.text}</p>
                    </article>
                  </li>
                ))}
              </ol>
            </div>
            <div className="process-lane">
              <ol className="process-steps">
                {ownerProcess.map((step, index) => (
                  <li key={step.id}>
                    {index > 0 && <span className="process-arrow" aria-hidden="true" />}
                    <article className="process-node">
                      <GuideArt type={step.art} />
                      <div className="process-num">{index + 1}</div>
                      <strong>{step.title}</strong>
                      <p>{step.text}</p>
                    </article>
                  </li>
                ))}
              </ol>
            </div>
          </div>
          <div className="process-down" aria-hidden="true" />
          <div className="process-terminal end">Fim</div>
        </div>
      </section>

      <div className="menu-access">
        <button
          className={`btn ${openForm === "profile" ? "green" : "ghost-btn"}`}
          type="button"
          onClick={() => setOpenForm(openForm === "profile" ? "" : "profile")}
        >
          Editar perfil
        </button>
        <button
          className={`btn ${openForm === "password" ? "green" : "ghost-btn"}`}
          type="button"
          onClick={() => setOpenForm(openForm === "password" ? "" : "password")}
        >
          Alterar senha
        </button>
      </div>

      {openForm === "profile" && (
        <form className="panel" style={{ marginTop: 16 }} onSubmit={saveProfile}>
          <h2>Editar perfil</h2>
          <p style={{ color: "var(--muted)", margin: "6px 0 14px" }}>
            Atualize nome, contato e endereco. CPF e documento não mudam por aqui.
          </p>
          {profileErr && <div className="alert">{profileErr}</div>}
          {profileMsg && <div className="ok">{profileMsg}</div>}
          <div className="form-grid">
            <div className="field" style={{ gridColumn: "1 / -1" }}>
              <label>Nome completo *</label>
              <input value={profile.name} onChange={(e) => setField("name", e.target.value)} required />
            </div>
            <div className="field">
              <label>E-mail *</label>
              <input type="email" value={profile.email} onChange={(e) => setField("email", e.target.value)} required />
            </div>
            <div className="field">
              <label>Telefone *</label>
              <input value={profile.phone} onChange={(e) => setField("phone", e.target.value)} required />
            </div>
            <div className="field">
              <label>Data de nascimento *</label>
              <input
                type="date"
                value={profile.birthDate}
                onChange={(e) => setField("birthDate", e.target.value)}
                max={maxAdultBirthDate()}
                required
              />
            </div>
            <div className="field" style={{ gridColumn: "1 / -1" }}>
              <label>Rua/Avenida *</label>
              <input value={profile.address} onChange={(e) => setField("address", e.target.value)} required />
            </div>
            <div className="field">
              <label>Cidade *</label>
              <input value={profile.city} onChange={(e) => setField("city", e.target.value)} required />
            </div>
            <div className="field">
              <label>Bairro *</label>
              <input value={profile.neighborhood} onChange={(e) => setField("neighborhood", e.target.value)} required />
            </div>
          </div>
          <div className="menu-form-actions">
            <button className="btn green" type="submit" disabled={savingProfile}>
              {savingProfile ? "Salvando..." : "Salvar perfil"}
            </button>
            <button className="btn ghost-btn" type="button" onClick={() => setOpenForm("")}>Fechar</button>
          </div>
        </form>
      )}

      {openForm === "password" && (
        <form className="panel" style={{ marginTop: 16, maxWidth: 520 }} onSubmit={savePassword}>
          <h2>Alterar senha</h2>
          <p style={{ color: "var(--muted)", margin: "6px 0 14px" }}>
            Informe a senha atual e a nova senha com no mínimo 6 caracteres.
          </p>
          {passErr && <div className="alert">{passErr}</div>}
          {passMsg && <div className="ok">{passMsg}</div>}
          <div className="field">
            <label>Senha atual *</label>
            <input
              type="password"
              value={passwords.currentPassword}
              onChange={(e) => setPasswords((p) => ({ ...p, currentPassword: e.target.value }))}
              required
            />
          </div>
          <div className="field">
            <label>Nova senha *</label>
            <input
              type="password"
              minLength="6"
              value={passwords.newPassword}
              onChange={(e) => setPasswords((p) => ({ ...p, newPassword: e.target.value }))}
              required
            />
          </div>
          <div className="field">
            <label>Confirmar nova senha *</label>
            <input
              type="password"
              minLength="6"
              value={passwords.confirmPassword}
              onChange={(e) => setPasswords((p) => ({ ...p, confirmPassword: e.target.value }))}
              required
            />
          </div>
          <div className="menu-form-actions">
            <button className="btn green" type="submit" disabled={savingPass}>
              {savingPass ? "Alterando..." : "Alterar senha"}
            </button>
            <button className="btn ghost-btn" type="button" onClick={() => setOpenForm("")}>Fechar</button>
          </div>
        </form>
      )}

      <div style={{ marginTop: 18 }}>
        <button className="btn green" type="button" onClick={leave}>Sair</button>
      </div>
    </div>
  );
}
