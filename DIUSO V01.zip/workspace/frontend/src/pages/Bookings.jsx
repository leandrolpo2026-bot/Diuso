import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import ProofAttach from "../ProofAttach.jsx";
import { compareBookings, formatDate, hasDeposit, localIsoDate, money, nextBookingStatus, nextStatusLabel, prevBookingStatus, statusLegend, statusMeta } from "../visuals.js";

export default function Bookings() {
  const [bookings, setBookings] = useState([]);
  const [sortKey, setSortKey] = useState("period");
  const [sortDir, setSortDir] = useState("asc");
  const [filterDate, setFilterDate] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [lateDialog, setLateDialog] = useState(null);
  const [lateReason, setLateReason] = useState("");
  const [lateError, setLateError] = useState("");

  const today = localIsoDate(0);
  const tomorrow = localIsoDate(1);

  const sortedBookings = useMemo(() => {
    const list = bookings.filter((b) => {
      if (filterStatus && b.status !== filterStatus) return false;
      if (!filterDate) return true;
      return (b.startDate || "") <= filterDate && filterDate <= (b.endDate || "");
    });
    list.sort((a, b) => compareBookings(a, b, sortKey, sortDir));
    return list;
  }, [bookings, sortKey, sortDir, filterDate, filterStatus]);

  function toggleSort(key) {
    if (sortKey === key) setSortDir((current) => (current === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setSortDir("asc");
    }
  }

  function sortMark(key) {
    if (sortKey !== key) return "";
    return sortDir === "asc" ? " ↑" : " ↓";
  }

  async function load() {
    setBookings(await api.bookings());
  }

  useEffect(() => { load().catch(console.error); }, []);

  async function update(id, status) {
    await api.updateBooking(id, status);
    await load();
  }

  function openLate(id) {
    setLateDialog(id);
    setLateReason("");
    setLateError("");
  }

  async function attachPayment(id, file) {
    await api.uploadPaymentProof(id, file);
    await load();
  }

  async function attachRefund(id, file) {
    await api.uploadDepositRefundProof(id, file);
    await load();
  }

  async function confirmLate() {
    const reason = lateReason.trim();
    if (!reason) {
      setLateError("Informe a justificativa do atraso");
      return;
    }
    await api.markLate(lateDialog, 1, reason);
    setLateDialog(null);
    setLateReason("");
    setLateError("");
    await load();
  }

  return (
    <div className="shell" style={{ padding: "32px 0 50px" }}>
      <h1>Aluguéis DIUSO</h1>
      <p style={{ color: "var(--muted)" }}>Acompanhe pedidos, confirme, entregue e encerre devolucoes.</p>
      <div className="panel" style={{ marginTop: 18, overflowX: "auto" }}>
        <div className="table-toolbar">
          <div className="status-legend">
            {statusLegend.map((key) => {
              const meta = statusMeta[key];
              return (
                <button
                  type="button"
                  key={key}
                  className={`status ${meta.tone} ${filterStatus === key ? "on" : ""}`}
                  onClick={() => setFilterStatus((current) => (current === key ? "" : key))}
                >
                  {meta.label}
                </button>
              );
            })}
          </div>
          <div className="date-filter">
            <button type="button" className={`chip-mini ${filterDate === today ? "on" : ""}`} onClick={() => setFilterDate(today)}>Hoje</button>
            <button type="button" className={`chip-mini ${filterDate === tomorrow ? "on" : ""}`} onClick={() => setFilterDate(tomorrow)}>Amanhã</button>
            <input type="date" value={filterDate} onChange={(e) => setFilterDate(e.target.value)} />
            {filterDate && (
              <button type="button" className="chip-mini" onClick={() => setFilterDate("")}>Limpar</button>
            )}
          </div>
        </div>
        <table className="table">
          <thead>
            <tr>
              <th><button type="button" className={`sort-head ${sortKey === "item" ? "on" : ""}`} onClick={() => toggleSort("item")}>Item{sortMark("item")}</button></th>
              <th><button type="button" className={`sort-head ${sortKey === "client" ? "on" : ""}`} onClick={() => toggleSort("client")}>Cliente{sortMark("client")}</button></th>
              <th><button type="button" className={`sort-head ${sortKey === "period" ? "on" : ""}`} onClick={() => toggleSort("period")}>Periodo{sortMark("period")}</button></th>
              <th><button type="button" className={`sort-head ${sortKey === "money" ? "on" : ""}`} onClick={() => toggleSort("money")}>Total{sortMark("money")}</button></th>
              <th><button type="button" className={`sort-head ${sortKey === "status" ? "on" : ""}`} onClick={() => toggleSort("status")}>Status{sortMark("status")}</button></th>
              <th><button type="button" className={`sort-head ${sortKey === "refund" ? "on" : ""}`} onClick={() => toggleSort("refund")}>Reembolso caução{sortMark("refund")}</button></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {sortedBookings.map((b) => {
              const meta = statusMeta[b.status] || statusMeta.aguardando_confirmacao;
              const next = nextBookingStatus(b);
              const prev = prevBookingStatus(b);
              return (
                <tr key={b.id}>
                  <td>
                    <Link to={`/item/${b.itemId}`}><strong>{b.item?.title || b.itemId}</strong></Link>
                  </td>
                  <td>
                    {b.renterName}
                    <div style={{ color: "var(--muted)" }}>{b.renterPhone}</div>
                  </td>
                  <td>{formatDate(b.startDate)} {b.startTime || ""} — {formatDate(b.endDate)} {b.endTime || ""}</td>
                  <td>{money(b.total)}</td>
                  <td>
                    <div className="status-cell">
                      <span className={`status ${meta.tone}`}>{meta.label}</span>
                      {b.status === "atrasado" && b.lateReason && <span className="status-desc">{b.lateReason}</span>}
                    </div>
                  </td>
                  <td>
                    {hasDeposit(b) ? (
                      <ProofAttach file={b.depositRefundProof} onFile={(file) => attachRefund(b.id, file)} label="Anexar reembolso" />
                    ) : (
                      <span className="status-desc">Sem caução</span>
                    )}
                  </td>
                  <td>
                    <div className="table-actions">
                      {prev && (
                        <button className="ghost" onClick={() => update(b.id, prev)}>Voltar status</button>
                      )}
                      {next && (
                        <button className="ghost" onClick={() => update(b.id, next)}>
                          {nextStatusLabel[next]}
                        </button>
                      )}
                      {b.status !== "atrasado" && !["finalizado", "cancelado", "reembolsado"].includes(b.status) && (
                        <button className="ghost" onClick={() => openLate(b.id)}>Atrasado</button>
                      )}
                      {b.status !== "cancelado" && b.status !== "finalizado" && (
                        <button className="ghost" onClick={() => update(b.id, "cancelado")}>Cancelar</button>
                      )}
                      <a className="ghost" href={api.serviceOrderUrl(b.id)} target="_blank" rel="noreferrer">Ordem de serviço</a>
                      <a className="btn green" href={api.chargeNoteUrl(b.id)} target="_blank" rel="noreferrer">Nota de cobrança</a>
                      <label className="chip-mini proof-upload">
                        Anexar comprovante
                        <input
                          type="file"
                          accept="image/*,application/pdf"
                          onChange={(e) => {
                            const picked = e.target.files?.[0];
                            if (picked) attachPayment(b.id, picked);
                            e.target.value = "";
                          }}
                        />
                      </label>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {lateDialog && (
        <div className="late-dialog-backdrop" onClick={() => setLateDialog(null)}>
          <div className="late-dialog" onClick={(e) => e.stopPropagation()}>
            <h2>Justificativa do atraso</h2>
            <p style={{ color: "var(--muted)", margin: "8px 0 12px" }}>Obrigatorio para marcar o pedido como atrasado. A descricao aparece na coluna Status.</p>
            <textarea value={lateReason} onChange={(e) => setLateReason(e.target.value)} placeholder="Ex.: locatário não devolveu no horario combinado" />
            {lateError && <div className="alert" style={{ marginTop: 10 }}>{lateError}</div>}
            <div className="late-dialog-actions">
              <button type="button" className="ghost" onClick={() => setLateDialog(null)}>Cancelar</button>
              <button type="button" className="btn green" onClick={confirmLate}>Marcar atrasado</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
