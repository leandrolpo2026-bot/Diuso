import { Link } from "react-router-dom";
import { useAuth } from "../auth.jsx";

export default function Messages() {
  const { user } = useAuth();

  return (
    <div className="shell" style={{ padding: "32px 0 50px" }}>
      <h1>Mensagens</h1>
      <div className="panel empty-state" style={{ marginTop: 18 }}>
        <strong>Em breve.</strong>
        <p>A comunicação organizada dentro da plataforma ainda está em desenvolvimento. Por enquanto, o pedido e o contrato ficam registrados na locação.</p>
        {user ? (
          <Link className="btn green" to="/conta">Ver meus aluguéis</Link>
        ) : (
          <Link className="btn green" to="/entrar?next=/mensagens">Entrar</Link>
        )}
      </div>
    </div>
  );
}
