import { useEffect, useState } from "react";
import { api } from "../api.js";

const emptyForm = { name: "", email: "", password: "", role: "admin" };

export default function StaffPanel({ onMessage }) {
  const [staff, setStaff] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState("");
  const [resetTarget, setResetTarget] = useState(null);
  const [resetPassword, setResetPassword] = useState("");
  const [resetError, setResetError] = useState("");
  const [removeTarget, setRemoveTarget] = useState(null);
  const [removePassword, setRemovePassword] = useState("");
  const [removeError, setRemoveError] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    setStaff(await api.staff());
  }

  useEffect(() => {
    load().catch((err) => setError(err.message));
  }, []);

  function setField(key, value) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function create(e) {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      await api.createStaff(form);
      setForm(emptyForm);
      onMessage?.("Administrador criado.");
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function confirmRemove() {
    const password = removePassword.trim();
    if (!password) {
      setRemoveError("Informe a senha do administrador master.");
      return;
    }
    try {
      await api.removeStaff(removeTarget.id, { password });
      setRemoveTarget(null);
      setRemovePassword("");
      setRemoveError("");
      onMessage?.("Administrador excluído.");
      await load();
    } catch (err) {
      setRemoveError(err.message);
    }
  }

  async function confirmReset() {
    const password = resetPassword.trim();
    if (password.length < 6) {
      setResetError("A senha precisa ter no mínimo 6 caracteres.");
      return;
    }
    try {
      await api.resetStaffPassword(resetTarget.id, { newPassword: password });
      setResetTarget(null);
      setResetPassword("");
      setResetError("");
      onMessage?.(`Senha de ${resetTarget.name} redefinida.`);
      await load();
    } catch (err) {
      setResetError(err.message);
    }
  }

  return (
    <section className="section">
      <div className="section-head">
        <div>
          <h2>Equipe administrativa</h2>
          <p className="section-lead">Somente o administrador master cria, redefine senha e exclui contas admin e master. Conta nova pede senha própria no primeiro acesso. Excluir exige a senha master.</p>
        </div>
      </div>
      {error && <div className="alert">{error}</div>}
      <form className="panel" onSubmit={create} style={{ marginBottom: 18 }}>
        <h3>Novo administrador</h3>
        <div className="form-grid">
          <div className="field">
            <label>Nome</label>
            <input value={form.name} onChange={(e) => setField("name", e.target.value)} required />
          </div>
          <div className="field">
            <label>E-mail</label>
            <input type="email" value={form.email} onChange={(e) => setField("email", e.target.value)} required />
          </div>
          <div className="field">
            <label>Senha inicial</label>
            <input type="password" minLength="6" value={form.password} onChange={(e) => setField("password", e.target.value)} required />
          </div>
          <div className="field">
            <label>Cargo</label>
            <select value={form.role} onChange={(e) => setField("role", e.target.value)}>
              <option value="admin">Administrador</option>
              <option value="master">Administrador master</option>
            </select>
          </div>
        </div>
        <button className="btn green" type="submit" disabled={saving}>
          {saving ? "Criando..." : "Criar administrador"}
        </button>
      </form>
      <div className="panel" style={{ overflowX: "auto" }}>
        <table className="table">
          <thead>
            <tr>
              <th>Nome</th>
              <th>E-mail</th>
              <th>Cargo</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {staff.map((member) => (
              <tr key={member.id}>
                <td><strong>{member.name}</strong></td>
                <td>{member.email}</td>
                <td>
                  {member.role === "master" ? "Administrador master" : "Administrador"}
                  {member.mustChangePassword ? <div style={{ color: "var(--muted)" }}>Pendente criar senha</div> : null}
                </td>
                <td>
                  <div className="table-actions">
                    <button className="ghost" type="button" onClick={() => { setResetTarget(member); setResetPassword(""); setResetError(""); }}>
                      Resetar senha
                    </button>
                    <button className="ghost" type="button" onClick={() => { setRemoveTarget(member); setRemovePassword(""); setRemoveError(""); }}>Excluir</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {staff.length === 0 && <p style={{ color: "var(--muted)" }}>Nenhum administrador cadastrado.</p>}
      </div>
      {removeTarget && (
        <div className="late-dialog-backdrop" onClick={() => setRemoveTarget(null)}>
          <div className="late-dialog" onClick={(e) => e.stopPropagation()}>
            <h2>Excluir administrador</h2>
            <p style={{ color: "var(--muted)", margin: "8px 0 12px" }}>
              Excluir {removeTarget.name}. Informe a senha do administrador master para confirmar.
            </p>
            <input type="password" value={removePassword} onChange={(e) => setRemovePassword(e.target.value)} placeholder="Senha master" autoFocus />
            {removeError && <div className="alert" style={{ marginTop: 10 }}>{removeError}</div>}
            <div className="late-dialog-actions">
              <button type="button" className="ghost" onClick={() => setRemoveTarget(null)}>Cancelar</button>
              <button type="button" className="btn green" onClick={confirmRemove}>Excluir perfil</button>
            </div>
          </div>
        </div>
      )}
      {resetTarget && (
        <div className="late-dialog-backdrop" onClick={() => setResetTarget(null)}>
          <div className="late-dialog" onClick={(e) => e.stopPropagation()}>
            <h2>Resetar senha</h2>
            <p style={{ color: "var(--muted)", margin: "8px 0 12px" }}>
              Nova senha para {resetTarget.name}. As sessoes abertas dessa conta serao encerradas.
            </p>
            <input type="password" minLength="6" value={resetPassword} onChange={(e) => setResetPassword(e.target.value)} placeholder="Nova senha" autoFocus />
            {resetError && <div className="alert" style={{ marginTop: 10 }}>{resetError}</div>}
            <div className="late-dialog-actions">
              <button type="button" className="ghost" onClick={() => setResetTarget(null)}>Cancelar</button>
              <button type="button" className="btn green" onClick={confirmReset}>Salvar senha</button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
