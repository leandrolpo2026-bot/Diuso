import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../auth.jsx";
import { availabilityLabel, formatDate, money, palettes, renterLevelMeta } from "../visuals.js";
import { isStaff } from "../roles.js";

export default function ItemPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [item, setItem] = useState(null);
  const [quote, setQuote] = useState(null);
  const [settings, setSettings] = useState(null);
  const [rulesOpen, setRulesOpen] = useState(false);
  const [photoIndex, setPhotoIndex] = useState(0);
  const [fav, setFav] = useState(false);
  const [form, setForm] = useState({
    startDate: "",
    endDate: "",
    startTime: "08:00",
    endTime: "18:00",
    note: "",
    delivery: true,
    contractAccepted: false
  });
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");

  useEffect(() => {
    setPhotoIndex(0);
    api.item(id).then(setItem).catch(() => setError("Item não encontrado"));
    api.settings().then(setSettings).catch(() => {});
    api.favorites().then((list) => setFav(list.some((i) => i.id === id))).catch(() => {});
  }, [id]);

  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);

  useEffect(() => {
    if (!form.startDate || !form.endDate || form.endDate < form.startDate) {
      setQuote(null);
      return;
    }
    api.quote({ itemId: id, startDate: form.startDate, endDate: form.endDate, delivery: true })
      .then(setQuote)
      .catch(() => setQuote(null));
  }, [id, form.startDate, form.endDate, form.delivery]);

  const [c1, c2] = palettes[item?.category] || ["#0f766e", "#134e4a"];
  const next = `/item/${id}`;

  async function toggleFav() {
    if (fav) await api.removeFavorite(id);
    else await api.addFavorite(id);
    setFav(!fav);
  }

  async function submit(e) {
    e.preventDefault();
    setError("");
    setOk("");
    if (!user) {
      navigate(`/cadastrar?next=${encodeURIComponent(next)}`);
      return;
    }
    if (form.startDate && form.endDate && form.endDate < form.startDate) {
      setError("A data de devolução deve ser igual ou posterior a data de retirada.");
      return;
    }
    if (form.startDate && form.endDate && form.startDate === form.endDate && form.endTime <= form.startTime) {
      setError("O horário de devolução deve ser depois do horário de retirada.");
      return;
    }
    try {
      const booking = await api.createBooking({ itemId: id, ...form, delivery: true });
      setOk(`Reserva criada. Locação ${money(booking.rentalDue)}. Caução retida ${money(booking.deposit)}.`);
      setTimeout(() => navigate(`/locação/${booking.id}`), 700);
    } catch (err) {
      setError(err.message);
    }
  }

  if (!item) return <div className="shell" style={{ padding: 40 }}>{error || "Carregando..."}</div>;

  const paused = item.listingStatus === "pausado" || item.availability === "pausado";
  const unavailable = paused || (item.availability && item.availability !== "disponível");
  const photos = item.photos?.length ? item.photos : [];
  const renterLevel = user?.renterLevel || "bronze";
  const renterLevelLabel = renterLevelMeta[renterLevel]?.label || "Bronze";
  const depositRate = renterLevel === "ouro" ? 0 : renterLevel === "prata" ? 0.5 : 1;
  const depositDue = Number(item.suggestedDeposit || 0) * depositRate;

  return (
    <div className="shell layout">
      <div>
        {photos.length > 0 ? (
          <div className="item-photos">
            <img src={photos[photoIndex]?.url || photos[photoIndex]} alt={item.title} />
            {photos.length > 1 && (
              <div className="item-thumbs">
                {photos.map((p, i) => (
                  <button
                    type="button"
                    key={p.url || i}
                    className={`item-thumb${i === photoIndex ? " on" : ""}`}
                    onClick={() => setPhotoIndex(i)}
                    aria-label={`Ver foto ${i + 1}`}
                  >
                    <img src={p.url || p} alt="" />
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="art" style={{ background: `linear-gradient(135deg, ${c1}, ${c2})` }}>
            {item.title}
          </div>
        )}
        <div style={{ marginTop: 18 }}>
          <span className="badge">{item.condition} · {item.rating} · {availabilityLabel[item.availability] || item.availability}</span>
          {item.protectionLabel && <span className="badge" style={{ marginLeft: 8 }}>{item.protectionLabel}</span>}
          <h1 style={{ margin: "12px 0 8px" }}>{item.title}</h1>
          <p style={{ color: "var(--brand)", fontWeight: 700 }}>{item.rating} · {item.rentalCount || 0} locações</p>
          <p style={{ color: "var(--muted)" }}>{item.description}</p>
          <div className="specs">
            {(item.specs || []).map((s) => <span className="spec" key={s}>{s}</span>)}
          </div>
          <div className="trust-grid" style={{ marginTop: 18 }}>
            <article className="trust-card">
              <strong>Localizacao</strong>
              <p>
                {isStaff(user) && (item.street || item.pickupAddress)
                  ? (item.pickupAddress || [item.street, item.streetNumber, item.neighborhood, item.city].filter(Boolean).join(", "))
                  : `${item.city}${item.neighborhood ? `, ${item.neighborhood}` : ""}`}
              </p>
            </article>
            {isStaff(user) && item.owner ? (
              <article className="trust-card"><strong>Proprietário</strong><p>{item.owner} · {item.rentalCount || 0} locações</p></article>
            ) : (
              <article className="trust-card"><strong>Locações</strong><p>{item.rentalCount || 0} locações concluídas</p></article>
            )}
            <article className="trust-card"><strong>Retirada / entrega</strong><p>Entrega pela DIUSO · {money(settings?.deliveryFee ?? item.deliveryFee)}</p></article>
            <article className="trust-card"><strong>Caução</strong><p>Você é um usuário nível {renterLevelLabel}, pagará {money(depositDue)}.</p></article>
          </div>
          {isStaff(user) && item.estimatedValue != null ? (
            <p>Valor estimado do produto: {money(item.estimatedValue)}</p>
          ) : null}
          <p>Diária {money(item.pricePerDay)} · Semanal {money(item.weeklyPrice)} · Mensal {money(item.monthlyPrice)}</p>
          <div className="menu-access" style={{ marginTop: 8 }}>
            <button className="ghost" onClick={toggleFav}>{fav ? "Remover dos favoritos" : "Salvar nos favoritos"}</button>
            <button className="ghost" type="button" onClick={() => setRulesOpen((v) => !v)}>Ver regras da locação</button>
          </div>
          {rulesOpen && (
            <div className="calc" style={{ marginTop: 12 }}>
              <p><strong>Uso:</strong> {item.usageRules}</p>
              <p><strong>Atraso na devolução:</strong> tolerância de {settings?.lateToleranceHours || 2}h. Depois, diária adicional de {settings?.lateFeeMultiplier || 1.5}x.</p>
              <p><strong>Taxa de cancelamento de solicitação:</strong> Cancelamentos acima de 48 horas da retirada, será devolvido 100% do valor da reserva. Cancelamentos entre 24–48 horas antes da retirada, será devolvido 90% do valor da reserva. Cancelamentos em menos de 24 horas antes da retirada, será devolvido 70%. Após o início da locação, não será reembolsado o período iniciado. Cancelar com menos de 24 horas coloca a conta em quarentena até reavaliação do administrador.</p>
              <p><strong>Quem precisa dar caução:</strong> Usuários Bronze pagam 100% do caução. Prata, pagam 50%. Na categoria Ouro você é isento de pagamento de caução. O caução é um valor temporário pago à DIUSO no início da locação e devolvido após inspeção e devolução do produto locado.</p>
            </div>
          )}
          {item.bookedRanges?.length > 0 && (
            <div>
              <h3 style={{ margin: "18px 0 8px" }}>Datas indisponiveis</h3>
              {item.bookedRanges.map((r) => (
                <div key={`${r.start}-${r.end}`} style={{ color: "var(--muted)" }}>
                  {formatDate(r.start)} — {formatDate(r.end)}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      <aside className="panel">
        <h2>Resumo da locação</h2>
        <p style={{ color: "var(--muted)" }}>A partir de {money(item.pricePerDay)}/dia</p>
        {error && <div className="alert">{error}</div>}
        {ok && <div className="ok">{ok}</div>}
        {!user && (
          <div className="alert">
            Você pode ver o produto sem cadastro. Para alugar, crie um perfil com seus dados e a foto do documento.
            <div style={{ marginTop: 10, display: "flex", gap: 8 }}>
              <Link className="btn green" to={`/cadastrar?next=${encodeURIComponent(next)}`}>Criar perfil</Link>
              <Link className="ghost" to={`/entrar?next=${encodeURIComponent(next)}`}>Já tenho perfil</Link>
            </div>
          </div>
        )}
        {user && user.quarantined && (
          <div className="alert">Sua conta está em quarentena por cancelamento próximo da retirada. Aguarde a reavaliação do administrador para alugar novamente.</div>
        )}
        {user && !user.quarantined && (
          <p className="ok">Aluguel vinculado a {user.name} · documento {user.documentType} enviado · nível {renterLevelMeta[user.renterLevel || "bronze"]?.label || "Bronze"}.</p>
        )}
        <form onSubmit={submit}>
          <div className="form-grid">
            <div className="field">
              <label>Data de retirada</label>
              <input
                type="date"
                value={form.startDate}
                min={today}
                onChange={(e) => {
                  const startDate = e.target.value;
                  setForm((prev) => ({
                    ...prev,
                    startDate,
                    endDate: prev.endDate && prev.endDate < startDate ? startDate : prev.endDate
                  }));
                }}
                required
              />
            </div>
            <div className="field">
              <label>Horário de retirada</label>
              <input
                type="time"
                value={form.startTime}
                onChange={(e) => setForm({ ...form, startTime: e.target.value })}
                required
              />
            </div>
            <div className="field">
              <label>Data de devolução</label>
              <input
                type="date"
                value={form.endDate}
                min={form.startDate || today}
                onChange={(e) => setForm({ ...form, endDate: e.target.value })}
                required
              />
            </div>
            <div className="field">
              <label>Horário de devolução</label>
              <input
                type="time"
                value={form.endTime}
                onChange={(e) => setForm({ ...form, endTime: e.target.value })}
                required
              />
            </div>
          </div>
          <div className="field">
            <p style={{ color: "var(--muted)", margin: 0 }}>Entrega pela DIUSO · {money(settings?.deliveryFee ?? item.deliveryFee)}</p>
          </div>
          <div className="field">
            <label>Observacao</label>
            <textarea rows="3" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} />
          </div>
          <div className="calc">
            <div className="calc-row"><span>Produto</span><span>{item.title}</span></div>
            <div className="calc-row"><span>Período</span><span>{quote?.periodLabel || "Escolha as datas"}</span></div>
            <div className="calc-row"><span>Aluguel</span><span>{money(quote?.rentalAmount)}</span></div>
            <div className="calc-row"><span>Proteção Diuso</span><span>{money(quote?.protectionFee)}</span></div>
            <div className="calc-row"><span>Entrega</span><span>{money(quote?.deliveryFee)}</span></div>
            <div className="calc-row"><span>Caução reembolsável.</span><span>{money(quote?.deposit)}</span></div>
            <div className="calc-row total"><span>Total inicial</span><span>{money(quote?.initialCharge)}</span></div>
          </div>
          {quote && (
            <div className="split-money">
              <div><b>Valor da locação</b><span>{money(quote.rentalDue)}</span></div>
              <div><b>Valor temporariamente retido como caução</b><span>{money(quote.deposit)}</span></div>
            </div>
          )}
          <p style={{ color: "var(--muted)", fontSize: 13 }}>
            {quote?.depositNote || "A caução não é uma cobrança definitiva. Ela será devolvida após a devolução do item e a conclusão da inspeção."}
            A Proteção Diuso cobre suporte, intermediação e prevenção de fraude — não é um seguro.
          </p>
          <div className="field">
            <label className="check">
              <input type="checkbox" checked={form.contractAccepted} onChange={(e) => setForm({ ...form, contractAccepted: e.target.checked })} />
              Aceito o contrato DIUSO de uso temporario e devolução na data combinada.
            </label>
          </div>
          {paused && (
            <div className="alert">Este anúncio está pausado. Não é possível fazer novas reservas. Locações já feitas seguem ativas até a devolução.</div>
          )}
          {!paused && unavailable && (
            <div className="alert">Este item está {availabilityLabel[item.availability] || "indisponível"} no momento.</div>
          )}
          <button className="btn green wide" type="submit" disabled={unavailable || Boolean(user?.quarantined)}>
            {user ? "Solicitar locação" : "Cadastrar para alugar"}
          </button>
          <button className="btn ghost-btn wide" type="button" disabled title="Em breve">
            Enviar mensagem · em breve
          </button>
          <p style={{ color: "var(--muted)", fontSize: 12, marginTop: 10 }}>
            Pagamento via gateway (cartão/Pix) ainda não está conectado. A reserva fica aguardando o provedor — nenhum pagamento é marcado como aprovado.
          </p>
        </form>
      </aside>
    </div>
  );
}
