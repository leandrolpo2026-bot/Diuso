import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../auth.jsx";
import { formatDate, money, renterLevelMeta, statusMeta } from "../visuals.js";

const groups = {
  proximas: ["aguardando_confirmacao", "confirmado", "preparando", "em_entrega"],
  andamento: ["ativo", "aguardando_devolucao", "atrasado", "reembolsado"],
  concluidas: ["finalizado"],
  canceladas: ["cancelado"]
};

export default function Account() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    if (!user) return;
    api.bookings({ mine: "1" }).then(setBookings).catch(console.error);
    api.profile(user.id).then(setProfile).catch(() => {});
  }, [user]);

  const next = useMemo(() => {
    return bookings
      .filter((b) => !["cancelado", "finalizado"].includes(b.status))
      .sort((a, b) => a.startDate.localeCompare(b.startDate))[0];
  }, [bookings]);

  function list(key) {
    return bookings.filter((b) => groups[key].includes(b.status));
  }

  return (
    <div className="shell" style={{ padding: "32px 0 50px" }}>
      <h1>Minhas locações</h1>
      {!user && (
        <div className="panel" style={{ marginTop: 18 }}>
          <p>Você pode explorar o catálogo sem cadastro. Para ver e fazer aluguéis, crie um perfil com documento.</p>
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <Link className="btn green" to="/cadastrar?next=/conta">Criar perfil</Link>
            <Link className="ghost" to="/entrar?next=/conta">Entrar</Link>
          </div>
        </div>
      )}
      {user && (
        <>
          <p style={{ color: "var(--muted)" }}>
            {user.name} · {profile?.identityVerified ? "Identidade verificada" : "Documento pendente"}
            {profile?.paymentVerified ? " · Pagamento verificado" : ""}
            {profile?.goodHistory ? " · Bom histórico" : ""}
            {` · Nível ${renterLevelMeta[user.renterLevel || profile?.renterLevel || "bronze"]?.label || "Bronze"}`}
          </p>
          <div className="dash">
            <div className="dash-card">
              <span>Nível do locatário</span>
              <strong>{(renterLevelMeta[user.renterLevel || profile?.renterLevel || "bronze"]?.label || "Bronze").toUpperCase()}</strong>
              <div style={{ color: "var(--muted)", marginTop: 6 }}>
                {profile?.renterPaidCount ?? user.renterPaidCount ?? 0} locações
              </div>
            </div>
            <div className="dash-card">
              <span>Próxima locação</span>
              <strong>{next ? next.item?.title : "Nenhuma"}</strong>
              <div style={{ color: "var(--muted)", marginTop: 6 }}>
                {next ? `${formatDate(next.startDate)} — ${formatDate(next.endDate)}` : "Reserve quando precisar usar."}
              </div>
            </div>
            <div className="dash-card">
              <span>Locações concluídas</span>
              <strong>{profile?.rentalsAsRenter || list("concluidas").length}</strong>
            </div>
            <div className="dash-card">
              <span>Avaliação</span>
              <strong>{profile?.rating ? `${profile.rating} ★` : "—"}</strong>
              <div style={{ color: "var(--muted)", marginTop: 6 }}>{profile?.reviewsCount || 0} avaliações</div>
            </div>
          </div>

          {Object.entries({
            proximas: "Próximas",
            andamento: "Em andamento",
            concluidas: "Concluídas",
            canceladas: "Canceladas"
          }).map(([key, label]) => (
            <section className="section" key={key}>
              <div className="section-head"><h2>{label}</h2></div>
              <div className="panel" style={{ overflowX: "auto" }}>
                {list(key).length === 0 && <p style={{ color: "var(--muted)" }}>Nenhuma locação nesta lista.</p>}
                {list(key).length > 0 && (
                  <table className="table">
                    <thead>
                      <tr><th>Produto</th><th>Período</th><th>Valor</th><th>Caução</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                      {list(key).map((b) => {
                        const meta = statusMeta[b.status] || statusMeta.aguardando_confirmacao;
                        return (
                          <tr key={b.id}>
                            <td><Link to={`/locação/${b.id}`}><strong>{b.item?.title || b.itemId}</strong></Link></td>
                            <td>{formatDate(b.startDate)} {b.startTime || ""} — {formatDate(b.endDate)} {b.endTime || ""}</td>
                            <td>{money(b.rentalDue || b.total)}</td>
                            <td>{money(b.deposit)} · {b.depositStatus || "retido"}</td>
                            <td>
                              <div className="status-cell">
                                <span className={`status ${meta.tone}`}>{meta.label}</span>
                                {b.status === "atrasado" && b.lateReason && <span className="status-desc">{b.lateReason}</span>}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </section>
          ))}
        </>
      )}
    </div>
  );
}
