import { useEffect, useMemo, useRef, useState } from "react";
import { Navigate } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../auth.jsx";
import { formatMoneyInput, money, parseMoney } from "../visuals.js";

const titleExamples = [
  "Furadeira Bosch Professional GSB 13",
  "Projetor Epson Full HD 3600 lumens",
  "Bicicleta mountain bike Caloi Aro 29",
  "Caixa de som JBL PartyBox",
  "Tenda gazebo 3x3 para festa",
  "Cafeteira Nespresso Inissia"
];

const empty = {
  title: "",
  category: "",
  pricePerDay: "",
  weeklyPrice: "",
  monthlyPrice: "",
  estimatedValue: "",
  deposit: "",
  city: "",
  neighborhood: "",
  street: "",
  streetNumber: "",
  owner: "",
  ownerEmail: "",
  ownerPhone: "",
  condition: "",
  description: "",
  specs: "",
  usageRules: "",
  quantity: ""
};

const steps = [
  { id: "nome", title: "Nome" },
  { id: "fotos", title: "Fotos" },
  { id: "categoria", title: "Categoria" },
  { id: "descricao", title: "Descricao" },
  { id: "preço", title: "Preço" },
  { id: "disponibilidade", title: "Disponibilidade" },
  { id: "local", title: "Localizacao" },
  { id: "regras", title: "Regras" },
  { id: "caução", title: "Caução" },
  { id: "revisar", title: "Revisar" },
  { id: "publicar", title: "Publicar" }
];

export default function Advertise() {
  const { user, ready } = useAuth();
  const [categories, setCategories] = useState([]);
  const [cities, setCities] = useState([]);
  const [form, setForm] = useState(empty);
  const [photos, setPhotos] = useState([]);
  const [previews, setPreviews] = useState([]);
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [sending, setSending] = useState(false);
  const [step, setStep] = useState(0);
  const galleryInput = useRef(null);
  const cameraInput = useRef(null);
  const [titleHint, setTitleHint] = useState(titleExamples[0]);

  useEffect(() => {
    api.categories().then(setCategories).catch(console.error);
    api.cities().then((data) => setCities(data.active || [])).catch(console.error);
  }, []);

  useEffect(() => {
    if (!user) return;
    setForm((prev) => ({
      ...prev,
      owner: prev.owner || user.name || "",
      ownerEmail: prev.ownerEmail || user.email || "",
      ownerPhone: prev.ownerPhone || user.phone || "",
      city: prev.city || (cities.includes(user.city) ? user.city : ""),
      neighborhood: prev.neighborhood || user.neighborhood || ""
    }));
  }, [user, cities]);

  useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      i = (i + 1) % titleExamples.length;
      setTitleHint(titleExamples[i]);
    }, 2800);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const urls = photos.map((file) => URL.createObjectURL(file));
    setPreviews(urls);
    return () => urls.forEach((url) => URL.revokeObjectURL(url));
  }, [photos]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [step]);

  const catName = useMemo(
    () => categories.find((c) => c.id === form.category)?.name || form.category,
    [categories, form.category]
  );

  function set(key, value) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function setMoney(key, value) {
    set(key, formatMoneyInput(value));
  }

  function addPhotos(fileList) {
    const incoming = Array.from(fileList || []).filter((file) => file.type.startsWith("image/"));
    if (!incoming.length) return;
    setPhotos((prev) => [...prev, ...incoming].slice(0, 12));
    setError("");
  }

  function onPhotos(e) {
    addPhotos(e.target.files);
    e.target.value = "";
  }

  function movePhoto(index, dir) {
    setPhotos((prev) => {
      const next = [...prev];
      const target = index + dir;
      if (target < 0 || target >= next.length) return prev;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  function removePhoto(index) {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  }

  function validateStep() {
    const id = steps[step].id;
    if (id === "fotos" && photos.length < 6) return "Envie no mínimo 6 fotos do item.";
    if (id === "nome" && !form.title.trim()) return "Informe o nome do item.";
    if (id === "categoria" && !form.category) return "Selecione a categoria.";
    if (id === "descricao" && (!form.description.trim() || !form.specs.trim())) return "Preencha descricao e destaques.";
    if (id === "preço" && !(parseMoney(form.pricePerDay) > 0)) return "Informe o preço por dia em reais.";
    if (id === "disponibilidade" && (!form.quantity || !form.condition)) return "Informe quantidade e condicao.";
    if (id === "local" && (!form.city.trim() || !form.neighborhood.trim() || !form.street.trim() || !form.streetNumber.trim())) {
      return "Informe município, bairro, logradouro e número.";
    }
    if (id === "regras" && !form.usageRules.trim()) return "Informe as regras de utilizacao.";
    if (id === "caução" && (!(parseMoney(form.deposit) >= 0) || !(parseMoney(form.estimatedValue) > 0))) {
      return "Informe caução e valor estimado em reais.";
    }
    if (id === "revisar" && (!form.owner.trim() || !form.ownerEmail.trim() || !form.ownerPhone.trim())) {
      return "Informe nome, e-mail e telefone para o anúncio.";
    }
    return "";
  }

  function nextStep() {
    const msg = validateStep();
    if (msg) {
      setError(msg);
      return;
    }
    setError("");
    setStep((s) => Math.min(s + 1, steps.length - 1));
  }

  async function submit(e) {
    e.preventDefault();
    setError("");
    setOk("");
    const optional = ["weeklyPrice", "monthlyPrice"];
    const missing = Object.entries(form).filter(([key, value]) => !optional.includes(key) && !String(value || "").trim());
    if (missing.length) {
      setError("Todos os campos são obrigatórios.");
      return;
    }
    if (photos.length < 6) {
      setError("Envie no mínimo 6 fotos do item.");
      return;
    }
    setSending(true);
    try {
      await api.submitListing({
        ...form,
        owner: form.owner || user?.name || "",
        ownerEmail: form.ownerEmail || user?.email || "",
        ownerPhone: form.ownerPhone || user?.phone || "",
        photos
      });
      setOk("Pedido enviado para análise. O item não foi publicado. O administrador DIUSO vai revisar e, se aprovado, disponibilizar no site.");
      setForm(empty);
      setPhotos([]);
      setStep(0);
    } catch (err) {
      setError(err.message);
    } finally {
      setSending(false);
    }
  }

  const current = steps[step];

  if (ready && !user) return <Navigate to="/entrar?next=/anunciar" replace />;

  return (
    <div className="shell" style={{ padding: "32px 0 50px", maxWidth: 820 }}>
      <h1>Anunciar na DIUSO</h1>
      <p style={{ color: "var(--muted)" }}>
        Cadastre em etapas. Nada e publicado automaticamente. O administrador analisa o pedido.
      </p>
      <div className="wizard-steps">
        {steps.map((s, i) => (
          <button
            key={s.id}
            type="button"
            className={`wizard-dot ${i === step ? "on" : ""} ${i < step ? "done" : ""}`}
            onClick={() => { setError(""); setStep(i); }}
          >
            {i + 1}
          </button>
        ))}
      </div>
      <form className="panel" style={{ marginTop: 18 }} onSubmit={submit}>
        {error && <div className="alert">{error}</div>}
        {ok && <div className="ok">{ok}</div>}
        <h2>{current.title}</h2>

        {current.id === "fotos" && (
          <div className="field">
            <label>Fotos do item * (mínimo 6)</label>
            <p style={{ color: "var(--muted)", fontSize: 14, margin: "0 0 12px" }}>
              A primeira foto é a capa do anúncio. Use as setas para escolher a ordem.
            </p>
            <div className="photo-actions">
              <input ref={galleryInput} type="file" accept="image/*" multiple onChange={onPhotos} hidden />
              <input ref={cameraInput} type="file" accept="image/*" capture="environment" onChange={onPhotos} hidden />
              <button className="btn ghost-btn" type="button" onClick={() => galleryInput.current?.click()}>
                Escolher da galeria
              </button>
              <button className="btn green" type="button" onClick={() => cameraInput.current?.click()}>
                Tirar foto agora
              </button>
            </div>
            <p className={`photo-hint ${photos.length >= 6 ? "ok-text" : ""}`}>
              {photos.length} de 6 fotos selecionadas
            </p>
            {previews.length > 0 && (
              <div className="photo-grid photo-grid-edit">
                {previews.map((src, index) => (
                  <figure key={`${src}-${index}`} className="photo-tile">
                    <img src={src} alt={`Foto ${index + 1}`} />
                    <span className="photo-order">{index === 0 ? "Capa" : index + 1}</span>
                    <div className="photo-tile-actions">
                      <button type="button" disabled={index === 0} onClick={() => movePhoto(index, -1)} aria-label="Mover para a esquerda">‹</button>
                      <button type="button" disabled={index === previews.length - 1} onClick={() => movePhoto(index, 1)} aria-label="Mover para a direita">›</button>
                      <button type="button" onClick={() => removePhoto(index)} aria-label="Remover foto">×</button>
                    </div>
                  </figure>
                ))}
              </div>
            )}
          </div>
        )}

        {current.id === "nome" && (
          <div className="field">
            <label>Título *</label>
            <input
              value={form.title}
              onChange={(e) => set("title", e.target.value)}
              placeholder={titleHint}
              required
            />
          </div>
        )}

        {current.id === "categoria" && (
          <div className="field">
            <label>Categoria *</label>
            <select value={form.category} onChange={(e) => set("category", e.target.value)} required>
              <option value="">Selecione</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
        )}

        {current.id === "descricao" && (
          <>
            <div className="field">
              <label>Destaques *</label>
              <input value={form.specs} onChange={(e) => set("specs", e.target.value)} placeholder="Maleta, 2 baterias, cabo 15m" required />
            </div>
            <div className="field">
              <label>Descricao de uso temporario *</label>
              <textarea rows="4" value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="Use pelo tempo que precisar e devolva." required />
            </div>
          </>
        )}

        {current.id === "preço" && (
          <div className="form-grid">
            <div className="field">
              <label>Aluguel por diária (R$) *</label>
              <input inputMode="numeric" placeholder="0,00" value={form.pricePerDay} onChange={(e) => setMoney("pricePerDay", e.target.value)} required />
            </div>
            <div className="field">
              <label>Preço semanal (R$)</label>
              <input inputMode="numeric" placeholder="0,00" value={form.weeklyPrice} onChange={(e) => setMoney("weeklyPrice", e.target.value)} />
            </div>
            <div className="field">
              <label>Preço mensal (R$)</label>
              <input inputMode="numeric" placeholder="0,00" value={form.monthlyPrice} onChange={(e) => setMoney("monthlyPrice", e.target.value)} />
            </div>
          </div>
        )}

        {current.id === "disponibilidade" && (
          <div className="form-grid">
            <div className="field">
              <label>Condicao *</label>
              <select value={form.condition} onChange={(e) => set("condition", e.target.value)} required>
                <option value="">Selecione</option>
                <option>Como novo</option>
                <option>Excelente</option>
                <option>Muito bom</option>
                <option>Bom</option>
              </select>
            </div>
            <div className="field">
              <label>Quantidade / unidades *</label>
              <input type="number" min="1" value={form.quantity} onChange={(e) => set("quantity", e.target.value)} required />
            </div>
          </div>
        )}

        {current.id === "local" && (
          <div className="form-grid">
            <div className="field">
              <label>Município *</label>
              <select value={form.city} onChange={(e) => set("city", e.target.value)} required>
                <option value="">Selecione</option>
                {cities.map((city) => <option key={city} value={city}>{city}</option>)}
              </select>
            </div>
            <div className="field">
              <label>Bairro *</label>
              <input value={form.neighborhood} onChange={(e) => set("neighborhood", e.target.value)} required />
            </div>
            <div className="field">
              <label>Logradouro (Rua/Avenida) *</label>
              <input value={form.street} onChange={(e) => set("street", e.target.value)} placeholder="Ex.: Rua das Palmeiras" required />
            </div>
            <div className="field">
              <label>Número *</label>
              <input value={form.streetNumber} onChange={(e) => set("streetNumber", e.target.value)} placeholder="Ex.: 120" required />
            </div>
            <p style={{ gridColumn: "1 / -1", color: "var(--muted)", margin: 0, fontSize: 13 }}>
              Endereço usado como referência para retirada e entrega pela DIUSO. Não aparece no anúncio público.
            </p>
          </div>
        )}

        {current.id === "regras" && (
          <div className="field">
            <label>Regras de utilizacao *</label>
            <textarea rows="4" value={form.usageRules} onChange={(e) => set("usageRules", e.target.value)} required />
          </div>
        )}

        {current.id === "caução" && (
          <div className="form-grid">
            <div className="field">
              <label>Valor estimado do produto (R$) *</label>
              <input inputMode="numeric" placeholder="0,00" value={form.estimatedValue} onChange={(e) => setMoney("estimatedValue", e.target.value)} required />
            </div>
            <div className="field">
              <label>Caução sugerida (R$) *</label>
              <input inputMode="numeric" placeholder="0,00" value={form.deposit} onChange={(e) => setMoney("deposit", e.target.value)} required />
            </div>
          </div>
        )}

        {(current.id === "revisar" || current.id === "publicar") && (
          <>
            {current.id === "revisar" && (
              <div className="form-grid">
                <div className="field">
                  <label>Seu nome *</label>
                  <input value={form.owner} onChange={(e) => set("owner", e.target.value)} required />
                </div>
                <div className="field">
                  <label>Seu e-mail *</label>
                  <input type="email" value={form.ownerEmail} onChange={(e) => set("ownerEmail", e.target.value)} required />
                </div>
                <div className="field" style={{ gridColumn: "1 / -1" }}>
                  <label>Seu telefone *</label>
                  <input value={form.ownerPhone} onChange={(e) => set("ownerPhone", e.target.value)} required />
                </div>
              </div>
            )}
            <div className="listing-preview">
              {previews[0] && <img src={previews[0]} alt="" />}
              <div>
                <strong>{form.title || "Sem titulo"}</strong>
                <p>{catName} · {form.street}{form.streetNumber ? `, ${form.streetNumber}` : ""} · {form.neighborhood} · {form.city}</p>
                <p>{parseMoney(form.pricePerDay) > 0 ? `${money(parseMoney(form.pricePerDay))}/dia` : "Preço pendente"} · caução {form.deposit || "—"}</p>
                <p style={{ color: "var(--muted)" }}>{form.description || "Descricao pendente"}</p>
              </div>
            </div>
          </>
        )}

        <div className="menu-form-actions" style={{ marginTop: 16 }}>
          {step > 0 && (
            <button className="btn ghost-btn" type="button" onClick={() => { setError(""); setStep((s) => s - 1); }}>
              Voltar
            </button>
          )}
          {current.id !== "publicar" && (
            <button className="btn green" type="button" onClick={nextStep}>Continuar</button>
          )}
          {current.id === "publicar" && (
            <button className="btn green" type="submit" disabled={sending}>
              {sending ? "Enviando para análise..." : "Enviar para análise"}
            </button>
          )}
        </div>
      </form>
    </div>
  );
}
