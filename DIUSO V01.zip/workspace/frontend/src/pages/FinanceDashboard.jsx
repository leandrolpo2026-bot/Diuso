import { useEffect, useState } from "react";
import { api } from "../api.js";
import { money } from "../visuals.js";

function pct(n) {
  return `${Math.round(Number(n || 0) * 1000) / 10}%`;
}

function BarChart({ rows, valueKey, color = "var(--brand)" }) {
  const max = Math.max(1, ...rows.map((row) => Number(row[valueKey] || 0)));
  return (
    <div className="chart-bars">
      {rows.map((row) => (
        <div className="chart-bar-row" key={row.month || row.status || row.label}>
          <span>{row.label || row.month || row.status}</span>
          <div className="chart-bar-track">
            <div className="chart-bar-fill" style={{ width: `${(Number(row[valueKey] || 0) / max) * 100}%`, background: color }} />
          </div>
          <b>{valueKey === "count" ? row[valueKey] : money(row[valueKey])}</b>
        </div>
      ))}
    </div>
  );
}

export default function FinanceDashboard() {
  const [data, setData] = useState(null);
  const [settings, setSettings] = useState(null);
  const [ok, setOk] = useState("");
  const [error, setError] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [askPassword, setAskPassword] = useState(false);
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");

  async function load() {
    const dash = await api.financeDashboard();
    setData(dash);
  }

  useEffect(() => { load().catch((err) => setError(err.message)); }, []);

  async function confirmPassword() {
    setPasswordError("");
    try {
      await api.unlockSettings(password);
      const conf = await api.settings();
      setSettings(conf);
      setUnlocked(true);
      setAskPassword(false);
    } catch (err) {
      setPasswordError(err.message);
    }
  }

  async function saveSettings(e) {
    e.preventDefault();
    setError("");
    setOk("");
    try {
      await api.saveSettings(settings, password);
      setOk("Configurações financeiras salvas.");
      await load();
    } catch (err) {
      setError(err.message);
    }
  }

  const kpis = data?.kpis || {};
  const mix = data?.mix || [];
  const mixTotal = mix.reduce((sum, item) => sum + Number(item.value || 0), 0) || 1;
  let cursor = 0;
  const donutStops = mix.map((item, index) => {
    const colors = ["#0f766e", "#0ea5e9", "#d97706", "#64748b"];
    const start = cursor;
    cursor += (Number(item.value || 0) / mixTotal) * 100;
    return `${colors[index % colors.length]} ${start}% ${cursor}%`;
  }).join(", ");

  return (
    <>
      {error && <div className="alert">{error}</div>}
      {ok && <div className="ok">{ok}</div>}
      {data && (
        <>
          <h2>Saude financeira</h2>
          <div className="dash">
            <div className="dash-card"><span>Receita DIUSO</span><strong>{money(kpis.revenue)}</strong></div>
            <div className="dash-card"><span>Volume de locação</span><strong>{money(kpis.rentalVolume)}</strong></div>
            <div className="dash-card"><span>Take rate</span><strong>{pct(kpis.takeRate)}</strong></div>
            <div className="dash-card"><span>Ticket medio</span><strong>{money(kpis.avgTicket)}</strong></div>
            <div className="dash-card"><span>Ocupacao</span><strong>{pct(kpis.occupancy)}</strong></div>
            <div className="dash-card"><span>Inadimplencia operacional</span><strong>{kpis.unpaidCount || 0}</strong><div style={{ color: "var(--muted)" }}>{kpis.paidCount || 0} pagas</div></div>
            <div className="dash-card"><span>Atraso</span><strong>{pct(kpis.lateRate)}</strong></div>
            <div className="dash-card"><span>Cancelamento</span><strong>{pct(kpis.cancelRate)}</strong></div>
            <div className="dash-card"><span>Conclusao</span><strong>{pct(kpis.completionRate)}</strong></div>
            <div className="dash-card"><span>Caucoes retidas</span><strong>{money(kpis.heldDeposits)}</strong><div style={{ color: "var(--muted)" }}>Não e receita</div></div>
            <div className="dash-card"><span>Repasses pendentes</span><strong>{money(kpis.payoutsPending)}</strong></div>
            <div className="dash-card"><span>Ocorrências abertas</span><strong>{kpis.openIncidents || 0}</strong></div>
          </div>

          <div className="chart-grid">
            <div className="panel">
              <h3>Receita nos ultimos 6 meses</h3>
              <BarChart rows={(data.monthly || []).map((row) => ({ ...row, label: row.month }))} valueKey="revenue" />
            </div>
            <div className="panel">
              <h3>Composicao da receita</h3>
              <div className="chart-donut-wrap">
                <div className="chart-donut" style={{ background: `conic-gradient(${donutStops || "#e6ebf2 0 100%"})` }} />
                <div className="chart-legend">
                  {mix.map((item) => (
                    <div key={item.id}><b>{item.label}</b><span>{money(item.value)}</span></div>
                  ))}
                </div>
              </div>
            </div>
            <div className="panel">
              <h3>Volume de locação</h3>
              <BarChart rows={(data.monthly || []).map((row) => ({ ...row, label: row.month }))} valueKey="volume" color="var(--navy)" />
            </div>
            <div className="panel">
              <h3>Pedidos por status</h3>
              <BarChart rows={(data.statusMix || []).filter((row) => row.count).map((row) => ({ ...row, label: row.status }))} valueKey="count" color="#0ea5e9" />
            </div>
          </div>
        </>
      )}

      <section className="section">
        {!unlocked && (
          <button type="button" className="btn green" onClick={() => { setAskPassword(true); setPassword(""); setPasswordError(""); }}>Editar configurações financeiras</button>
        )}
        {unlocked && settings && (
          <>
          <div className="section-head"><h2>Configurações financeiras</h2></div>
          <form className="panel" onSubmit={saveSettings}>
            <div className="form-grid">
              <div className="field">
                <label>Comissão Diuso (%)</label>
                <input type="number" step="0.1" value={Math.round(Number(settings.commissionRate || 0) * 1000) / 10} onChange={(e) => setSettings({ ...settings, commissionRate: Number(e.target.value) / 100 })} />
              </div>
              <div className="field">
                <label>Taxa de proteção (%)</label>
                <input type="number" step="0.1" value={Math.round(Number(settings.protectionRate || 0) * 1000) / 10} onChange={(e) => setSettings({ ...settings, protectionRate: Number(e.target.value) / 100 })} />
              </div>
              <div className="field">
                <label>Multiplicador de atraso</label>
                <input type="number" step="0.1" value={settings.lateFeeMultiplier} onChange={(e) => setSettings({ ...settings, lateFeeMultiplier: Number(e.target.value) })} />
              </div>
              <div className="field">
                <label>Tolerância de atraso (horas)</label>
                <input type="number" value={settings.lateToleranceHours} onChange={(e) => setSettings({ ...settings, lateToleranceHours: Number(e.target.value) })} />
              </div>
              <div className="field">
                <label>Taxa padrão de entrega (R$)</label>
                <input type="number" min="0" step="0.01" value={settings.deliveryFee ?? 0} onChange={(e) => setSettings({ ...settings, deliveryFee: Number(e.target.value) })} />
              </div>
              <div className="field">
                <label>Reembolso +48h (%)</label>
                <input type="number" value={Math.round(Number(settings.cancellation?.over48h || 0) * 1000) / 10} onChange={(e) => setSettings({ ...settings, cancellation: { ...settings.cancellation, over48h: Number(e.target.value) / 100 } })} />
              </div>
              <div className="field">
                <label>Reembolso 24–48h (%)</label>
                <input type="number" value={Math.round(Number(settings.cancellation?.between24and48h || 0) * 1000) / 10} onChange={(e) => setSettings({ ...settings, cancellation: { ...settings.cancellation, between24and48h: Number(e.target.value) / 100 } })} />
              </div>
              <div className="field">
                <label>Reembolso menos de 24h (%)</label>
                <input type="number" value={Math.round(Number(settings.cancellation?.under24h || 0) * 1000) / 10} onChange={(e) => setSettings({ ...settings, cancellation: { ...settings.cancellation, under24h: Number(e.target.value) / 100 } })} />
              </div>
              <div className="field">
                <label>Níveis do locatário</label>
                <p style={{ color: "var(--muted)", margin: 0 }}>
                  Bronze 100% caução · Prata 50% após R$ 1000 · Ouro isento após R$ 2000. Promoção só após a 3ª locação paga (valor da locação).
                </p>
              </div>
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
              <button className="btn green" type="submit">Salvar configurações</button>
              <button className="ghost" type="button" onClick={() => { setUnlocked(false); setPassword(""); setSettings(null); }}>Ocultar</button>
            </div>
          </form>
          </>
        )}
      </section>
      {askPassword && (
        <div className="late-dialog-backdrop" onClick={() => setAskPassword(false)}>
          <div className="late-dialog" onClick={(e) => e.stopPropagation()}>
            <h2>Senha do administrador master</h2>
            <p style={{ color: "var(--muted)", margin: "8px 0 12px" }}>Necessaria para abrir e alterar as configurações financeiras.</p>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Senha master" autoFocus />
            {passwordError && <div className="alert" style={{ marginTop: 10 }}>{passwordError}</div>}
            <div className="late-dialog-actions">
              <button type="button" className="ghost" onClick={() => setAskPassword(false)}>Cancelar</button>
              <button type="button" className="btn green" onClick={confirmPassword}>Desbloquear</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
