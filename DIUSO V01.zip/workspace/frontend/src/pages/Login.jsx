import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../auth.jsx";
import { isStaff } from "../roles.js";

export default function Login() {
  const { setSession } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
    const next = new URLSearchParams(location.search).get("next") || (["/admin", "/reservas", "/anunciar"].includes(location.pathname) ? location.pathname : "/conta");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function submit(e) {
    e.preventDefault();
    setError("");
    try {
      const session = await api.login({ email, password });
      setSession(session);
      if (session.user?.mustChangePassword) {
        if (next && next !== "/conta") sessionStorage.setItem("diuso_next", next);
        navigate("/criar-senha");
        return;
      }
      const target = isStaff(session.user)
        ? (next === "/conta" ? "/admin" : next)
        : (next === "/admin" || next === "/reservas" ? "/conta" : next);
      navigate(target);
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="shell" style={{ padding: "32px 0 50px", maxWidth: 520 }}>
      <h1>{location.pathname === "/admin" ? "Acesso ao painel" : "Entrar"}</h1>
      <p style={{ color: "var(--muted)" }}>
        {location.pathname === "/admin"
          ? "O painel é restrito ao administrador. Informe e-mail e senha."
          : location.pathname === "/anunciar" || next === "/anunciar"
            ? "Para publicar um anúncio, entre ou crie um perfil."
            : "Use seu perfil para alugar. A navegação do catálogo continua livre."}
      </p>
      <form className="panel" style={{ marginTop: 18 }} onSubmit={submit}>
        {error && <div className="alert">{error}</div>}
        <div className="field">
          <label>E-mail</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div className="field">
          <label>Senha</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div>
        <button className="btn green wide" type="submit">Entrar</button>
        {location.pathname !== "/admin" && (
          <>
            <p style={{ color: "var(--muted)", marginTop: 12 }}>
              <Link to="/esqueci-a-senha">Esqueci a senha</Link>
            </p>
            <p style={{ color: "var(--muted)", marginTop: 8 }}>
              Ainda não tem perfil? <Link to={`/cadastrar?next=${encodeURIComponent(next)}`}>Criar perfil</Link>
            </p>
          </>
        )}
      </form>
    </div>
  );
}
