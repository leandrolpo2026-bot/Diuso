import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../auth.jsx";

export default function Notifications() {
  const { user } = useAuth();
  const [list, setList] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user) return;
    api.notifications().then(setList).catch((err) => setError(err.message));
  }, [user]);

  if (!user) {
    return (
      <div className="shell" style={{ padding: "32px 0 50px" }}>
        <h1>Notificações</h1>
        <div className="panel" style={{ marginTop: 18 }}>
          <p>Entre na conta para ver avisos das suas locações.</p>
          <Link className="btn green" to="/entrar?next=/notificações">Entrar</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="shell" style={{ padding: "32px 0 50px" }}>
      <h1>Notificações</h1>
      <p style={{ color: "var(--muted)" }}>Avisos da sua conta e das locações.</p>
      {error && <div className="alert">{error}</div>}
      {list.length === 0 && (
        <div className="panel empty-state" style={{ marginTop: 18 }}>
          <strong>Nenhuma notificacao ainda.</strong>
          <p>Quando houver atualizacao de pedido, comprovante ou ocorrencia, ela aparece aqui.</p>
        </div>
      )}
      <div style={{ display: "grid", gap: 10, marginTop: 18 }}>
        {list.map((n) => (
          <article className="panel" key={n.id || n.createdAt}>
            <strong>{n.title || n.type || "Aviso"}</strong>
            <p style={{ color: "var(--muted)", margin: "6px 0 0" }}>{n.body || n.message || ""}</p>
            {(n.type === "anuncio_devolvido" || n.type === "anuncio_reenviado") && (
              <Link className="btn green" to="/proprietario" style={{ marginTop: 12, display: "inline-flex" }}>
                Ver meus anúncios
              </Link>
            )}
          </article>
        ))}
      </div>
    </div>
  );
}
