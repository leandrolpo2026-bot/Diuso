export const palettes = {
  ferramentas: ["#0f766e", "#134e4a"],
  eletronicos: ["#1e3a5f", "#0ea5e9"],
  esportes: ["#0f766e", "#f59e0b"],
  festas: ["#312e81", "#06b6d4"],
  casa: ["#14532d", "#14b8a6"],
  cameras: ["#111827", "#64748b"],
  musica: ["#0f172a", "#14b8a6"],
  mobilidade: ["#0e7490", "#22d3ee"],
  automotivo: ["#1e293b", "#0f766e"],
  construcao: ["#78350f", "#d97706"],
  moveis: ["#3f3f46", "#14b8a6"],
  outros: ["#0f172a", "#64748b"]
};

export const statusMeta = {
  aguardando_confirmacao: { label: "Aguardando confirmação", tone: "wait" },
  confirmado: { label: "Confirmado", tone: "info" },
  preparando: { label: "Preparando", tone: "prep" },
  em_entrega: { label: "Em entrega", tone: "ship" },
  ativo: { label: "Ativo", tone: "ok" },
  aguardando_devolucao: { label: "Aguardando devolução", tone: "warn" },
  atrasado: { label: "Atrasado", tone: "late" },
  reembolsado: { label: "Reembolsado", tone: "ok" },
  finalizado: { label: "Finalizado", tone: "done" },
  cancelado: { label: "Cancelado", tone: "late" },
  pendente: { label: "Aguardando confirmação", tone: "wait" },
  confirmada: { label: "Confirmado", tone: "info" },
  concluida: { label: "Finalizado", tone: "done" },
  cancelada: { label: "Cancelado", tone: "late" },
  aguardando_analise: { label: "Aguardando análise", tone: "wait" },
  aprovado: { label: "Aprovado", tone: "ok" },
  rejeitado: { label: "Devolvido para correção", tone: "late" }
};

export const availabilityLabel = {
  disponivel: "Disponível",
  "disponível": "Disponível",
  alugado: "Alugado agora",
  manutencao: "Em manutenção",
  "manutenção": "Em manutenção",
  pausado: "Pausado",
  indisponivel: "Indisponível",
  "indisponível": "Indisponível"
};

export function money(n) {
  return Number(n || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function parseMoney(value) {
  const raw = String(value ?? "").trim();
  if (!raw) return NaN;
  if (raw.includes(",")) {
    return Number(raw.replace(/[^\d,-]/g, "").replace(/\./g, "").replace(",", "."));
  }
  return Number(raw.replace(/[^\d.-]/g, ""));
}

export function formatMoneyInput(value) {
  const digits = String(value || "").replace(/\D/g, "");
  if (!digits) return "";
  return (Number(digits) / 100).toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

export function formatDate(iso) {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

export function daysBetween(start, end) {
  if (!start || !end) return 0;
  const a = new Date(`${start}T00:00:00`);
  const b = new Date(`${end}T00:00:00`);
  return Math.round((b - a) / 86400000) + 1;
}

export const renterLevelMeta = {
  bronze: { label: "Bronze", deposit: "100% da caução" },
  prata: { label: "Prata", deposit: "50% da caução" },
  ouro: { label: "Ouro", deposit: "Isento de caução" }
};

export function hasDeposit(booking) {
  return Number(booking?.deposit || 0) > 0;
}

const nextStatusMap = {
  aguardando_confirmacao: "confirmado",
  confirmado: "preparando",
  preparando: "em_entrega",
  em_entrega: "ativo",
  ativo: "aguardando_devolucao",
  aguardando_devolucao: "finalizado",
  reembolsado: "finalizado"
};

const prevStatusMap = {
  confirmado: "aguardando_confirmacao",
  preparando: "confirmado",
  em_entrega: "preparando",
  ativo: "em_entrega",
  aguardando_devolucao: "ativo",
  atrasado: "aguardando_devolucao",
  reembolsado: "aguardando_devolucao",
  finalizado: "aguardando_devolucao"
};

export function nextBookingStatus(booking) {
  if (booking?.status === "aguardando_devolucao" && hasDeposit(booking)) return "reembolsado";
  return nextStatusMap[booking?.status] || "";
}

export function prevBookingStatus(booking) {
  if (booking?.status === "finalizado" && hasDeposit(booking)) return "reembolsado";
  return prevStatusMap[booking?.status] || "";
}

export const nextStatusLabel = {
  confirmado: "Confirmar",
  preparando: "Preparar",
  em_entrega: "Saiu para entrega",
  ativo: "Marcar em uso",
  aguardando_devolucao: "Aguardar devolução",
  reembolsado: "Reembolsar caução",
  finalizado: "Finalizar"
};

export const statusLegend = [
  "aguardando_confirmacao",
  "confirmado",
  "preparando",
  "em_entrega",
  "ativo",
  "aguardando_devolucao",
  "atrasado",
  "reembolsado",
  "finalizado",
  "cancelado"
];

export function bookingSortValue(booking, key) {
  if (key === "item") return String(booking.item?.title || booking.itemId || "").toLowerCase();
  if (key === "client") return String(booking.renterName || "").toLowerCase();
  if (key === "period") return `${booking.startDate || ""}|${booking.endDate || ""}`;
  if (key === "money") return Number(booking.rentalDue || booking.total || 0);
  if (key === "status") return String(statusMeta[booking.status]?.label || booking.status || "").toLowerCase();
  if (key === "refund") return hasDeposit(booking) ? (booking.depositRefundProof ? "anexado" : "pendente") : "sem";
  return "";
}

export function compareValues(left, right, dir = "asc") {
  const cmp = typeof left === "number" && typeof right === "number"
    ? left - right
    : String(left ?? "").localeCompare(String(right ?? ""), "pt-BR", { numeric: true, sensitivity: "base" });
  return dir === "asc" ? cmp : -cmp;
}

export function compareBookings(a, b, key, dir) {
  return compareValues(bookingSortValue(a, key), bookingSortValue(b, key), dir);
}

export function sortBy(list, getValue, dir = "asc") {
  return [...list].sort((a, b) => compareValues(getValue(a), getValue(b), dir));
}

export function localIsoDate(offsetDays = 0) {
  const date = new Date();
  date.setHours(12, 0, 0, 0);
  date.setDate(date.getDate() + offsetDays);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
