const VISITOR_KEY = "diuso_visitor";
const SESSION_KEY = "diuso_session";
let cachedVisitor = "";

function randomId(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export function visitorId() {
  if (cachedVisitor) return cachedVisitor;
  try {
    let id = localStorage.getItem(VISITOR_KEY);
    if (!id) {
      id = randomId("vis");
      localStorage.setItem(VISITOR_KEY, id);
    }
    cachedVisitor = id;
    return id;
  } catch {
    return "";
  }
}

export function sessionId() {
  try {
    let id = sessionStorage.getItem(SESSION_KEY);
    if (!id) {
      id = randomId("ses");
      sessionStorage.setItem(SESSION_KEY, id);
    }
    return id;
  } catch {
    return "";
  }
}

export function visitorHeaders() {
  const id = visitorId();
  return id ? { "X-Diuso-Visitor": id } : {};
}

let lastTrack = { path: "", at: 0 };

export function trackVisit(path, options = {}) {
  try {
    const now = Date.now();
    if (lastTrack.path === path && now - lastTrack.at < 1500) return;
    lastTrack = { path, at: now };
    visitorId();
    const body = JSON.stringify({
      path: path || "/",
      referrer: options.referrer ?? document.referrer ?? "",
      visitorId: visitorId(),
      sessionId: sessionId(),
      screen: `${window.innerWidth}x${window.innerHeight}`,
      language: navigator.language || "",
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || ""
    });
    fetch("/api/analytics/visit", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...visitorHeaders() },
      body,
      keepalive: true
    }).catch(() => {});
  } catch {
    // analytics must never break the app
  }
}
