export default function ProofAttach({ file, onFile, label = "Anexar" }) {
  return (
    <div className="proof-cell">
      {file?.url ? (
        <a href={file.url} target="_blank" rel="noreferrer">{file.originalname || "Ver anexo"}</a>
      ) : (
        <span className="status-desc">Sem anexo</span>
      )}
      <label className="chip-mini proof-upload table-btn">
        {label}
        <input
          type="file"
          accept="image/*,application/pdf"
          onChange={(e) => {
            const picked = e.target.files?.[0];
            if (picked) onFile(picked);
            e.target.value = "";
          }}
        />
      </label>
    </div>
  );
}
