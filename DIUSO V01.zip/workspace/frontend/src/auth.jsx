import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { api, setToken } from "./api.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    api.me()
      .then((data) => setUser(data.user || null))
      .catch(() => setUser(null))
      .finally(() => setReady(true));
  }, []);

  const value = useMemo(() => ({
    user,
    ready,
    setSession(next) {
      setToken(next?.token || "");
      setUser(next?.user || null);
    },
    setUser,
    async logout() {
      try { await api.logout(); } catch {}
      setToken("");
      setUser(null);
    }
  }), [user, ready]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
