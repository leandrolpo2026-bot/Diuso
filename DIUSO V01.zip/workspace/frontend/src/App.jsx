import { useEffect } from "react";
import { NavLink, Route, Routes, useLocation } from "react-router-dom";
import { useAuth } from "./auth.jsx";
import { trackVisit } from "./analytics.js";
import { useTheme } from "./theme.jsx";
import Home from "./pages/Home.jsx";
import ItemPage from "./pages/ItemPage.jsx";
import Advertise from "./pages/Advertise.jsx";
import Bookings from "./pages/Bookings.jsx";
import Account from "./pages/Account.jsx";
import Favorites from "./pages/Favorites.jsx";
import Admin from "./pages/Admin.jsx";
import Register from "./pages/Register.jsx";
import Login from "./pages/Login.jsx";
import ForgotPassword from "./pages/ForgotPassword.jsx";
import ResetPassword from "./pages/ResetPassword.jsx";
import ForcePassword from "./pages/ForcePassword.jsx";
import BookingDetail from "./pages/BookingDetail.jsx";
import Owner from "./pages/Owner.jsx";
import Menu from "./pages/Menu.jsx";
import Notifications from "./pages/Notifications.jsx";
import Messages from "./pages/Messages.jsx";
import { isStaff } from "./roles.js";
import { IconHome, IconExplore, IconPlus, IconCalendar, IconUser } from "./icons.jsx";

export default function App() {
  const { user, ready } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  const mustChangePassword = Boolean(user?.mustChangePassword);

  useEffect(() => {
    trackVisit(`${location.pathname}${location.search || ""}`);
  }, [location.pathname, location.search]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname, location.search]);

  return (
    <div className="app-wrap">
      <header className="topbar">
        <div className="shell topbar-inner">
          <NavLink to="/" className="brand">
            <img src="/logo-diuso.png" alt="DIUSO" className="brand-logo" />
          </NavLink>
          <nav className="nav">
            <NavLink to="/" end>Início</NavLink>
            {user && !mustChangePassword ? (
              <>
                <a href="/#disponiveis">Explorar</a>
                <NavLink to="/conta">Meus aluguéis</NavLink>
                <NavLink to="/proprietario">Meus anúncios</NavLink>
                <NavLink to="/mensagens">Mensagens</NavLink>
                <NavLink to="/notificações">Notificações</NavLink>
                {isStaff(user) && <NavLink to="/admin">Painel</NavLink>}
              </>
            ) : user ? (
              <span style={{ color: "var(--muted)" }}>Crie a nova senha para continuar</span>
            ) : (
              <>
                <a href="/#disponiveis">Explorar</a>
                <a href="/#categorias">Categorias</a>
                <a href="/#como-funciona">Como funciona</a>
                <NavLink to="/anunciar">Alugar meu objeto</NavLink>
              </>
            )}
          </nav>
          <div className="header-actions">
            <button
              type="button"
              className="theme-toggle"
              onClick={toggleTheme}
              aria-label={theme === "dark" ? "Ativar modo claro" : "Ativar modo escuro"}
              title={theme === "dark" ? "Modo claro" : "Modo escuro"}
            >
              <span className={theme === "light" ? "on" : ""}>Claro</span>
              <span className={theme === "dark" ? "on" : ""}>Escuro</span>
            </button>
            {user && !mustChangePassword ? (
              <NavLink to="/menu" className="btn green">{user.name.split(" ")[0]}</NavLink>
            ) : user ? null : (
              <div className="auth-actions">
                <NavLink to="/entrar" className="btn ghost-btn">Entrar</NavLink>
                <NavLink to="/cadastrar" className="btn green">Criar perfil</NavLink>
              </div>
            )}
          </div>
        </div>
      </header>
      {mustChangePassword ? (
        <ForcePassword />
      ) : (
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/item/:id" element={<ItemPage />} />
        <Route path="/anunciar" element={!ready ? null : user ? <Advertise /> : <Login />} />
        <Route path="/reservas" element={!ready ? null : isStaff(user) ? <Bookings /> : <Login />} />
        <Route path="/conta" element={<Account />} />
        <Route path="/locação/:id" element={<BookingDetail />} />
        <Route path="/proprietario" element={<Owner />} />
        <Route path="/favoritos" element={<Favorites />} />
        <Route path="/notificações" element={<Notifications />} />
        <Route path="/mensagens" element={<Messages />} />
        <Route path="/admin" element={!ready ? null : isStaff(user) ? <Admin /> : <Login />} />
        <Route path="/menu" element={<Menu />} />
        <Route path="/cadastrar" element={<Register />} />
        <Route path="/entrar" element={<Login />} />
        <Route path="/esqueci-a-senha" element={<ForgotPassword />} />
        <Route path="/redefinir-senha" element={<ResetPassword />} />
        <Route path="/criar-senha" element={!ready ? null : user ? <ForcePassword /> : <Login />} />
      </Routes>
      )}
      <footer className="shell footer">
        <strong>DIUSO</strong> — Você precisa. A gente resolve. Encontre, alugue, use e devolva.
      </footer>
      {!mustChangePassword && (
      <nav className="mobile-nav">
        <NavLink to="/" end>
          <IconHome />
          <span>Início</span>
        </NavLink>
        <a href="/#disponiveis">
          <IconExplore />
          <span>Explorar</span>
        </a>
        <NavLink to="/anunciar">
          <IconPlus />
          <span>Publicar</span>
        </NavLink>
        <NavLink to="/conta">
          <IconCalendar />
          <span>Aluguéis</span>
        </NavLink>
        <NavLink to={user ? "/menu" : "/entrar"}>
          <IconUser />
          <span>Perfil</span>
        </NavLink>
      </nav>
      )}
    </div>
  );
}
