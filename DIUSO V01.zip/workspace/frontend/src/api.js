import { visitorHeaders } from "./analytics.js";

async function request(path, options = {}) {
  const token = localStorage.getItem("diuso_token") || "";
  const headers = { ...visitorHeaders(), ...(options.headers || {}) };
  if (!(options.body instanceof FormData)) {
    headers["Content-Type"] = headers["Content-Type"] || "application/json";
  }
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(path, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Falha na requisicao");
  return data;
}

function formRequest(path, payload, filesKey = "photos") {
  const data = new FormData();
  Object.entries(payload || {}).forEach(([key, value]) => {
    if (key === filesKey || value == null) return;
    data.append(key, value);
  });
  (payload?.[filesKey] || []).forEach((file) => data.append(filesKey, file));
  return request(path, { method: "POST", body: data });
}

export function setToken(token) {
  if (token) localStorage.setItem("diuso_token", token);
  else localStorage.removeItem("diuso_token");
}

export const api = {
  me: () => request("/api/auth/me"),
  register: async (payload) => {
    const data = new FormData();
    Object.entries(payload).forEach(([key, value]) => {
      if (key === "documentPhoto") return;
      data.append(key, value);
    });
    if (payload.documentPhoto) data.append("documentPhoto", payload.documentPhoto);
    return request("/api/auth/register", { method: "POST", body: data });
  },
  login: (body) => request("/api/auth/login", { method: "POST", body: JSON.stringify(body) }),
  logout: () => request("/api/auth/logout", { method: "POST", body: JSON.stringify({}) }),
  updateProfile: (body) => request("/api/auth/profile", { method: "PUT", body: JSON.stringify(body) }),
  changePassword: (body) => request("/api/auth/password", { method: "POST", body: JSON.stringify(body) }),
  forgotPassword: (body) => request("/api/auth/forgot-password", { method: "POST", body: JSON.stringify(body) }),
  resetPasswordInfo: (token) => request(`/api/auth/reset-password?token=${encodeURIComponent(token)}`),
  resetPassword: (body) => request("/api/auth/reset-password", { method: "POST", body: JSON.stringify(body) }),
  adminUsers: () => request("/api/admin/users"),
  staff: () => request("/api/admin/staff"),
  createStaff: (body) => request("/api/admin/staff", { method: "POST", body: JSON.stringify(body) }),
  resetStaffPassword: (id, body) => request(`/api/admin/staff/${id}/reset-password`, { method: "POST", body: JSON.stringify(body) }),
  resetUserPassword: (id, body) => request(`/api/admin/users/${id}/reset-password`, { method: "POST", body: JSON.stringify(body) }),
  removeStaff: (id, body) => request(`/api/admin/staff/${id}/remove`, { method: "POST", body: JSON.stringify(body) }),
  removeUser: (id, body) => request(`/api/admin/users/${id}/remove`, { method: "POST", body: JSON.stringify(body) }),
  reviewQuarantine: (id, body = {}) => request(`/api/admin/users/${id}/quarantine`, { method: "POST", body: JSON.stringify(body) }),
  stats: () => request("/api/stats"),
  overview: (period = "30") => request(`/api/admin/overview?period=${encodeURIComponent(period)}`),
  analytics: (days = 30) => request(`/api/admin/analytics?days=${Number(days) || 30}`),
  analyticsExportUrl: (days = 30) => {
    const token = localStorage.getItem("diuso_token") || "";
    const params = new URLSearchParams({ days: String(Number(days) || 30) });
    if (token) params.set("token", token);
    return `/api/admin/analytics/export?${params.toString()}`;
  },
  financeDashboard: () => request("/api/admin/finance"),
  settings: () => request("/api/settings"),
  cities: () => request("/api/cities"),
  createCity: (name) => request("/api/admin/cities", { method: "POST", body: JSON.stringify({ name }) }),
  saveCities: (activeCities, password) => request("/api/admin/cities", { method: "PUT", body: JSON.stringify({ activeCities, password }) }),
  unlockSettings: (password) => request("/api/admin/settings/unlock", { method: "POST", body: JSON.stringify({ password }) }),
  saveSettings: (body, password) => request("/api/admin/settings", { method: "PUT", body: JSON.stringify({ ...body, password }) }),
  categories: () => request("/api/categories"),
  items: (params = {}) => {
    const q = new URLSearchParams(
      Object.fromEntries(Object.entries(params).filter(([, v]) => v !== "" && v != null))
    );
    return request(`/api/items?${q.toString()}`);
  },
  item: (id) => request(`/api/items/${id}`),
  quote: (body) => request("/api/quote", { method: "POST", body: JSON.stringify(body) }),
  listingRequests: () => request("/api/listing-requests"),
  submitListing: async (payload) => {
    const data = new FormData();
    Object.entries(payload).forEach(([key, value]) => {
      if (key === "photos") return;
      data.append(key, value);
    });
    (payload.photos || []).forEach((file) => data.append("photos", file));
    const token = localStorage.getItem("diuso_token") || "";
    const res = await fetch("/api/listing-requests", {
      method: "POST",
      body: data,
      headers: token ? { Authorization: `Bearer ${token}` } : {}
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(json.error || "Falha na requisicao");
    return json;
  },
  listingRequest: (id) => request(`/api/listing-requests/${id}`),
  updateListingRequest: (id, payload) => {
    const data = new FormData();
    Object.entries(payload || {}).forEach(([key, value]) => {
      if (key === "photos" || key === "photoOrder" || value == null) return;
      data.append(key, value);
    });
    if (payload?.photoOrder) data.append("photoOrder", JSON.stringify(payload.photoOrder));
    (payload?.photos || []).forEach((file) => data.append("photos", file));
    return request(`/api/listing-requests/${id}`, { method: "PATCH", body: data });
  },
  approveListing: (id, payload) => {
    if (!payload) {
      return request(`/api/listing-requests/${id}/approve`, { method: "POST", body: JSON.stringify({}) });
    }
    const data = new FormData();
    Object.entries(payload).forEach(([key, value]) => {
      if (key === "photos" || key === "photoOrder" || value == null) return;
      data.append(key, value);
    });
    if (payload.photoOrder) data.append("photoOrder", JSON.stringify(payload.photoOrder));
    (payload.photos || []).forEach((file) => data.append("photos", file));
    return request(`/api/listing-requests/${id}/approve`, { method: "POST", body: data });
  },
  rejectListing: (id, body = {}) => request(`/api/listing-requests/${id}/reject`, { method: "POST", body: JSON.stringify(body) }),
  myListingRequests: () => request("/api/my/listing-requests"),
  resubmitListing: (id, payload) => {
    const data = new FormData();
    Object.entries(payload || {}).forEach(([key, value]) => {
      if (key === "photos" || key === "photoOrder" || value == null) return;
      data.append(key, value);
    });
    if (payload?.photoOrder) data.append("photoOrder", JSON.stringify(payload.photoOrder));
    (payload?.photos || []).forEach((file) => data.append("photos", file));
    return request(`/api/my/listing-requests/${id}/resubmit`, { method: "POST", body: data });
  },
  bookings: (params = {}) => {
    const q = new URLSearchParams(
      Object.fromEntries(Object.entries(params).filter(([, v]) => v !== "" && v != null))
    );
    return request(`/api/bookings?${q.toString()}`);
  },
  booking: (id) => request(`/api/bookings/${id}`),
  createBooking: (body) =>
    request("/api/bookings", { method: "POST", body: JSON.stringify(body) }),
  updateBooking: (id, status) =>
    request(`/api/bookings/${id}`, { method: "PATCH", body: JSON.stringify({ status }) }),
  serviceOrderUrl: (id) => {
    const token = localStorage.getItem("diuso_token") || "";
    return `/api/bookings/${id}/service-order${token ? `?token=${encodeURIComponent(token)}` : ""}`;
  },
  chargeNoteUrl: (id) => {
    const token = localStorage.getItem("diuso_token") || "";
    return `/api/bookings/${id}/charge-note${token ? `?token=${encodeURIComponent(token)}` : ""}`;
  },
  uploadPaymentProof: (id, file) => {
    const data = new FormData();
    data.append("file", file);
    return request(`/api/bookings/${id}/payment-proof`, { method: "POST", body: data });
  },
  uploadDepositRefundProof: (id, file) => {
    const data = new FormData();
    data.append("file", file);
    return request(`/api/bookings/${id}/deposit-refund-proof`, { method: "POST", body: data });
  },
  contract: (id) => request(`/api/bookings/${id}/contract`),
  acceptContract: (id) => request(`/api/bookings/${id}/accept-contract`, { method: "POST", body: JSON.stringify({}) }),
  cancelBooking: (id, body = {}) => request(`/api/bookings/${id}/cancel`, { method: "POST", body: JSON.stringify(body) }),
  inspectBooking: (id, result) => request(`/api/bookings/${id}/inspect`, { method: "POST", body: JSON.stringify({ result }) }),
  markLate: (id, extraDays = 1, reason = "") => request(`/api/bookings/${id}/late`, { method: "POST", body: JSON.stringify({ extraDays, reason }) }),
  checkIn: (id, payload) => formRequest(`/api/bookings/${id}/check-in`, payload),
  checkOut: (id, payload) => formRequest(`/api/bookings/${id}/check-out`, payload),
  incidents: (params = {}) => {
    const q = new URLSearchParams(params);
    return request(`/api/incidents?${q.toString()}`);
  },
  openIncident: (payload) => formRequest("/api/incidents", payload),
  updateIncident: (id, body) => request(`/api/incidents/${id}`, { method: "PATCH", body: JSON.stringify(body) }),
  reviews: () => request("/api/reviews"),
  review: (body) => request("/api/reviews", { method: "POST", body: JSON.stringify(body) }),
  profile: (id) => request(`/api/users/${id}/profile`),
  ownerDashboard: () => request("/api/owner/dashboard"),
  pauseListing: (id) => request(`/api/items/${id}/pause`, { method: "POST", body: JSON.stringify({}) }),
  resumeListing: (id) => request(`/api/items/${id}/resume`, { method: "POST", body: JSON.stringify({}) }),
  removeListing: (id, body = {}) => request(`/api/items/${id}/remove`, { method: "POST", body: JSON.stringify(body) }),
  notifications: () => request("/api/notifications"),
  favorites: () => request("/api/favorites"),
  addFavorite: (id) => request(`/api/favorites/${id}`, { method: "POST" }),
  removeFavorite: (id) => request(`/api/favorites/${id}/remove`, { method: "POST" })
};
