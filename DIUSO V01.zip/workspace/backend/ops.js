import { cancellationPreview, DEFAULT_SETTINGS, lateFeeForDays, moneyRound } from "./finance.js";

export function nowIso() {
  return new Date().toISOString();
}

export function addNotification(db, payload) {
  db.notifications = db.notifications || [];
  db.notifications.unshift({
    id: `ntf-${Date.now()}-${Math.random().toString(16).slice(2, 6)}`,
    read: false,
    createdAt: nowIso(),
    ...payload
  });
}

export function addAudit(db, payload) {
  db.auditLog = db.auditLog || [];
  db.auditLog.unshift({
    id: `log-${Date.now()}-${Math.random().toString(16).slice(2, 6)}`,
    createdAt: nowIso(),
    ...payload
  });
}

export function openIncidentsFor(db, bookingId) {
  return (db.incidents || []).filter(
    (i) => i.bookingId === bookingId && !["resolvido", "rejeitado"].includes(i.status)
  );
}

export function buildContract(booking, item, user, settings) {
  return {
    id: `ctr-${booking.id}`,
    generatedAt: nowIso(),
    acceptedAt: booking.contractAcceptedAt || null,
    locador: item.owner,
    locadorId: item.ownerId,
    locatario: user?.name || booking.renterName,
    locatarioId: user?.id || booking.userId,
    product: item.title,
    description: item.description,
    photos: item.photos || [],
    period: { start: booking.startDate, end: booking.endDate, startTime: booking.startTime || "08:00", endTime: booking.endTime || "18:00", days: booking.days },
    pickupWindow: item.pickupWindow || "08:00 as 18:00",
    returnWindow: item.returnWindow || "08:00 as 18:00",
    rentalAmount: booking.rentalAmount,
    protectionFee: booking.protectionFee,
    deliveryFee: booking.deliveryFee,
    deposit: booking.deposit,
    usageRules: item.usageRules,
    latePolicy: `Atraso na devolução: tolerância de ${settings.lateToleranceHours}h. Depois, diária adicional de ${settings.lateFeeMultiplier}x.`,
    damagePolicy: "Desgaste normal não gera cobranca. Danos e perda seguem análise com evidencias de check-in e check-out.",
    cancellationPolicy: settings.cancellation,
    platformRules: "O Diuso intermedia anúncio, reserva, contrato, caução e suporte. A caução não e receita da plataforma.",
    responsibilities: {
      locatario: "Usar o item conforme as regras, devolver no prazo e registrar o estado na devolução.",
      locador: "Entregar o item no estado anunciado e registrar o check-in com evidencias.",
      diuso: "Intermediar pagamento, contrato, caução, ocorrências e repasse apos inspecao."
    }
  };
}

function hasNotification(db, bookingId, type) {
  return (db.notifications || []).some((n) => n.bookingId === bookingId && n.type === type);
}

export function applyLateIfNeeded(db, booking, settings) {
  if (["cancelado", "finalizado", "reembolsado"].includes(booking.status)) return booking;
  const now = new Date();
  const today = now.toISOString().slice(0, 10);
  const due = new Date(`${booking.endDate}T18:00:00`);
  const hours = (due.getTime() - now.getTime()) / 3600000;
  if (hours <= 24 && hours > 2 && !hasNotification(db, booking.id, "lembrete_24h")) {
    addNotification(db, {
      userId: booking.userId,
      bookingId: booking.id,
      role: "locatário",
      type: "lembrete_24h",
      title: "Devolução em 24 horas",
      body: "Falta um dia para devolver o item."
    });
  }
  if (hours <= 2 && hours > 0 && !hasNotification(db, booking.id, "lembrete_2h")) {
    addNotification(db, {
      userId: booking.userId,
      bookingId: booking.id,
      role: "locatário",
      type: "lembrete_2h",
      title: "Devolução em 2 horas",
      body: "A tolerância de atraso comeca a contar em breve."
    });
  }
  if (hours <= 0 && hours > -Number(settings.lateToleranceHours || 2) && !hasNotification(db, booking.id, "vencimento")) {
    addNotification(db, {
      userId: booking.userId,
      bookingId: booking.id,
      role: "locatário",
      type: "vencimento",
      title: "Horario de devolução",
      body: "O prazo de devolução venceu. Há tolerancia de 2 horas."
    });
  }
  if (booking.endDate && today > booking.endDate && !["finalizado", "cancelado", "reembolsado"].includes(booking.status)) {
    const extraDays = Math.max(1, Math.round((new Date(`${today}T00:00:00`) - new Date(`${booking.endDate}T00:00:00`)) / 86400000));
    booking.status = "atrasado";
    booking.lateDays = extraDays;
    booking.lateFee = lateFeeForDays(settings, booking.pricePerDay || booking.itemPricePerDay, extraDays);
    booking.lateCalculatedAt = nowIso();
    if (!booking.lateReason) booking.lateReason = "Prazo de devolução vencido";
    if (!hasNotification(db, booking.id, "atraso")) {
      addNotification(db, {
        userId: booking.userId,
        bookingId: booking.id,
        role: "locatário",
        type: "atraso",
        title: "Atraso na devolução",
        body: `Diaria adicional de ${settings.lateFeeMultiplier}x calculada automaticamente.`
      });
    }
  }
  return booking;
}

export function ownerCancelPenalty(settings, count) {
  if (count <= 1) return settings.ownerCancel.first;
  if (count === 2) return settings.ownerCancel.second;
  return settings.ownerCancel.repeat;
}

export function refundForCancel(settings, booking) {
  return cancellationPreview(settings, booking);
}

export function canReleaseDeposit(db, booking) {
  if (!["finalizado", "reembolsado"].includes(booking.status) && booking.inspectionStatus !== "aprovada") return false;
  return openIncidentsFor(db, booking.id).length === 0;
}

export function listingToItem(request) {
  return {
    id: `itm-${Date.now()}`,
    title: request.title,
    category: request.category,
    pricePerDay: Number(request.pricePerDay),
    weeklyPrice: Number(request.weeklyPrice || 0),
    monthlyPrice: Number(request.monthlyPrice || 0),
    deposit: Number(request.deposit || 0),
    depositSuggested: Number(request.deposit || 0),
    estimatedValue: Number(request.estimatedValue || 0),
    city: request.city,
    neighborhood: request.neighborhood,
    street: request.street || "",
    streetNumber: request.streetNumber || "",
    pickupAddress: [request.street, request.streetNumber, request.neighborhood, request.city].filter(Boolean).join(", "),
    owner: request.owner,
    ownerEmail: request.ownerEmail,
    ownerPhone: request.ownerPhone,
    ownerId: request.ownerUserId || "",
    ownerType: "partner",
    rating: 5,
    reviews: 0,
    available: true,
    condition: request.condition,
    description: request.description,
    specs: String(request.specs || "").split(",").map((s) => s.trim()).filter(Boolean),
    usageRules: request.usageRules || "",
    quantity: Number(request.quantity || 1),
    deliveryFee: Number(request.deliveryFee || DEFAULT_SETTINGS.deliveryFee || 0),
    pickupOrDelivery: "entrega_plataforma",
    listingStatus: "ativo",
    protectionEligible: true,
    photos: (request.photos || []).map((p) => ({
      filename: p.filename,
      originalname: p.originalname,
      url: `/uploads/listings/${p.filename}`
    })),
    rentalHistoryCount: 0,
    createdAt: nowIso()
  };
}

export function userStats(db, user) {
  const rentals = (db.bookings || []).filter((b) => b.userId === user.id);
  const ownedItems = (db.items || []).filter((i) => i.ownerId === user.ownerId || i.ownerEmail === user.email || i.owner === user.name);
  const ownerBookings = (db.bookings || []).filter((b) => ownedItems.some((i) => i.id === b.itemId));
  const reviews = (db.reviews || []).filter((r) => r.targetUserId === user.id);
  const avg = reviews.length
    ? moneyRound(reviews.reduce((sum, r) => sum + Number(r.stars || 0), 0) / reviews.length)
    : user.rating || 0;
  return {
    rentalsAsRenter: rentals.filter((b) => b.status === "finalizado").length,
    listings: ownedItems.length,
    rentalsAsOwner: ownerBookings.filter((b) => b.status === "finalizado").length,
    reviewsCount: reviews.length,
    rating: avg,
    identityVerified: Boolean(user.documentPhoto),
    paymentVerified: Boolean(user.paymentVerified),
    renterLevel: user.renterLevel || "bronze",
    renterSpent: user.renterSpent || 0,
    renterPaidCount: user.renterPaidCount || 0,
    goodHistory: avg >= 4.5 && (rentals.length + ownerBookings.length) >= 3 && !user.blocked,
    memberSince: user.createdAt || null
  };
}
