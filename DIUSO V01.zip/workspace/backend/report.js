function rank(rows, headers) {
  return [headers, ...(rows || []).map((row) => [row.title || row.label || "", row.count])];
}

export function analyticsSheets(data) {
  const totals = data.totals || {};
  const geo = data.geography || {};
  const generated = new Date(data.generatedAt || Date.now()).toLocaleString("pt-BR");

  const sheets = [];

  sheets.push({
    name: "Resumo",
    rows: [
      ["DIUSO — Relatorio de acessos"],
      ["Gerado em", generated],
      ["Período (dias)", data.rangeDays || 30],
      [],
      ["Indicador", "Valor"],
      ["Acessos no período", totals.visits || 0],
      ["Acessos no total", totals.visitsTotal || 0],
      ["Visitantes unicos", totals.uniqueVisitors || 0],
      ["Visitantes novos", totals.newVisitors || 0],
      ["Visitantes recorrentes", totals.returningVisitors || 0],
      ["Acessos hoje", totals.today || 0],
      ["Acessos ultimos 7 dias", totals.last7 || 0],
      ["Acessos humanos", totals.humanVisits || 0],
      ["Acessos de robo", totals.botVisits || 0],
      ["Acessos por visitante", totals.viewsPerVisitor || 0],
      ["Anúncios vistos", totals.views || 0],
      ["Buscas", totals.searches || 0],
      ["Itens curtidos", totals.likes || 0],
      ["Cadastros", totals.registrations || 0],
      ["Logins", totals.logins || 0],
      ["Reservas solicitadas", totals.bookings || 0],
      ["Locações pagas", totals.paid || 0],
      ["Vistas por reserva (%)", totals.viewToBooking || 0],
      ["Acessos por reserva (%)", totals.visitToBooking || 0],
      [],
      ["Acessos localizados", geo.located || 0],
      ["Acessos sem localizacao", geo.unknown || 0]
    ]
  });

  sheets.push({
    name: "Funil",
    rows: [["Etapa", "Quantidade"], ...(data.funnel || []).map((step) => [step.label, step.count])]
  });

  sheets.push({
    name: "Acessos por dia",
    rows: [["Data", "Acessos", "Visitantes unicos"], ...(data.timeline || []).map((row) => [row.date, row.visits, row.visitors])]
  });

  sheets.push({
    name: "Paises",
    rows: [["Pais", "Acessos"], ...(geo.countries || []).map((row) => [row.label, row.count])]
  });

  sheets.push({
    name: "Estados",
    rows: [["Estado / regiao", "Acessos"], ...(geo.regions || []).map((row) => [row.label, row.count])]
  });

  sheets.push({
    name: "Cidades",
    rows: [["Cidade", "Acessos"], ...(geo.cities || []).map((row) => [row.label, row.count])]
  });

  sheets.push({
    name: "Provedores",
    rows: [["Provedor de internet", "Acessos"], ...(geo.networks || []).map((row) => [row.label, row.count])]
  });

  sheets.push({
    name: "Visitantes por pais",
    rows: [["Pais", "Visitantes unicos"], ...(geo.visitorsByCountry || []).map((row) => [row.label, row.count])]
  });

  sheets.push({
    name: "Dispositivos",
    rows: rank(data.devices, ["Dispositivo", "Acessos"])
  });

  sheets.push({
    name: "Navegadores",
    rows: rank(data.browsers, ["Navegador", "Acessos"])
  });

  sheets.push({
    name: "Sistemas",
    rows: rank(data.operatingSystems, ["Sistema operacional", "Acessos"])
  });

  sheets.push({
    name: "Origens",
    rows: rank(data.sources, ["Origem", "Acessos"])
  });

  sheets.push({
    name: "Paginas",
    rows: rank(data.pages, ["Pagina", "Acessos"])
  });

  sheets.push({
    name: "Termos pesquisados",
    rows: rank(data.topSearches, ["Termo", "Buscas"])
  });

  sheets.push({
    name: "Cidades pesquisadas",
    rows: rank(data.topLocations, ["Cidade / bairro", "Buscas"])
  });

  sheets.push({
    name: "Categorias",
    rows: rank(data.topCategories, ["Categoria", "Interacoes"])
  });

  sheets.push({
    name: "Anúncios mais vistos",
    rows: [["Anúncio", "Visualizações"], ...(data.topItems || []).map((row) => [row.title, row.count])]
  });

  sheets.push({
    name: "Itens mais curtidos",
    rows: [["Anúncio", "Curtidas"], ...(data.topLiked || []).map((row) => [row.title, row.count])]
  });

  sheets.push({
    name: "Eventos",
    rows: rank(data.events, ["Evento", "Quantidade"])
  });

  sheets.push({
    name: "Horarios de pico",
    rows: [["Hora", "Acessos"], ...(data.byHour || []).map((row) => [row.label, row.count])]
  });

  sheets.push({
    name: "Acessos recentes",
    rows: [
      ["Quando", "De onde", "Pagina", "Dispositivo", "Navegador", "Sistema", "Origem", "Provedor", "IP", "Visitante"],
      ...(data.recent || []).map((visit) => [
        new Date(visit.at).toLocaleString("pt-BR"),
        visit.location || "Não identificado",
        visit.path,
        visit.device,
        visit.browser,
        visit.os,
        visit.source,
        visit.network || "",
        visit.ip || "",
        visit.visitorId || ""
      ])
    ]
  });

  return sheets;
}

export function analyticsFileName(data) {
  const stamp = new Date(data.generatedAt || Date.now()).toISOString().slice(0, 10);
  return `diuso-acessos-${stamp}.xlsx`;
}
