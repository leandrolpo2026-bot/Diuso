import crypto from "crypto";

const KEYLEN = 64;

export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(String(password), salt, KEYLEN).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password, stored) {
  const [salt, hash] = String(stored || "").split(":");
  if (!salt || !hash) return false;
  const check = crypto.scryptSync(String(password), salt, KEYLEN);
  const current = Buffer.from(hash, "hex");
  if (current.length !== check.length) return false;
  return crypto.timingSafeEqual(current, check);
}

export function createToken() {
  return crypto.randomBytes(32).toString("hex");
}

export function isAdmin(user) {
  return Boolean(user && (user.role === "admin" || user.role === "master"));
}

export function isMaster(user) {
  return Boolean(user && user.role === "master");
}

export function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    cpf: user.cpf,
    birthDate: user.birthDate,
    address: user.address,
    city: user.city,
    neighborhood: user.neighborhood,
    documentType: user.documentType,
    documentNumber: user.documentNumber,
    documentUploaded: Boolean(user.documentPhoto),
    createdAt: user.createdAt,
    role: user.role || "client",
    reputation: user.reputation || "regular",
    renterLevel: user.renterLevel || "bronze",
    renterSpent: user.renterSpent || 0,
    renterPaidCount: user.renterPaidCount || 0,
    identityVerified: Boolean(user.documentPhoto),
    paymentVerified: Boolean(user.paymentVerified),
    photoUrl: user.photoUrl || "",
    blocked: Boolean(user.blocked),
    quarantined: Boolean(user.quarantined),
    quarantinedAt: user.quarantinedAt || null,
    quarantineReason: user.quarantineReason || "",
    mustChangePassword: Boolean(user.mustChangePassword)
  };
}

export function adminUser(user) {
  if (!user) return null;
  return {
    ...publicUser(user),
    documentPhoto: user.documentPhoto || null
  };
}
