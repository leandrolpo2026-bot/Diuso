import nodemailer from "nodemailer";

export const ADMIN_EMAIL = "leandro.lpo1000@gmail.com";

function createTransport() {
  if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
    return nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: String(process.env.SMTP_SECURE || "") === "true",
      family: 4,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });
  }

  return nodemailer.createTransport({
    sendmail: true,
    newline: "unix",
    path: process.env.SENDMAIL_PATH || "/usr/sbin/sendmail"
  });
}

function withTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      setTimeout(() => reject(new Error("Tempo esgotado ao enviar e-mail")), ms);
    })
  ]);
}

export async function sendPasswordResetEmail({ user, resetUrl }) {
  const transporter = createTransport();
  const name = user.name || "usuário";
  const safeUrl = String(resetUrl || "");
  await withTimeout(
    transporter.sendMail({
      from: process.env.MAIL_FROM || "DIUSO <no-reply@diuso.local>",
      to: user.email,
      subject: "[DIUSO] Redefinir senha",
      text: `Ola, ${name}.\n\nRecebemos um pedido para redefinir a senha da sua conta DIUSO.\nAbra este link em ate 1 hora:\n${safeUrl}\n\nSe você não pediu isso, ignore este e-mail.`,
      html: `<p>Ola, <strong>${String(name).replace(/</g, "&lt;")}</strong>.</p><p>Recebemos um pedido para redefinir a senha da sua conta DIUSO.</p><p><a href="${safeUrl}">Redefinir senha</a></p><p>O link vale por 1 hora. Se você não pediu isso, ignore este e-mail.</p>`
    }),
    12000
  );
}

export async function sendListingRequestEmail({ request, files }) {
  const transporter = createTransport();
  const rows = [
    ["Titulo", request.title],
    ["Categoria", request.category],
    ["Condicao", request.condition],
    ["Diaria", `R$ ${request.pricePerDay}`],
    ["Caução", `R$ ${request.deposit}`],
    ["Quantidade", request.quantity],
    ["Cidade", request.city],
    ["Bairro", request.neighborhood],
    ["Logradouro", request.street],
    ["Número", request.streetNumber],
    ["Proprietario", request.owner],
    ["E-mail do anunciante", request.ownerEmail],
    ["Telefone do anunciante", request.ownerPhone],
    ["Destaques", request.specs],
    ["Descricao", request.description],
    ["Fotos enviadas", String(files.length)]
  ];

  const html = `
    <h2>Nova solicitacao de anúncio DIUSO</h2>
    <p>Uma pessoa pediu para anunciar um item. Isso <strong>não foi publicado</strong> no site. Análise e aprove manualmente.</p>
    <table cellpadding="6" style="border-collapse:collapse">
      ${rows
        .map(
          ([label, value]) =>
            `<tr><td style="border:1px solid #ddd"><strong>${label}</strong></td><td style="border:1px solid #ddd">${String(value || "").replace(/</g, "&lt;")}</td></tr>`
        )
        .join("")}
    </table>
    <p>ID da solicitacao: <strong>${request.id}</strong></p>
  `;

  const attachments = files.map((file, index) => ({
    filename: file.originalname || `foto-${index + 1}.jpg`,
    path: file.path
  }));

  await withTimeout(
    transporter.sendMail({
      from: process.env.MAIL_FROM || `DIUSO <no-reply@diuso.local>`,
      to: ADMIN_EMAIL,
      replyTo: request.ownerEmail,
      subject: `[DIUSO] Análise de anúncio: ${request.title}`,
      text: `Nova solicitacao de anúncio DIUSO (não publicada).\n\n${rows
        .map(([label, value]) => `${label}: ${value}`)
        .join("\n")}\n\nID: ${request.id}`,
      html,
      attachments
    }),
    12000
  );
}
