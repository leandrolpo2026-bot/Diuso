import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";
import multer from "multer";
import { categories, PLATFORM } from "./data.js";
import { SERVICE_CITIES, isActiveCity, mergeActiveCities, mergeCityCatalog, normalizeCity, titleCity } from "./cities.js";
import { sendListingRequestEmail, sendPasswordResetEmail } from "./mailer.js";
import { adminUser, createToken, hashPassword, isAdmin, isMaster, publicUser, verifyPassword } from "./auth.js";
import { readDb, STATUSES, writeDb } from "./store.js";
import {
  cancellationPreview,
  daysBetween,
  lateFeeForDays,
  mergeSettings,
  publicSettings,
  financialDashboard,
  quoteRental,
  syncRenterLevel
} from "./finance.js";
import {
  addAudit,
  addNotification,
  applyLateIfNeeded,
  buildContract,
  canReleaseDeposit,
  listingToItem,
  nowIso,
  openIncidentsFor,
  ownerCancelPenalty,
  userStats
} from "./ops.js";
import { chargeNoteHtml, formatDateBr, moneyBr, pixPayload, serviceOrderHtml } from "./pix.js";
import {
  buildAnalytics,
  recordEvent,
  recordItemView,
  recordLike,
  recordSearch,
  recordVisit
} from "./analytics.js";
import { geoFromHeaders, mergeGeo, readCache, requestIp, resolveGeo, writeCache } from "./geo.js";
import { buildXlsx } from "./xlsx.js";
import { analyticsFileName, analyticsSheets } from "./report.js";

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: "2mb" }));

const uploadsDir = path.join(process.cwd(), "storage", "listing-uploads");
const docsDir = path.join(process.cwd(), "storage", "document-uploads");
const evidenceDir = path.join(process.cwd(), "storage", "evidence-uploads");
fs.mkdirSync(uploadsDir, { recursive: true });
fs.mkdirSync(docsDir, { recursive: true });
fs.mkdirSync(evidenceDir, { recursive: true });

function diskStorage(dir) {
  return multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, dir),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname || "").slice(0, 8);
      cb(null, `${Date.now()}-${Math.random().toString(16).slice(2)}${ext}`);
    }
  });
}

const imageOnly = (_req, file, cb) => {
  if (String(file.mimetype || "").startsWith("image/")) cb(null, true);
  else cb(new Error("Envie apenas imagens"));
};

const proofOnly = (_req, file, cb) => {
  const type = String(file.mimetype || "");
  if (type.startsWith("image/") || type === "application/pdf") cb(null, true);
  else cb(new Error("Envie imagem ou PDF"));
};

const upload = multer({
  storage: diskStorage(uploadsDir),
  limits: { files: 12, fileSize: 6 * 1024 * 1024 },
  fileFilter: imageOnly
});

const uploadDoc = multer({
  storage: diskStorage(docsDir),
  limits: { files: 1, fileSize: 6 * 1024 * 1024 },
  fileFilter: imageOnly
});

const uploadEvidence = multer({
  storage: diskStorage(evidenceDir),
  limits: { files: 8, fileSize: 6 * 1024 * 1024 },
  fileFilter: imageOnly
});

const uploadProof = multer({
  storage: diskStorage(evidenceDir),
  limits: { files: 1, fileSize: 8 * 1024 * 1024 },
  fileFilter: proofOnly
});

app.use("/uploads/documents", express.static(docsDir));
app.use("/uploads/evidence", express.static(evidenceDir));
app.use("/uploads/listings", express.static(uploadsDir));

function digits(value) {
  return String(value || "").replace(/\D/g, "");
}

function requestToken(req) {
  const header = String(req.headers.authorization || "");
  if (header.startsWith("Bearer ")) return header.slice(7);
  return String(req.query?.token || "");
}

function currentUser(req, db) {
  const token = requestToken(req);
  if (!token) return null;
  const session = (db.sessions || []).find((s) => s.token === token);
  if (!session) return null;
  return (db.users || []).find((u) => u.id === session.userId) || null;
}

function passwordChangeAllowed(req) {
  const path = String(req.path || "");
  return path === "/api/auth/me" || path === "/api/auth/password" || path === "/api/auth/logout";
}

function blockIfMustChangePassword(req, res, user) {
  if (!user?.mustChangePassword || passwordChangeAllowed(req)) return false;
  res.status(403).json({ error: "Crie uma nova senha para continuar." });
  return true;
}

function requireUser(req, res) {
  const db = readDb();
  const user = currentUser(req, db);
  if (!user) {
    res.status(401).json({ error: "Cadastre-se para alugar. A navegação continua liberada." });
    return { db, user: null };
  }
  if (blockIfMustChangePassword(req, res, user)) {
    return { db, user: null };
  }
  return { db, user };
}

function requireAdmin(req, res) {
  const db = readDb();
  const user = currentUser(req, db);
  if (!user) {
    res.status(401).json({ error: "Entre com a conta de administrador." });
    return { db, user: null };
  }
  if (!isAdmin(user)) {
    res.status(403).json({ error: "Acesso restrito ao administrador." });
    return { db, user: null };
  }
  if (blockIfMustChangePassword(req, res, user)) {
    return { db, user: null };
  }
  return { db, user };
}

function requireMaster(req, res) {
  const auth = requireAdmin(req, res);
  if (!auth.user) return auth;
  if (!isMaster(auth.user)) {
    res.status(403).json({ error: "Acesso restrito ao administrador master." });
    return { db: auth.db, user: null };
  }
  return auth;
}

function requiredText(value) {
  return String(value || "").trim();
}

function parseMoneyBr(value) {
  const raw = String(value ?? "").trim();
  if (!raw) return NaN;
  if (raw.includes(",")) {
    return Number(raw.replace(/[^\d,-]/g, "").replace(/\./g, "").replace(",", "."));
  }
  return Number(raw.replace(/[^\d.-]/g, ""));
}

function parseTime(value, fallback = "08:00") {
  const time = String(value || "").trim();
  return /^\d{2}:\d{2}$/.test(time) ? time : fallback;
}

function ageFromBirthDate(value) {
  const birth = new Date(`${requiredText(value)}T00:00:00`);
  if (Number.isNaN(birth.getTime())) return -1;
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) age -= 1;
  return age;
}

function settingsOf(db) {
  return mergeSettings(db.settings);
}

function cityCatalogOf(db) {
  const settings = settingsOf(db);
  return mergeCityCatalog(settings.extraCities);
}

function activeCitiesOf(db) {
  const settings = settingsOf(db);
  return mergeActiveCities(settings.activeCities, settings.extraCities);
}

function resolveCityName(db, city) {
  const catalog = cityCatalogOf(db);
  return catalog.find((name) => normalizeCity(name) === normalizeCity(city)) || titleCity(city);
}

function citiesPayload(db) {
  return { all: cityCatalogOf(db), active: activeCitiesOf(db) };
}

function findBooking(db, id) {
  return (db.bookings || []).find((b) => b.id === id);
}

function itemOwnerUser(db, item) {
  return (db.users || []).find((u) =>
    u.id === item.ownerUserId ||
    u.email === item.ownerEmail ||
    u.name === item.owner
  ) || null;
}

function overlap(aStart, aEnd, bStart, bEnd) {
  return aStart <= bEnd && bStart <= aEnd;
}

function itemBookedRanges(bookings, itemId) {
  return bookings
    .filter((b) => b.itemId === itemId && b.status !== "cancelado" && b.status !== "cancelada")
    .map((b) => ({ start: b.startDate, end: b.endDate, status: b.status }));
}

function isAvailable(bookings, itemId, startDate, endDate) {
  return !itemBookedRanges(bookings, itemId).some((range) =>
    overlap(startDate, endDate, range.start, range.end)
  );
}

function quote(item, days, delivery, settings, extras = {}) {
  return quoteRental(item, days, delivery, settings || mergeSettings(), extras);
}

function evidenceFiles(files = []) {
  return files.map((file) => ({
    filename: file.filename,
    originalname: file.originalname,
    url: `/uploads/evidence/${file.filename}`
  }));
}

function proofFile(file) {
  if (!file) return null;
  return {
    filename: file.filename,
    originalname: file.originalname,
    mimeType: file.mimetype,
    url: `/uploads/evidence/${file.filename}`,
    uploadedAt: nowIso()
  };
}

function withBooking(db, booking) {
  const item = db.items.find((i) => i.id === booking.itemId) || null;
  const incidents = (db.incidents || []).filter((i) => i.bookingId === booking.id);
  const notifications = (db.notifications || []).filter((n) => n.bookingId === booking.id);
  return { ...booking, item, incidents, notifications };
}

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function addDaysIso(iso, days) {
  const [y, m, d] = String(iso).split("-").map(Number);
  const date = new Date(Date.UTC(y, m - 1, d));
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function revenueWindow(req, user) {
  const to = todayIso();
  const raw = String(req.query?.period || req.query?.days || "30").trim().toLowerCase();
  const master = isMaster(user);
  if (raw === "all") {
    if (!master) {
      return { period: "30", days: 30, from: addDaysIso(to, -29), to, limited: true };
    }
    return { period: "all", days: null, from: null, to, limited: false };
  }
  const requested = Number(raw) || 30;
  const maxDays = master ? 3650 : 30;
  const days = Math.min(Math.max(requested, 1), maxDays);
  return {
    period: String(days),
    days,
    from: addDaysIso(to, -(days - 1)),
    to,
    limited: !master && days === 30
  };
}

function bookingInWindow(booking, from, to) {
  const d = String(booking.createdAt || booking.startDate || "").slice(0, 10);
  if (!d) return !from;
  if (from && d < from) return false;
  if (to && d > to) return false;
  return true;
}

const OPEN_RENTAL_STATUSES = [
  "aguardando_confirmacao",
  "confirmado",
  "preparando",
  "em_entrega",
  "ativo",
  "aguardando_devolucao",
  "atrasado"
];

function openRentalsForItem(bookings, itemId) {
  return (bookings || []).filter((b) => b.itemId === itemId && OPEN_RENTAL_STATUSES.includes(b.status));
}

function availabilityOf(item, bookings) {
  if (item.listingStatus === "excluido") return "indisponível";
  if (item.listingStatus === "pausado" || item.available === false) return "pausado";
  if (item.maintenanceStatus === "manutenção") return "manutenção";
  const today = todayIso();
  const busy = bookings.some(
    (b) =>
      b.itemId === item.id &&
      !["cancelado", "cancelada", "finalizado", "reembolsado"].includes(b.status) &&
      overlap(today, today, b.startDate, b.endDate)
  );
  if (busy) return "alugado";
  return "disponível";
}

function confirmUserPassword(user, password) {
  return Boolean(user && verifyPassword(requiredText(password), user.passwordHash));
}

function listingPhoto(p) {
  if (!p) return null;
  if (typeof p === "string") {
    const url = p.startsWith("/uploads") || p.startsWith("http") ? p : `/uploads/listings/${p}`;
    return { filename: p, url };
  }
  const filename = p.filename || "";
  const url = p.url || (filename ? `/uploads/listings/${filename}` : "");
  return { ...p, filename, url };
}

function withItemMeta(item, db, viewer) {
  const settings = settingsOf(db);
  const reviews = (db.reviews || []).filter((r) => r.itemId === item.id || r.targetOwnerId === item.ownerId);
  const completed = (db.bookings || []).filter((b) => b.itemId === item.id && b.status === "finalizado").length;
  const depositInfo = quoteRental(item, 1, false, settings);
  const payload = {
    ...item,
    photos: (item.photos || []).map(listingPhoto).filter(Boolean),
    bookedRanges: itemBookedRanges(db.bookings, item.id),
    availability: availabilityOf(item, db.bookings),
    protectionLabel: item.protectionEligible ? "Proteção Diuso" : null,
    rentalCount: item.rentalHistoryCount || completed,
    reviewCount: reviews.length || item.reviews || 0,
    rating: item.rating,
    suggestedDeposit: depositInfo.deposit,
    estimatedValue: item.estimatedValue,
    weeklyPrice: item.weeklyPrice,
    monthlyPrice: item.monthlyPrice,
    deliveryFee: Number(settings.deliveryFee ?? item.deliveryFee ?? 0),
    pickupOrDelivery: "entrega_plataforma"
  };
  if (!isAdmin(viewer)) {
    delete payload.owner;
    delete payload.ownerEmail;
    delete payload.ownerPhone;
    delete payload.ownerId;
    delete payload.ownerUserId;
    delete payload.estimatedValue;
    delete payload.street;
    delete payload.streetNumber;
    delete payload.pickupAddress;
  }
  return payload;
}

app.use((req, res, next) => {
  if (!String(req.path || "").startsWith("/api/")) return next();
  const db = readDb();
  const user = currentUser(req, db);
  if (blockIfMustChangePassword(req, res, user)) return;
  next();
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "diuso", brand: PLATFORM.name, slogan: PLATFORM.slogan });
});

app.get("/api/settings", (_req, res) => {
  const db = readDb();
  res.json(publicSettings(settingsOf(db)));
});

app.get("/api/cities", (_req, res) => {
  const db = readDb();
  res.json(citiesPayload(db));
});

app.post("/api/admin/cities", (req, res) => {
  const auth = requireMaster(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const name = titleCity(req.body?.name || req.body?.city);
  if (name.length < 2) {
    return res.status(400).json({ error: "Informe o nome do município." });
  }
  const settings = settingsOf(db);
  if (cityCatalogOf(db).some((city) => normalizeCity(city) === normalizeCity(name))) {
    return res.status(409).json({ error: "Este município já está cadastrado." });
  }
  const extraCities = mergeCityCatalog([...(settings.extraCities || []), name]).filter(
    (city) => !SERVICE_CITIES.some((known) => normalizeCity(known) === normalizeCity(city))
  );
  db.settings = mergeSettings({ ...settings, extraCities });
  addAudit(db, { action: "cities.create", userId: user.id, payload: { city: name } });
  writeDb(db);
  res.json(citiesPayload(db));
});

app.put("/api/admin/cities", (req, res) => {
  const auth = requireMaster(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  if (!confirmMasterPassword(user, req.body?.password)) {
    return res.status(401).json({ error: "Informe a senha da conta master para ativar municípios." });
  }
  const extraCities = settingsOf(db).extraCities;
  const activeCities = mergeActiveCities(req.body?.activeCities, extraCities);
  if (!activeCities.length) {
    return res.status(400).json({ error: "Selecione pelo menos um município de atuação." });
  }
  db.settings = mergeSettings({ ...settingsOf(db), extraCities, activeCities });
  addAudit(db, { action: "cities.update", userId: user.id, payload: { activeCities } });
  writeDb(db);
  res.json(citiesPayload(db));
});

function visitorIdOf(req) {
  return String(req.headers["x-diuso-visitor"] || req.body?.visitorId || "").slice(0, 64);
}

app.post("/api/analytics/visit", (req, res) => {
  const db = readDb();
  const user = currentUser(req, db);
  const ip = requestIp(req);
  const headerGeo = geoFromHeaders(req.headers);
  const cachedGeo = headerGeo ? mergeGeo(headerGeo, readCache(db, ip)) : readCache(db, ip);
  const visit = recordVisit(
    db,
    {
      ...(req.body || {}),
      userId: user?.id || null,
      visitorId: visitorIdOf(req),
      ip,
      geo: cachedGeo
    },
    req
  );
  writeDb(db);
  res.status(201).json({ ok: true, id: visit.id, located: Boolean(cachedGeo) });

  const needsCity = !cachedGeo || !cachedGeo.city;
  if (needsCity && ip) {
    resolveGeo(ip)
      .then((resolved) => {
        if (!resolved) return;
        const geo = mergeGeo(headerGeo, resolved);
        const fresh = readDb();
        const target = (fresh.analytics?.visits || []).find((v) => v.id === visit.id);
        if (!target) return;
        target.geo = geo;
        writeCache(fresh, ip, geo);
        writeDb(fresh);
      })
      .catch(() => {});
  }
});

function analyticsDays(req) {
  return Math.min(Math.max(Number(req.query?.days) || 30, 1), 180);
}

app.get("/api/admin/analytics", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  res.json(buildAnalytics(auth.db, { days: analyticsDays(req) }));
});

app.get("/api/admin/analytics/export", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const data = buildAnalytics(auth.db, { days: analyticsDays(req) });
  const file = buildXlsx(analyticsSheets(data));
  addAudit(auth.db, { action: "analytics.export", userId: auth.user.id, payload: { days: data.rangeDays } });
  writeDb(auth.db);
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", `attachment; filename="${analyticsFileName(data)}"`);
  res.setHeader("Content-Length", file.length);
  res.send(file);
});

function confirmMasterPassword(user, password) {
  return Boolean(user && isMaster(user) && verifyPassword(requiredText(password), user.passwordHash));
}

app.post("/api/admin/settings/unlock", (req, res) => {
  const auth = requireMaster(req, res);
  if (!auth.user) return;
  if (!confirmMasterPassword(auth.user, req.body?.password)) {
    return res.status(401).json({ error: "Senha do administrador master invalida." });
  }
  addAudit(auth.db, { action: "settings.unlock", userId: auth.user.id });
  writeDb(auth.db);
  res.json({ ok: true });
});

app.put("/api/admin/settings", (req, res) => {
  const auth = requireMaster(req, res);
  if (!auth.user) return;
  if (!confirmMasterPassword(auth.user, req.body?.password)) {
    return res.status(401).json({ error: "Informe a senha do administrador master para salvar." });
  }
  const { db } = auth;
  const { password, ...payload } = req.body || {};
  db.settings = mergeSettings({ ...settingsOf(db), ...payload });
  addAudit(db, { action: "settings.update", payload });
  writeDb(db);
  res.json(publicSettings(db.settings));
});

app.get("/api/categories", (_req, res) => {
  const db = readDb();
  const featured = new Set(["festas", "eletrônicos", "ferramentas", "casa", "automotivo", "esportes", "cameras", "construção", "móveis", "outros"]);
  const withCount = categories.map((c) => ({
    ...c,
    count: db.items.filter((i) => i.category === c.id).length,
    featured: featured.has(c.id)
  }));
  res.json(withCount);
});

app.get("/api/reviews", (_req, res) => {
  const db = readDb();
  res.json((db.reviews || []).slice(0, 8));
});

app.get("/api/stats", (_req, res) => {
  const db = readDb();
  const active = db.bookings.filter((b) =>
    ["confirmado", "preparando", "em_entrega", "ativo", "aguardando_devolucao"].includes(b.status)
  );
  res.json({
    items: db.items.length,
    bookings: db.bookings.length,
    activeBookings: active.length,
    cities: [...new Set(db.items.map((i) => i.city))].length,
    avgPrice: Math.round(
      db.items.reduce((sum, i) => sum + i.pricePerDay, 0) / Math.max(db.items.length, 1)
    )
  });
});

app.get("/api/items", (req, res) => {
  const db = readDb();
  const { q, category, maxPrice, city, location } = req.query;
  const settings = settingsOf(db);
  const activeCities = activeCitiesOf(db);
  const staff = isAdmin(currentUser(req, db));
  let items = [...db.items];
  if (!staff) {
    items = items.filter((i) =>
      isActiveCity(i.city, activeCities, settings.extraCities) &&
      i.listingStatus !== "excluido" &&
      i.listingStatus !== "pausado"
    );
  }

  if (category && category !== "todos") {
    items = items.filter((i) => i.category === category);
  }
  const place = String(location || city || "").toLowerCase();
  if (place) {
    items = items.filter((i) =>
      String(i.city || "").toLowerCase().includes(place) ||
      String(i.neighborhood || "").toLowerCase().includes(place)
    );
  }
  if (maxPrice) {
    items = items.filter((i) => i.pricePerDay <= Number(maxPrice));
  }
  if (q) {
    const term = String(q).toLowerCase();
    items = items.filter(
      (i) =>
        i.title.toLowerCase().includes(term) ||
        i.description.toLowerCase().includes(term) ||
        i.neighborhood.toLowerCase().includes(term) ||
        String(i.city || "").toLowerCase().includes(term)
    );
  }

  const result = items.map((item) => withItemMeta(item, db, currentUser(req, db)));

  const term = String(q || "").trim();
  const searchPlace = String(location || city || "").trim();
  if (term || searchPlace) {
    const user = currentUser(req, db);
    recordSearch(db, {
      term,
      location: searchPlace,
      category: category && category !== "todos" ? category : "",
      results: result.length,
      params: req.originalUrl.slice(0, 160),
      userId: user?.id || null
    });
    writeDb(db);
  }

  res.json(result);
});

app.get("/api/items/:id", (req, res) => {
  const db = readDb();
  const item = db.items.find((i) => i.id === req.params.id);
  if (!item) return res.status(404).json({ error: "Item não encontrado" });
  const user = currentUser(req, db);
  const owner = userOwnsItem(user, item);
  if (item.listingStatus === "excluido" && !isAdmin(user) && !owner) {
    return res.status(404).json({ error: "Item não encontrado" });
  }
  if (!isAdmin(user) && !owner && !isActiveCity(item.city, settingsOf(db).activeCities, settingsOf(db).extraCities)) {
    return res.status(404).json({ error: "Item não encontrado" });
  }
  recordItemView(db, { itemId: item.id, userId: user?.id || null, visitorId: visitorIdOf(req) });
  writeDb(db);
  res.json(withItemMeta(item, db, user));
});

function canManageListing(user, item) {
  return isAdmin(user) || userOwnsItem(user, item);
}

app.post("/api/items/:id/pause", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const item = db.items.find((i) => i.id === req.params.id);
  if (!item || item.listingStatus === "excluido") return res.status(404).json({ error: "Item não encontrado" });
  if (!canManageListing(user, item)) {
    return res.status(403).json({ error: "Só o anunciante ou o administrador pode pausar este anúncio." });
  }
  const open = openRentalsForItem(db.bookings, item.id);
  item.listingStatus = "pausado";
  item.available = false;
  item.pausedAt = nowIso();
  item.pausedBy = user.id;
  addAudit(db, { action: "listing.pause", itemId: item.id, userId: user.id, openRentals: open.length });
  addNotification(db, {
    userId: item.ownerUserId || user.id,
    role: "proprietario",
    itemId: item.id,
    type: "anuncio_pausado",
    title: "Anúncio pausado",
    body: open.length
      ? `“${item.title}” foi pausado. Novas reservas estão bloqueadas. ${open.length} locação(ões) já feitas seguem ativas até a devolução.`
      : `“${item.title}” foi pausado. Ninguém pode reservar enquanto estiver pausado.`
  });
  writeDb(db);
  res.json({
    ok: true,
    item: withItemMeta(item, db, user),
    openRentals: open.length,
    message: open.length
      ? "Anúncio pausado. Reservas já feitas continuam no perfil do locatário até a data de devolução."
      : "Anúncio pausado. Não aceita novas reservas."
  });
});

app.post("/api/items/:id/resume", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const item = db.items.find((i) => i.id === req.params.id);
  if (!item || item.listingStatus === "excluido") return res.status(404).json({ error: "Item não encontrado" });
  if (!canManageListing(user, item)) {
    return res.status(403).json({ error: "Só o anunciante ou o administrador pode reativar este anúncio." });
  }
  if (item.listingStatus !== "pausado" && item.available !== false) {
    return res.status(400).json({ error: "Este anúncio não está pausado." });
  }
  item.listingStatus = "ativo";
  item.available = true;
  item.resumedAt = nowIso();
  item.resumedBy = user.id;
  addAudit(db, { action: "listing.resume", itemId: item.id, userId: user.id });
  writeDb(db);
  res.json({ ok: true, item: withItemMeta(item, db, user) });
});

app.post("/api/items/:id/remove", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const item = db.items.find((i) => i.id === req.params.id);
  if (!item || item.listingStatus === "excluido") return res.status(404).json({ error: "Item não encontrado" });
  if (!canManageListing(user, item)) {
    return res.status(403).json({ error: "Só o anunciante ou o administrador pode excluir este anúncio." });
  }
  if (!confirmUserPassword(user, req.body?.password)) {
    return res.status(401).json({ error: "Informe a senha da conta para excluir o anúncio." });
  }
  const open = openRentalsForItem(db.bookings, item.id);
  item.listingStatus = "excluido";
  item.available = false;
  item.removedAt = nowIso();
  item.removedBy = user.id;
  addAudit(db, { action: "listing.remove", itemId: item.id, userId: user.id, openRentals: open.length });
  addNotification(db, {
    userId: item.ownerUserId || user.id,
    role: "proprietario",
    itemId: item.id,
    type: "anuncio_excluido",
    title: "Anúncio excluído",
    body: open.length
      ? `“${item.title}” saiu do catálogo. ${open.length} locação(ões) já reservadas seguem ativas. Estorno, se necessário, só o administrador pode fazer.`
      : `“${item.title}” foi excluído do catálogo.`
  });
  writeDb(db);
  res.json({
    ok: true,
    openRentals: open.length,
    message: open.length
      ? "Anúncio excluído do catálogo. Reservas já feitas continuam no perfil do locatário. Estorno, se necessário, só o administrador pode fazer."
      : "Anúncio excluído."
  });
});

app.post("/api/quote", (req, res) => {
  const { itemId, startDate, endDate, delivery } = req.body || {};
  const db = readDb();
  const item = db.items.find((i) => i.id === itemId);
  if (!item) return res.status(404).json({ error: "Item não encontrado" });
  if (startDate && endDate && endDate < startDate) {
    return res.status(400).json({ error: "A data de devolução deve ser igual ou posterior a data de retirada." });
  }
  const days = startDate && endDate ? daysBetween(startDate, endDate) : 0;
  const settings = settingsOf(db);
  const user = currentUser(req, db);
  const renterLevel = user ? syncRenterLevel(user, db.bookings, settings) : "bronze";
  if (user) writeDb(db);
  const pricing = quote(item, days, true, settings, { renterLevel });
  const cancelPreview = startDate
    ? cancellationPreview(settingsOf(db), { startDate, rentalAmount: pricing.rentalAmount, protectionFee: pricing.protectionFee, deliveryFee: pricing.deliveryFee, deposit: pricing.deposit })
    : null;
  res.json({
    ...pricing,
    cancellationPreview: cancelPreview,
    renterLevel,
    depositNote: renterLevel === "ouro"
      ? "Nivel Ouro: isento de caução."
      : renterLevel === "prata"
        ? "Nivel Prata: 50% da caução. Valor temporario, devolvido apos a inspecao."
        : "Nivel Bronze: 100% da caução. Valor temporario, devolvido apos a inspecao.",
    protectionNote: "Taxa relacionada aos mecanismos de protecao, suporte, intermediacao, prevencao de fraude e gestao da locação. Não e um seguro."
  });
});

app.get("/api/auth/me", (req, res) => {
  const db = readDb();
  const user = currentUser(req, db);
  if (!user) return res.json({ user: null });
  syncRenterLevel(user, db.bookings, settingsOf(db));
  writeDb(db);
  res.json({ user: publicUser(user) });
});

app.post("/api/auth/register", (req, res, next) => {
  uploadDoc.single("documentPhoto")(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || "Falha no envio do documento" });
    next();
  });
}, (req, res) => {
  const body = req.body || {};
  const fields = {
    name: requiredText(body.name),
    email: requiredText(body.email).toLowerCase(),
    phone: requiredText(body.phone),
    cpf: digits(body.cpf),
    birthDate: requiredText(body.birthDate),
    address: requiredText(body.address),
    city: requiredText(body.city),
    neighborhood: requiredText(body.neighborhood),
    documentType: requiredText(body.documentType),
    documentNumber: digits(body.documentNumber),
    password: requiredText(body.password)
  };

  const missing = Object.entries(fields).filter(([, value]) => !value).map(([key]) => key);
  if (missing.length) {
    return res.status(400).json({ error: `Preencha todos os dados pessoais. Faltando: ${missing.join(", ")}` });
  }
  if (fields.cpf.length !== 11) {
    return res.status(400).json({ error: "Informe um CPF com 11 dígitos" });
  }
  if (ageFromBirthDate(fields.birthDate) < 18) {
    return res.status(400).json({ error: "O cadastro é permitido apenas para maiores de 18 anos" });
  }
  if (!fields.documentNumber) {
    return res.status(400).json({ error: "Informe o número do documento apenas com números" });
  }
  if (fields.password.length < 6) {
    return res.status(400).json({ error: "A senha precisa ter no mínimo 6 caracteres" });
  }
  if (!req.file) {
    return res.status(400).json({ error: "Envie a foto do documento" });
  }

  const db = readDb();
  db.users = db.users || [];
  const exists = db.users.find(
    (u) => String(u.email || "").toLowerCase() === fields.email || digits(u.cpf) === fields.cpf
  );
  if (exists) {
    return res.status(409).json({ error: "Já existe um perfil com este e-mail ou CPF. Entre na conta." });
  }

  const user = {
    id: `usr-${Date.now()}`,
    name: fields.name,
    email: fields.email,
    phone: fields.phone,
    cpf: fields.cpf,
    birthDate: fields.birthDate,
    address: fields.address,
    city: fields.city,
    neighborhood: fields.neighborhood,
    documentType: fields.documentType,
    documentNumber: fields.documentNumber,
    documentPhoto: {
      filename: req.file.filename,
      originalname: req.file.originalname,
      path: req.file.path,
      url: `/uploads/documents/${req.file.filename}`
    },
    passwordHash: hashPassword(fields.password),
    role: "client",
    renterLevel: "bronze",
    renterSpent: 0,
    renterPaidCount: 0,
    mustChangePassword: true,
    createdAt: new Date().toISOString()
  };

  const token = createToken();
  db.users.unshift(user);
  db.sessions = db.sessions || [];
  db.sessions.unshift({ token, userId: user.id, createdAt: new Date().toISOString() });
  recordEvent(db, { type: "register", userId: user.id, meta: { city: user.city } });
  writeDb(db);
  res.status(201).json({ user: publicUser(user), token });
});

app.post("/api/auth/login", (req, res) => {
  const email = requiredText(req.body?.email).toLowerCase();
  const password = requiredText(req.body?.password);
  if (!email || !password) {
    return res.status(400).json({ error: "Informe e-mail e senha" });
  }

  const db = readDb();
  const user = (db.users || []).find((u) => String(u.email || "").toLowerCase() === email && u.passwordHash);
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return res.status(401).json({ error: "E-mail ou senha inválidos" });
  }
  if (!isAdmin(user) && !user.documentPhoto) {
    return res.status(403).json({ error: "Complete o cadastro com a foto do documento para alugar." });
  }

  const token = createToken();
  db.sessions = db.sessions || [];
  db.sessions.unshift({ token, userId: user.id, createdAt: new Date().toISOString() });
  recordEvent(db, { type: "login", userId: user.id, meta: { role: user.role || "client" } });
  writeDb(db);
  res.json({ user: publicUser(user), token });
});

app.post("/api/auth/logout", (req, res) => {
  const header = String(req.headers.authorization || "");
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  const db = readDb();
  db.sessions = (db.sessions || []).filter((s) => s.token !== token);
  writeDb(db);
  res.json({ ok: true });
});

app.put("/api/auth/profile", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const body = req.body || {};
  const fields = {
    name: requiredText(body.name),
    email: requiredText(body.email).toLowerCase(),
    phone: requiredText(body.phone),
    birthDate: requiredText(body.birthDate),
    address: requiredText(body.address),
    city: requiredText(body.city),
    neighborhood: requiredText(body.neighborhood)
  };
  const missing = Object.entries(fields).filter(([, value]) => !value).map(([key]) => key);
  if (missing.length) {
    return res.status(400).json({ error: `Preencha todos os dados pessoais. Faltando: ${missing.join(", ")}` });
  }
  if (ageFromBirthDate(fields.birthDate) < 18) {
    return res.status(400).json({ error: "O cadastro é permitido apenas para maiores de 18 anos" });
  }
  const taken = (db.users || []).find(
    (u) => u.id !== user.id && String(u.email || "").toLowerCase() === fields.email
  );
  if (taken) {
    return res.status(409).json({ error: "Já existe um perfil com este e-mail." });
  }
  Object.assign(user, fields);
  writeDb(db);
  res.json({ user: publicUser(user) });
});

app.post("/api/auth/password", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const currentPassword = requiredText(req.body?.currentPassword);
  const newPassword = requiredText(req.body?.newPassword);
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: "Informe a senha atual e a nova senha" });
  }
  if (!verifyPassword(currentPassword, user.passwordHash)) {
    return res.status(401).json({ error: "Senha atual invalida" });
  }
  if (newPassword.length < 6) {
    return res.status(400).json({ error: "A senha precisa ter no mínimo 6 caracteres" });
  }
  if (currentPassword === newPassword) {
    return res.status(400).json({ error: "A nova senha precisa ser diferente da atual" });
  }
  user.passwordHash = hashPassword(newPassword);
  user.mustChangePassword = false;
  const currentToken = requestToken(req);
  db.sessions = (db.sessions || []).filter((s) => s.userId !== user.id || s.token === currentToken);
  writeDb(db);
  res.json({ ok: true, user: publicUser(user) });
});

function publicOrigin(req) {
  const proto = String(req.headers["x-forwarded-proto"] || req.protocol || "https").split(",")[0].trim();
  const host = String(req.headers["x-forwarded-host"] || req.headers.host || "").split(",")[0].trim();
  if (!host) return "";
  return `${proto}://${host}`;
}

function expirePasswordResets(db) {
  const now = Date.now();
  db.passwordResets = (db.passwordResets || []).filter((entry) => {
    if (entry.usedAt) return now - new Date(entry.usedAt).getTime() < 7 * 86400000;
    return new Date(entry.expiresAt).getTime() > now;
  });
}

app.post("/api/auth/forgot-password", async (req, res) => {
  const email = requiredText(req.body?.email).toLowerCase();
  if (!email) return res.status(400).json({ error: "Informe o e-mail da conta." });
  const db = readDb();
  expirePasswordResets(db);
  const user = (db.users || []).find((u) => String(u.email || "").toLowerCase() === email && u.passwordHash);
  const generic = { ok: true, message: "Se este e-mail estiver cadastrado, enviamos as instruções para redefinir a senha." };
  if (!user || isAdmin(user)) {
    writeDb(db);
    return res.json(generic);
  }
  const token = createToken();
  const reset = {
    id: `rst-${Date.now()}`,
    token,
    userId: user.id,
    email: user.email,
    createdAt: nowIso(),
    expiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
    usedAt: null,
    emailSent: false
  };
  db.passwordResets = db.passwordResets || [];
  db.passwordResets.unshift(reset);
  const origin = publicOrigin(req);
  const resetUrl = `${origin}/redefinir-senha?token=${encodeURIComponent(token)}`;
  try {
    await sendPasswordResetEmail({ user, resetUrl });
    reset.emailSent = true;
  } catch (err) {
    reset.emailSent = false;
    reset.emailError = err.message;
    console.error("Falha ao enviar e-mail de redefinicao:", err.message);
  }
  addAudit(db, { action: "auth.forgot-password", userId: user.id, emailSent: reset.emailSent });
  writeDb(db);
  res.json(generic);
});

app.get("/api/auth/reset-password", (req, res) => {
  const token = requiredText(req.query?.token);
  if (!token) return res.status(400).json({ error: "Informe o token." });
  const db = readDb();
  expirePasswordResets(db);
  const reset = (db.passwordResets || []).find((entry) => entry.token === token);
  if (!reset || reset.usedAt || new Date(reset.expiresAt).getTime() <= Date.now()) {
    return res.status(400).json({ error: "Este link expirou ou já foi usado. Peça um novo." });
  }
  const user = (db.users || []).find((u) => u.id === reset.userId);
  if (!user || isAdmin(user)) {
    return res.status(400).json({ error: "Este link não e valido." });
  }
  res.json({ ok: true, email: user.email });
});

app.post("/api/auth/reset-password", (req, res) => {
  const token = requiredText(req.body?.token);
  const newPassword = requiredText(req.body?.newPassword);
  if (!token || !newPassword) {
    return res.status(400).json({ error: "Informe o token e a nova senha." });
  }
  if (newPassword.length < 6) {
    return res.status(400).json({ error: "A senha precisa ter no mínimo 6 caracteres" });
  }
  const db = readDb();
  expirePasswordResets(db);
  const reset = (db.passwordResets || []).find((entry) => entry.token === token);
  if (!reset || reset.usedAt || new Date(reset.expiresAt).getTime() <= Date.now()) {
    return res.status(400).json({ error: "Este link expirou ou já foi usado. Peça um novo." });
  }
  const user = (db.users || []).find((u) => u.id === reset.userId);
  if (!user || isAdmin(user)) {
    return res.status(400).json({ error: "Este link não e valido." });
  }
  user.passwordHash = hashPassword(newPassword);
  user.mustChangePassword = false;
  reset.usedAt = nowIso();
  db.sessions = (db.sessions || []).filter((s) => s.userId !== user.id);
  addAudit(db, { action: "auth.reset-password", userId: user.id });
  writeDb(db);
  res.json({ ok: true });
});

function staffPublic(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    createdAt: user.createdAt,
    mustChangePassword: Boolean(user.mustChangePassword)
  };
}

app.get("/api/admin/users", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  res.json((auth.db.users || []).filter((u) => u.email && !isAdmin(u)).map(adminUser));
});

app.post("/api/admin/users/:id/quarantine", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const target = (db.users || []).find((u) => u.id === req.params.id);
  if (!target || isAdmin(target)) {
    return res.status(404).json({ error: "Usuário não encontrado." });
  }
  const action = requiredText(req.body?.action) || "release";
  if (action === "release") {
    target.quarantined = false;
    target.quarantineReleasedAt = nowIso();
    target.quarantineReleasedBy = user.id;
    target.quarantineReason = "";
  } else {
    target.quarantined = true;
    target.quarantinedAt = nowIso();
    target.quarantineReason = requiredText(req.body?.reason) || "Quarentena aplicada pelo administrador.";
  }
  addAudit(db, { action: `user.quarantine.${action}`, userId: user.id, targetId: target.id });
  writeDb(db);
  res.json(adminUser(target));
});

app.get("/api/admin/staff", (req, res) => {
  const auth = requireMaster(req, res);
  if (!auth.user) return;
  res.json((auth.db.users || []).filter((u) => isAdmin(u)).map(staffPublic));
});

app.post("/api/admin/staff", (req, res) => {
  const auth = requireMaster(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const name = requiredText(req.body?.name);
  const email = requiredText(req.body?.email).toLowerCase();
  const password = requiredText(req.body?.password);
  const role = requiredText(req.body?.role);
  if (!name || !email || !password) {
    return res.status(400).json({ error: "Informe nome, e-mail e senha." });
  }
  if (!["admin", "master"].includes(role)) {
    return res.status(400).json({ error: "O cargo precisa ser administrador ou administrador master." });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: "A senha precisa ter no mínimo 6 caracteres" });
  }
  const exists = (db.users || []).find((u) => String(u.email || "").toLowerCase() === email);
  if (exists) {
    return res.status(409).json({ error: "Já existe um perfil com este e-mail." });
  }
  const staff = {
    id: `usr-${Date.now()}`,
    name,
    email,
    phone: "",
    role,
    reputation: "regular",
    renterLevel: "bronze",
    renterSpent: 0,
    renterPaidCount: 0,
    passwordHash: hashPassword(password),
    mustChangePassword: true,
    createdAt: nowIso()
  };
  db.users = db.users || [];
  db.users.unshift(staff);
  addAudit(db, { action: "staff.create", userId: user.id, staffId: staff.id, role });
  writeDb(db);
  res.status(201).json({ ok: true, user: staffPublic(staff) });
});

app.post("/api/admin/staff/:id/reset-password", (req, res) => {
  const auth = requireMaster(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const newPassword = requiredText(req.body?.newPassword);
  if (newPassword.length < 6) {
    return res.status(400).json({ error: "A senha precisa ter no mínimo 6 caracteres" });
  }
  const target = (db.users || []).find((u) => u.id === req.params.id);
  if (!target || !isAdmin(target)) {
    return res.status(404).json({ error: "Administrador não encontrado." });
  }
  target.passwordHash = hashPassword(newPassword);
  target.mustChangePassword = target.id !== user.id;
  db.sessions = (db.sessions || []).filter((s) => s.userId !== target.id);
  addAudit(db, { action: "staff.reset-password", userId: user.id, staffId: target.id });
  writeDb(db);
  res.json({ ok: true });
});

app.post("/api/admin/users/:id/reset-password", (req, res) => {
  const auth = requireMaster(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const newPassword = requiredText(req.body?.newPassword);
  if (newPassword.length < 6) {
    return res.status(400).json({ error: "A senha precisa ter no mínimo 6 caracteres" });
  }
  const target = (db.users || []).find((u) => u.id === req.params.id);
  if (!target || isAdmin(target)) {
    return res.status(404).json({ error: "Usuário não encontrado." });
  }
  target.passwordHash = hashPassword(newPassword);
  target.mustChangePassword = true;
  db.sessions = (db.sessions || []).filter((s) => s.userId !== target.id);
  addAudit(db, { action: "user.reset-password", userId: user.id, targetId: target.id });
  writeDb(db);
  res.json({ ok: true });
});

function userOwnsItem(user, item) {
  return Boolean(
    user &&
    item &&
    (item.ownerUserId === user.id || item.ownerEmail === user.email || item.owner === user.name)
  );
}

function hasOpenActivity(db, user) {
  const open = ["aguardando_confirmacao", "confirmado", "preparando", "em_entrega", "ativo", "aguardando_devolucao", "atrasado"];
  const ownedIds = new Set((db.items || []).filter((item) => userOwnsItem(user, item)).map((item) => item.id));
  return (db.bookings || []).some((booking) => {
    if (!open.includes(booking.status)) return false;
    return booking.userId === user.id || booking.ownerUserId === user.id || ownedIds.has(booking.itemId);
  });
}

function purgeClientProfile(db, target) {
  db.users = (db.users || []).filter((u) => u.id !== target.id);
  db.sessions = (db.sessions || []).filter((s) => s.userId !== target.id);
  db.passwordResets = (db.passwordResets || []).filter((entry) => entry.userId !== target.id);
  db.notifications = (db.notifications || []).filter((n) => n.userId !== target.id);
  db.listingRequests = (db.listingRequests || []).filter(
    (request) => request.ownerUserId !== target.id && request.ownerEmail !== target.email
  );
  db.items = (db.items || []).map((item) => {
    if (!userOwnsItem(target, item)) return item;
    return { ...item, available: false, ownerRemovedAt: nowIso() };
  });
}

app.post("/api/admin/staff/:id/remove", (req, res) => {
  const auth = requireMaster(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  if (!confirmMasterPassword(user, req.body?.password)) {
    return res.status(401).json({ error: "Informe a senha do administrador master para excluir." });
  }
  const target = (db.users || []).find((u) => u.id === req.params.id);
  if (!target || !isAdmin(target)) {
    return res.status(404).json({ error: "Administrador não encontrado." });
  }
  if (target.id === user.id) {
    return res.status(400).json({ error: "Você não pode excluir a própria conta." });
  }
  const masters = (db.users || []).filter((u) => u.role === "master");
  if (target.role === "master" && masters.length <= 1) {
    return res.status(400).json({ error: "E preciso manter pelo menos um administrador master." });
  }
  db.users = (db.users || []).filter((u) => u.id !== target.id);
  db.sessions = (db.sessions || []).filter((s) => s.userId !== target.id);
  addAudit(db, { action: "staff.remove", userId: user.id, staffId: target.id, role: target.role });
  writeDb(db);
  res.json({ ok: true });
});

app.post("/api/admin/users/:id/remove", (req, res) => {
  const auth = requireMaster(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  if (!confirmMasterPassword(user, req.body?.password)) {
    return res.status(401).json({ error: "Informe a senha do administrador master para excluir." });
  }
  const target = (db.users || []).find((u) => u.id === req.params.id);
  if (!target || isAdmin(target)) {
    return res.status(404).json({ error: "Usuário não encontrado." });
  }
  if (hasOpenActivity(db, target)) {
    return res.status(409).json({ error: "Não e possível excluir: há locação em andamento neste perfil." });
  }
  purgeClientProfile(db, target);
  addAudit(db, { action: "user.remove", userId: user.id, targetId: target.id, email: target.email });
  writeDb(db);
  res.json({ ok: true });
});

function withListingPhotos(request) {
  if (!request) return request;
  return {
    ...request,
    photos: (request.photos || []).map(listingPhoto).filter(Boolean)
  };
}

function listingOwnedBy(user, request) {
  if (!user || !request) return false;
  if (request.ownerUserId && request.ownerUserId === user.id) return true;
  return String(request.ownerEmail || "").toLowerCase() === String(user.email || "").toLowerCase();
}

function applyListingRequestEdits(db, request, body, files = []) {
  const textKeys = [
    "title",
    "category",
    "city",
    "neighborhood",
    "street",
    "streetNumber",
    "owner",
    "ownerEmail",
    "ownerPhone",
    "description",
    "specs",
    "condition",
    "usageRules"
  ];
  for (const key of textKeys) {
    if (body[key] == null) continue;
    const value = requiredText(body[key]);
    if (!value) return { error: `Informe ${key}.` };
    request[key] = value;
  }
  if (body.quantity != null) {
    const quantity = Number(requiredText(body.quantity));
    if (!(quantity > 0)) return { error: "Quantidade deve ser maior que zero." };
    request.quantity = quantity;
  }
  const moneyKeys = ["pricePerDay", "deposit", "estimatedValue", "weeklyPrice", "monthlyPrice"];
  for (const key of moneyKeys) {
    if (body[key] == null || body[key] === "") continue;
    const amount = parseMoneyBr(body[key]);
    if (Number.isNaN(amount) || amount < 0) return { error: `Informe um valor válido em ${key}.` };
    if (key === "pricePerDay" && !(amount > 0)) return { error: "Preço diário deve ser maior que zero." };
    request[key] = amount;
  }
  if (request.city) {
    request.city = resolveCityName(db, request.city) || request.city;
  }

  const hasPhotoChange = body.keepPhotos != null || body.photoOrder != null || files.length > 0;
  if (hasPhotoChange) {
    const current = request.photos || [];
    const byName = new Map(current.map((p) => [p.filename, p]));
    let order = [];
    const rawOrder = body.photoOrder;
    if (typeof rawOrder === "string" && rawOrder.trim()) {
      try {
        order = JSON.parse(rawOrder);
      } catch {
        order = rawOrder.split(",").map((s) => s.trim()).filter(Boolean);
      }
    } else if (Array.isArray(rawOrder)) {
      order = rawOrder;
    } else {
      const rawKeep = body.keepPhotos;
      if (typeof rawKeep === "string" && rawKeep.trim()) {
        try {
          order = JSON.parse(rawKeep);
        } catch {
          order = rawKeep.split(",").map((s) => s.trim()).filter(Boolean);
        }
      } else if (Array.isArray(rawKeep)) {
        order = rawKeep;
      } else {
        order = current.map((p) => p.filename);
      }
      files.forEach((_, index) => order.push(`new:${index}`));
    }
    const next = [];
    for (const token of order) {
      const key = String(token || "");
      if (key.startsWith("new:")) {
        const file = files[Number(key.slice(4))];
        if (!file) continue;
        next.push({
          filename: file.filename,
          originalname: file.originalname,
          path: file.path,
          size: file.size
        });
      } else if (byName.has(key)) {
        next.push(byName.get(key));
      }
    }
    if (next.length < 6) return { error: "O anúncio precisa de no mínimo 6 fotos." };
    if (next.length > 12) return { error: "Envie no máximo 12 fotos." };
    request.photos = next;
  }
  return { request };
}

app.get("/api/listing-requests", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  res.json((auth.db.listingRequests || []).map(withListingPhotos));
});

app.get("/api/listing-requests/:id", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const request = (auth.db.listingRequests || []).find((r) => r.id === req.params.id);
  if (!request) return res.status(404).json({ error: "Solicitacao não encontrada" });
  res.json(withListingPhotos(request));
});

function maybeListingPhotos(req, res, next) {
  const type = String(req.headers["content-type"] || "");
  if (!type.includes("multipart/form-data")) return next();
  return upload.array("photos", 12)(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || "Falha no envio das fotos" });
    next();
  });
}

app.patch("/api/listing-requests/:id", maybeListingPhotos, (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const { db } = auth;
  const request = (db.listingRequests || []).find((r) => r.id === req.params.id);
  if (!request) return res.status(404).json({ error: "Solicitacao não encontrada" });
  if (request.status !== "aguardando_analise") {
    return res.status(400).json({ error: "Só é possível editar solicitações aguardando análise." });
  }
  const result = applyListingRequestEdits(db, request, req.body || {}, req.files || []);
  if (result.error) return res.status(400).json({ error: result.error });
  addAudit(db, { action: "listing.edit", requestId: request.id });
  writeDb(db);
  res.json({ ok: true, request: withListingPhotos(request) });
});

app.post("/api/listing-requests", (req, res, next) => {
  upload.array("photos", 12)(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || "Falha no envio das fotos" });
    next();
  });
}, async (req, res) => {
    const auth = requireUser(req, res);
    if (!auth.user) return;
    const files = req.files || [];
    const body = req.body || {};
    const {
      title,
      category,
      pricePerDay,
      deposit,
      city,
      neighborhood,
      street,
      streetNumber,
      owner,
      ownerEmail,
      ownerPhone,
      description,
      specs,
      condition,
      quantity,
      estimatedValue,
      weeklyPrice,
      monthlyPrice,
      usageRules
    } = body;

    const fields = {
      title: requiredText(title),
      category: requiredText(category),
      pricePerDay: requiredText(pricePerDay),
      deposit: requiredText(deposit),
      city: requiredText(city),
      neighborhood: requiredText(neighborhood),
      street: requiredText(street),
      streetNumber: requiredText(streetNumber),
      owner: requiredText(owner),
      ownerEmail: requiredText(ownerEmail),
      ownerPhone: requiredText(ownerPhone),
      description: requiredText(description),
      specs: requiredText(specs),
      condition: requiredText(condition),
      quantity: requiredText(quantity),
      estimatedValue: requiredText(estimatedValue),
      weeklyPrice: requiredText(weeklyPrice) || "0",
      monthlyPrice: requiredText(monthlyPrice) || "0",
      usageRules: requiredText(usageRules) || "Use o item apenas no período contratado e devolva com todos os acessorios.",
      pickupOrDelivery: "entrega_plataforma"
    };

    const missing = Object.entries(fields).filter(([, value]) => !value).map(([key]) => key);
    if (missing.length) {
      return res.status(400).json({ error: `Todos os campos são obrigatórios. Faltando: ${missing.join(", ")}` });
    }
    if (files.length < 6) {
      return res.status(400).json({ error: "Envie no mínimo 6 fotos do item" });
    }
    const pricePerDayValue = parseMoneyBr(fields.pricePerDay);
    const depositValue = parseMoneyBr(fields.deposit);
    const estimatedValueAmount = parseMoneyBr(fields.estimatedValue);
    const weeklyPriceValue = parseMoneyBr(fields.weeklyPrice || "0");
    const monthlyPriceValue = parseMoneyBr(fields.monthlyPrice || "0");
    if (!(pricePerDayValue > 0) || Number(fields.quantity) <= 0) {
      return res.status(400).json({ error: "Preço e quantidade devem ser maiores que zero" });
    }
    if (!(depositValue >= 0) || !(estimatedValueAmount >= 0)) {
      return res.status(400).json({ error: "Informe caução e valor estimado em reais." });
    }

    const db = auth.db;
    const user = auth.user;
    const extraCities = settingsOf(db).extraCities;
    const activeCities = activeCitiesOf(db);
    if (!isActiveCity(fields.city, activeCities, extraCities)) {
      return res.status(400).json({ error: "Este município ainda não está na área de atuação da DIUSO." });
    }
    const cityName = resolveCityName(db, fields.city) || fields.city;
    const request = {
      id: `req-${Date.now()}`,
      ...fields,
      city: cityName,
      pricePerDay: pricePerDayValue,
      deposit: depositValue,
      deliveryFee: Number(settingsOf(db).deliveryFee || 0),
      quantity: Number(fields.quantity),
      estimatedValue: estimatedValueAmount,
      weeklyPrice: weeklyPriceValue || 0,
      monthlyPrice: monthlyPriceValue || 0,
      ownerUserId: user?.id || "",
      photos: files.map((file) => ({
        filename: file.filename,
        originalname: file.originalname,
        path: file.path,
        size: file.size
      })),
      status: "aguardando_analise",
      published: false,
      createdAt: new Date().toISOString()
    };

    db.listingRequests = db.listingRequests || [];
    db.listingRequests.unshift(request);
    writeDb(db);

    try {
      await sendListingRequestEmail({ request, files });
      request.emailSent = true;
    } catch (mailError) {
      console.error("Falha ao enviar e-mail de anúncio:", mailError.message);
      request.emailSent = false;
      request.emailError = mailError.message;
    }
    writeDb(db);

    res.status(201).json({
      ok: true,
      id: request.id,
      status: request.status,
      emailSent: Boolean(request.emailSent),
      message: "Solicitacao enviada para análise. O item não foi publicado."
    });
});

app.get("/api/bookings", (req, res) => {
  const db = readDb();
  const { itemId, renter, mine } = req.query;
  const user = currentUser(req, db);
  let bookings = db.bookings.map((b) => ({
    ...b,
    item: db.items.find((i) => i.id === b.itemId) || null
  }));
  if (itemId) bookings = bookings.filter((b) => b.itemId === itemId);
  if (renter) {
    const term = String(renter).toLowerCase();
    bookings = bookings.filter((b) => String(b.renterName || "").toLowerCase().includes(term));
  }
  if (mine === "1") {
    if (!user) return res.status(401).json({ error: "Entre na conta para ver seus aluguéis." });
    bookings = bookings.filter((b) => b.userId === user.id || (!b.userId && b.renterEmail === user.email));
  } else if (!isAdmin(user)) {
    if (!user) return res.status(401).json({ error: "Entre na conta para ver seus aluguéis." });
    bookings = bookings.filter((b) => b.userId === user.id || (!b.userId && b.renterEmail === user.email));
  }
  bookings.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(bookings);
});

app.post("/api/bookings", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  if (!user.documentPhoto) {
    return res.status(403).json({ error: "Envie a foto do documento para alugar." });
  }
  if (user.quarantined) {
    return res.status(403).json({ error: "Sua conta está em quarentena. Aguarde a reavaliação do administrador para alugar novamente." });
  }

  const {
    itemId,
    startDate,
    endDate,
    startTime,
    endTime,
    note,
    delivery,
    contractAccepted
  } = req.body || {};
  if (!itemId || !startDate || !endDate) {
    return res.status(400).json({ error: "Informe item e período" });
  }
  if (endDate < startDate) {
    return res.status(400).json({ error: "A data de devolução deve ser igual ou posterior a data de retirada." });
  }
  const pickupTime = parseTime(startTime, "08:00");
  const returnTime = parseTime(endTime, "18:00");
  if (endDate === startDate && returnTime <= pickupTime) {
    return res.status(400).json({ error: "O horário de devolução deve ser depois do horário de retirada." });
  }
  if (!contractAccepted) {
    return res.status(400).json({ error: "Aceite o contrato DIUSO para continuar" });
  }

  const days = daysBetween(startDate, endDate);
  if (days < 1) {
    return res.status(400).json({ error: "Período inválido" });
  }

  const item = db.items.find((i) => i.id === itemId);
  if (!item) return res.status(404).json({ error: "Item não encontrado" });
  if (item.listingStatus === "excluido") {
    return res.status(404).json({ error: "Item não encontrado" });
  }
  if (item.listingStatus === "pausado" || item.available === false) {
    return res.status(409).json({ error: "Este anúncio está pausado. Não é possível fazer novas reservas." });
  }
  if (item.maintenanceStatus === "manutenção") {
    return res.status(409).json({ error: "Este item está em manutenção" });
  }

  if (!isAvailable(db.bookings, itemId, startDate, endDate)) {
    return res.status(409).json({ error: "Esse período já está reservado" });
  }

  const settings = settingsOf(db);
  const renterLevel = syncRenterLevel(user, db.bookings, settings);
  const pricing = quote(item, days, true, settings, { renterLevel });
  const owner = itemOwnerUser(db, item);
  const booking = {
    id: `bkg-${Date.now()}`,
    itemId,
    userId: user.id,
    ownerUserId: owner?.id || item.ownerUserId || "",
    ownerName: item.owner,
    renterName: user.name,
    renterPhone: user.phone,
    renterEmail: user.email,
    renterCpf: user.cpf,
    documentType: user.documentType,
    documentNumber: user.documentNumber,
    startDate,
    endDate,
    startTime: pickupTime,
    endTime: returnTime,
    days: pricing.days,
    periodLabel: pricing.periodLabel,
    pricePerDay: item.pricePerDay,
    delivery: true,
    deliveryFee: pricing.deliveryFee,
    deposit: pricing.deposit,
    depositBase: pricing.depositBase,
    renterLevel,
    depositStatus: Number(pricing.deposit || 0) > 0 ? "retido" : "isento",
    payoutStatus: "retido",
    inspectionStatus: "pendente",
    rentalAmount: pricing.rentalAmount,
    protectionRate: pricing.protectionRate,
    protectionFee: pricing.protectionFee,
    subtotal: pricing.rentalAmount,
    dailyTotal: pricing.dailyTotal,
    rentalDue: pricing.rentalDue,
    initialCharge: pricing.initialCharge,
    total: pricing.rentalDue,
    commissionRate: pricing.commissionRate,
    commission: pricing.commission,
    ownerPayout: pricing.ownerPayout,
    lateFee: 0,
    status: "aguardando_confirmacao",
    paymentStatus: "aguardando_gateway",
    paymentProvider: "gateway_pendente",
    contractAccepted: true,
    contractAcceptedAt: nowIso(),
    createdAt: nowIso(),
    note: String(note || "").trim()
  };
  booking.contract = buildContract(booking, item, user, settings);

  db.bookings.unshift(booking);
  addNotification(db, {
    userId: user.id,
    role: "locatário",
    bookingId: booking.id,
    type: "reserva_criada",
    title: "Reserva criada",
    body: `Pedido de ${item.title} registrado. Contrato gerado. Pagamento aguarda gateway.`
  });
  addNotification(db, {
    userId: owner?.id || "",
    role: "proprietario",
    bookingId: booking.id,
    type: "nova_reserva",
    title: "Nova reserva",
    body: `${user.name} reservou ${item.title}.`
  });
  addAudit(db, { action: "booking.create", bookingId: booking.id, userId: user.id });
  recordEvent(db, { type: "booking_created", userId: user.id, itemId, meta: { rentalDue: booking.rentalDue } });
  writeDb(db);
  res.status(201).json(withBooking(db, booking));
});

app.get("/api/bookings/:id", (req, res) => {
  const db = readDb();
  const user = currentUser(req, db);
  const booking = findBooking(db, req.params.id);
  if (!booking) return res.status(404).json({ error: "Reserva não encontrada" });
  const mine = user && (booking.userId === user.id || (!booking.userId && booking.renterEmail === user.email));
  if (!isAdmin(user) && !mine) {
    return res.status(403).json({ error: "Acesso restrito." });
  }
  applyLateIfNeeded(db, booking, settingsOf(db));
  writeDb(db);
  res.json(withBooking(db, booking));
});

function bookingDocument(db, booking) {
  const item = db.items.find((i) => i.id === booking.itemId) || {};
  const renter = (db.users || []).find((u) => u.id === booking.userId) || {};
  const owner = itemOwnerUser(db, item) || {};
  const settings = settingsOf(db);
  const amount = Number(booking.initialCharge || booking.rentalDue || booking.total || 0);
  const txid = String(booking.id || "").replace(/[^A-Za-z0-9]/g, "").slice(0, 25) || "DIUSO";
  const pixKey = settings.pix?.key || "pix@diuso.com";
  const payload = pixPayload({
    key: pixKey,
    name: settings.pix?.name || "DIUSO",
    city: settings.pix?.city || item.city || "SAO PAULO",
    amount,
    txid
  });
  return {
    id: booking.id,
    generatedAtLabel: new Date().toLocaleString("pt-BR"),
    item: {
      title: item.title || booking.itemId,
      period: `${formatDateBr(booking.startDate)} — ${formatDateBr(booking.endDate)}`
    },
    owner: {
      name: owner.name || item.owner || booking.ownerName || "—",
      email: owner.email || item.ownerEmail || "",
      phone: owner.phone || item.ownerPhone || "",
      city: [item.street, item.streetNumber, item.neighborhood, item.city].filter(Boolean).join(" · ")
    },
    renter: {
      name: booking.renterName || renter.name || "—",
      cpf: booking.renterCpf || renter.cpf || "",
      document: [booking.documentType || renter.documentType, booking.documentNumber || renter.documentNumber].filter(Boolean).join(" "),
      email: booking.renterEmail || renter.email || "",
      phone: booking.renterPhone || renter.phone || "",
      address: [renter.address, renter.neighborhood, renter.city].filter(Boolean).join(" · ")
    },
    billing: {
      rentalAmount: moneyBr(booking.rentalAmount),
      protectionFee: moneyBr(booking.protectionFee),
      deliveryFee: moneyBr(booking.deliveryFee),
      rentalDue: moneyBr(booking.rentalDue || booking.total),
      deposit: moneyBr(booking.deposit),
      initialCharge: moneyBr(booking.initialCharge || Number(booking.rentalDue || 0) + Number(booking.deposit || 0)),
      commission: moneyBr(booking.commission),
      ownerPayout: moneyBr(booking.ownerPayout)
    },
    pix: {
      key: pixKey,
      payload,
      amountLabel: moneyBr(amount)
    }
  };
}

function sendBookingDocument(req, res, { action, render }) {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const { db } = auth;
  const booking = findBooking(db, req.params.id);
  if (!booking) return res.status(404).send("Reserva não encontrada");
  const html = render(bookingDocument(db, booking));
  addAudit(db, { action, bookingId: booking.id });
  writeDb(db);
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send(html);
}

app.get("/api/bookings/:id/service-order", (req, res) => {
  sendBookingDocument(req, res, { action: "booking.service-order", render: serviceOrderHtml });
});

app.get("/api/bookings/:id/charge-note", (req, res) => {
  sendBookingDocument(req, res, { action: "booking.charge-note", render: chargeNoteHtml });
});

function attachProof(req, res, field, action) {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const { db } = auth;
  const booking = findBooking(db, req.params.id);
  if (!booking) return res.status(404).json({ error: "Reserva não encontrada" });
  if (!req.file) return res.status(400).json({ error: "Envie o comprovante" });
  if (field === "depositRefundProof" && !(Number(booking.deposit || 0) > 0)) {
    return res.status(400).json({ error: "Esta locação não tem caução para reembolsar." });
  }
  booking[field] = proofFile(req.file);
  if (field === "paymentProof") {
    booking.paymentStatus = "comprovante_anexado";
    const renter = (db.users || []).find((u) => u.id === booking.userId);
    if (renter) syncRenterLevel(renter, db.bookings, settingsOf(db));
  }
  addAudit(db, { action, bookingId: booking.id, filename: req.file.filename });
  writeDb(db);
  res.json(withBooking(db, booking));
}

app.post("/api/bookings/:id/payment-proof", (req, res, next) => {
  uploadProof.single("file")(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || "Falha no envio do comprovante" });
    next();
  });
}, (req, res) => attachProof(req, res, "paymentProof", "booking.payment-proof"));

app.post("/api/bookings/:id/deposit-refund-proof", (req, res, next) => {
  uploadProof.single("file")(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || "Falha no envio do comprovante" });
    next();
  });
}, (req, res) => attachProof(req, res, "depositRefundProof", "booking.deposit-refund-proof"));

app.patch("/api/bookings/:id", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const { status } = req.body || {};
  if (!STATUSES.includes(status)) {
    return res.status(400).json({ error: "Status inválido" });
  }

  const { db } = auth;
  const booking = findBooking(db, req.params.id);
  if (!booking) return res.status(404).json({ error: "Reserva não encontrada" });
  const settings = settingsOf(db);
  if (status === "reembolsado") {
    if (!(Number(booking.deposit || 0) > 0)) {
      return res.status(400).json({ error: "Reembolso de caução só se aplica a locações com caução." });
    }
    if (openIncidentsFor(db, booking.id).length) {
      return res.status(409).json({ error: "Existe ocorrencia aberta. A caução permanece retida." });
    }
    if (!booking.depositRefundProof) {
      return res.status(400).json({ error: "Anexe o comprovante de reembolso da caução." });
    }
    booking.inspectionStatus = "aprovada";
    booking.depositStatus = "reembolsado";
    booking.payoutStatus = "em_processamento";
  }
  if (status === "finalizado") {
    if (openIncidentsFor(db, booking.id).length) {
      return res.status(409).json({ error: "Existe ocorrencia aberta. A caução permanece retida." });
    }
    booking.inspectionStatus = "aprovada";
    if (Number(booking.deposit || 0) > 0 && booking.status !== "reembolsado") {
      return res.status(409).json({ error: "Anexe o comprovante e marque como Reembolsado antes de finalizar." });
    }
    if (canReleaseDeposit(db, { ...booking, status: "finalizado", inspectionStatus: "aprovada" })) {
      booking.depositStatus = Number(booking.deposit || 0) > 0 ? (booking.depositStatus || "reembolsado") : "liberado";
      booking.payoutStatus = "em_processamento";
    }
  }
  if (status === "atrasado") {
    const reason = requiredText(req.body?.reason);
    if (!reason) return res.status(400).json({ error: "Informe a justificativa do atraso" });
    booking.lateReason = reason;
  }
  booking.status = status;
  if (status === "cancelado") {
    const preview = cancellationPreview(settings, booking);
    booking.cancellation = booking.cancellation || { at: nowIso(), byUserId: auth.user.id, ...preview };
    booking.depositStatus = "liberado";
    booking.payoutStatus = "cancelado";
    const renter = (db.users || []).find((u) => u.id === booking.userId);
    if (preview.window === "menos_de_24h" && renter && !isAdmin(renter)) {
      renter.quarantined = true;
      renter.quarantinedAt = nowIso();
      renter.quarantineReason = "Cancelamento com menos de 24 horas da retirada.";
      renter.quarantineBookingId = booking.id;
    }
  }
  if (["confirmado", "preparando", "em_entrega", "ativo"].includes(status)) {
    booking.paymentStatus = "aguardando_gateway";
  }
  applyLateIfNeeded(db, booking, settings);
  addAudit(db, { action: "booking.status", bookingId: booking.id, status });
  writeDb(db);
  res.json(withBooking(db, booking));
});

app.get("/api/bookings/:id/contract", (req, res) => {
  const db = readDb();
  const booking = findBooking(db, req.params.id);
  if (!booking) return res.status(404).json({ error: "Reserva não encontrada" });
  const item = db.items.find((i) => i.id === booking.itemId);
  const user = (db.users || []).find((u) => u.id === booking.userId);
  if (!booking.contract) booking.contract = buildContract(booking, item, user, settingsOf(db));
  writeDb(db);
  res.json(booking.contract);
});

app.post("/api/bookings/:id/accept-contract", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const booking = findBooking(db, req.params.id);
  if (!booking) return res.status(404).json({ error: "Reserva não encontrada" });
  if (booking.userId !== user.id) return res.status(403).json({ error: "Somente o locatário pode aceitar o contrato." });
  booking.contractAccepted = true;
  booking.contractAcceptedAt = nowIso();
  booking.contract = booking.contract || buildContract(booking, db.items.find((i) => i.id === booking.itemId), user, settingsOf(db));
  booking.contract.acceptedAt = booking.contractAcceptedAt;
  addAudit(db, { action: "contract.accept", bookingId: booking.id, userId: user.id });
  addNotification(db, {
    userId: user.id,
    bookingId: booking.id,
    role: "locatário",
    type: "contrato_aceito",
    title: "Contrato aceito",
    body: "O contrato digital desta locação foi aceito."
  });
  writeDb(db);
  res.json(withBooking(db, booking));
});

app.post("/api/bookings/:id/check-in", (req, res, next) => {
  uploadEvidence.array("photos", 8)(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || "Falha no envio das fotos" });
    next();
  });
}, (req, res) => {
  const db = readDb();
  const booking = findBooking(db, req.params.id);
  if (!booking) return res.status(404).json({ error: "Reserva não encontrada" });
  booking.checkIn = {
    at: nowIso(),
    notes: requiredText(req.body?.notes),
    accessories: requiredText(req.body?.accessories),
    condition: requiredText(req.body?.condition) || "conforme anunciado",
    serialNumber: requiredText(req.body?.serialNumber),
    photos: evidenceFiles(req.files)
  };
  if (["aguardando_confirmacao", "confirmado", "preparando", "em_entrega"].includes(booking.status)) {
    booking.status = "ativo";
  }
  addAudit(db, { action: "booking.checkin", bookingId: booking.id });
  addNotification(db, {
    userId: booking.userId,
    bookingId: booking.id,
    role: "locatário",
    type: "checkin",
    title: "Check-in registrado",
    body: "O estado do produto na retirada foi registrado."
  });
  writeDb(db);
  res.json(withBooking(db, booking));
});

app.post("/api/bookings/:id/check-out", (req, res, next) => {
  uploadEvidence.array("photos", 8)(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || "Falha no envio das fotos" });
    next();
  });
}, (req, res) => {
  const db = readDb();
  const booking = findBooking(db, req.params.id);
  if (!booking) return res.status(404).json({ error: "Reserva não encontrada" });
  booking.checkOut = {
    at: nowIso(),
    notes: requiredText(req.body?.notes),
    checklist: requiredText(req.body?.checklist),
    condition: requiredText(req.body?.condition) || "devolvido",
    confirmed: true,
    photos: evidenceFiles(req.files)
  };
  booking.status = "aguardando_devolucao";
  booking.inspectionStatus = "pendente";
  addAudit(db, { action: "booking.checkout", bookingId: booking.id });
  addNotification(db, {
    userId: booking.ownerUserId,
    bookingId: booking.id,
    role: "proprietario",
    type: "checkout",
    title: "Check-out registrado",
    body: "O estado do produto na devolução foi registrado."
  });
  writeDb(db);
  res.json(withBooking(db, booking));
});

app.post("/api/bookings/:id/cancel", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const booking = findBooking(db, req.params.id);
  if (!booking) return res.status(404).json({ error: "Reserva não encontrada" });
  if (["finalizado", "cancelado"].includes(booking.status)) {
    return res.status(409).json({ error: "Esta locação não pode ser cancelada." });
  }
  const settings = settingsOf(db);
  const preview = cancellationPreview(settings, booking);
  const byOwner = Boolean(req.body?.byOwner) || booking.ownerUserId === user.id && booking.userId !== user.id;
  booking.status = "cancelado";
  booking.cancellation = {
    at: nowIso(),
    byUserId: user.id,
    byOwner,
    ...preview
  };
  booking.depositStatus = "liberado";
  booking.payoutStatus = "cancelado";
  const renter = (db.users || []).find((u) => u.id === booking.userId);
  if (!byOwner && preview.window === "menos_de_24h" && renter && !isAdmin(renter)) {
    renter.quarantined = true;
    renter.quarantinedAt = nowIso();
    renter.quarantineReason = "Cancelamento com menos de 24 horas da retirada.";
    renter.quarantineBookingId = booking.id;
  }
  if (byOwner) {
    const owner = (db.users || []).find((u) => u.id === user.id);
    if (owner) {
      owner.ownerCancelCount = Number(owner.ownerCancelCount || 0) + 1;
      owner.reputation = ownerCancelPenalty(settings, owner.ownerCancelCount);
      if (owner.ownerCancelCount >= 3) owner.blocked = true;
    }
  }
  addAudit(db, { action: "booking.cancel", bookingId: booking.id, userId: user.id, byOwner, quarantined: Boolean(renter?.quarantined) });
  addNotification(db, {
    userId: booking.userId,
    bookingId: booking.id,
    role: "locatário",
    type: "cancelamento",
    title: "Locação cancelada",
    body: preview.window === "menos_de_24h" && !byOwner
      ? "Cancelamento com menos de 24 horas da retirada. A conta entrou em quarentena até reavaliação do administrador."
      : `Reembolso previsto do aluguel: política ${preview.window}. Caução tratada em separado.`
  });
  writeDb(db);
  res.json(withBooking(db, booking));
});

app.post("/api/bookings/:id/late", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const { db } = auth;
  const booking = findBooking(db, req.params.id);
  if (!booking) return res.status(404).json({ error: "Reserva não encontrada" });
  const reason = requiredText(req.body?.reason);
  if (!reason) return res.status(400).json({ error: "Informe a justificativa do atraso" });
  const settings = settingsOf(db);
  const extraDays = Math.max(1, Number(req.body?.extraDays || booking.lateDays || 1));
  booking.status = "atrasado";
  booking.lateDays = extraDays;
  booking.lateFee = lateFeeForDays(settings, booking.pricePerDay, extraDays);
  booking.lateCalculatedAt = nowIso();
  booking.lateReason = reason;
  addNotification(db, {
    userId: booking.userId,
    bookingId: booking.id,
    role: "locatário",
    type: "atraso",
    title: "Atraso na devolução",
    body: `${reason} Diaria adicional de 1,5x calculada: ${booking.lateFee}.`
  });
  addAudit(db, { action: "booking.late", bookingId: booking.id, extraDays, reason });
  writeDb(db);
  res.json(withBooking(db, booking));
});

app.post("/api/bookings/:id/inspect", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const { db } = auth;
  const booking = findBooking(db, req.params.id);
  if (!booking) return res.status(404).json({ error: "Reserva não encontrada" });
  const result = requiredText(req.body?.result) || "aprovada";
  booking.inspectionStatus = result;
  if (result === "aprovada" && !openIncidentsFor(db, booking.id).length) {
    if (Number(booking.deposit || 0) > 0) {
      if (booking.depositRefundProof) {
        booking.status = "reembolsado";
        booking.depositStatus = "reembolsado";
      }
    } else {
      booking.status = "finalizado";
      booking.depositStatus = "liberado";
    }
    booking.payoutStatus = "em_processamento";
    addNotification(db, {
      userId: booking.userId,
      bookingId: booking.id,
      role: "locatário",
      type: "caucao_liberada",
      title: "Caução liberada",
      body: "A inspecao foi aprovada e a caução sera devolvida. Não e receita do Diuso."
    });
    addNotification(db, {
      userId: booking.ownerUserId,
      bookingId: booking.id,
      role: "proprietario",
      type: "repasse",
      title: "Repasse em processamento",
      body: "O valor liquido do proprietario entra em processamento apos a inspecao."
    });
  }
  addAudit(db, { action: "booking.inspect", bookingId: booking.id, result });
  writeDb(db);
  res.json(withBooking(db, booking));
});

app.post("/api/incidents", (req, res, next) => {
  uploadEvidence.array("photos", 8)(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || "Falha no envio das fotos" });
    next();
  });
}, (req, res) => {
  const db = readDb();
  const booking = findBooking(db, requiredText(req.body?.bookingId));
  if (!booking) return res.status(404).json({ error: "Reserva não encontrada" });
  const incident = {
    id: `inc-${Date.now()}`,
    bookingId: booking.id,
    itemId: booking.itemId,
    type: requiredText(req.body?.type) || "pequeno_dano",
    description: requiredText(req.body?.description),
    budget: Number(req.body?.budget || 0),
    amount: Number(req.body?.amount || req.body?.budget || 0),
    status: "aberto",
    photos: evidenceFiles(req.files),
    createdAt: nowIso()
  };
  db.incidents = db.incidents || [];
  db.incidents.unshift(incident);
  booking.depositStatus = "retido";
  booking.payoutStatus = "retido";
  addNotification(db, {
    userId: booking.userId,
    bookingId: booking.id,
    role: "locatário",
    type: "ocorrencia",
    title: "Ocorrencia aberta",
    body: "Uma ocorrencia de dano foi aberta. A caução permanece retida."
  });
  addAudit(db, { action: "incident.open", incidentId: incident.id, bookingId: booking.id });
  writeDb(db);
  res.status(201).json(incident);
});

app.patch("/api/incidents/:id", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const { db } = auth;
  const incident = (db.incidents || []).find((i) => i.id === req.params.id);
  if (!incident) return res.status(404).json({ error: "Ocorrencia não encontrada" });
  const allowed = ["aberto", "em_analise", "aprovado", "cobrado", "resolvido", "rejeitado"];
  if (req.body?.status && !allowed.includes(req.body.status)) {
    return res.status(400).json({ error: "Status de ocorrencia inválido" });
  }
  if (req.body?.status) incident.status = req.body.status;
  if (req.body?.amount != null) incident.amount = Number(req.body.amount);
  incident.updatedAt = nowIso();
  addAudit(db, { action: "incident.update", incidentId: incident.id, status: incident.status });
  writeDb(db);
  res.json(incident);
});

app.get("/api/incidents", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  let list = auth.db.incidents || [];
  if (req.query.bookingId) list = list.filter((i) => i.bookingId === req.query.bookingId);
  res.json(list);
});

app.post("/api/reviews", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const booking = findBooking(db, requiredText(req.body?.bookingId));
  if (!booking) return res.status(404).json({ error: "Reserva não encontrada" });
  if (booking.status !== "finalizado") {
    return res.status(409).json({ error: "Avaliação só apos a locação concluida." });
  }
  const review = {
    id: `rev-${Date.now()}`,
    bookingId: booking.id,
    itemId: booking.itemId,
    fromUserId: user.id,
    targetUserId: requiredText(req.body?.targetUserId),
    role: requiredText(req.body?.role) || "locatário",
    stars: Math.min(5, Math.max(1, Number(req.body?.stars || 5))),
    reliability: Number(req.body?.reliability || req.body?.stars || 5),
    conservation: Number(req.body?.conservation || req.body?.stars || 5),
    communication: Number(req.body?.communication || req.body?.stars || 5),
    punctuality: Number(req.body?.punctuality || req.body?.stars || 5),
    comment: requiredText(req.body?.comment),
    createdAt: nowIso()
  };
  db.reviews = db.reviews || [];
  db.reviews.unshift(review);
  writeDb(db);
  res.status(201).json(review);
});

app.get("/api/users/:id/profile", (req, res) => {
  const db = readDb();
  const user = (db.users || []).find((u) => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: "Usuário não encontrado" });
  syncRenterLevel(user, db.bookings, settingsOf(db));
  writeDb(db);
  const stats = userStats(db, user);
  const items = db.items.filter((i) => i.ownerId === user.ownerId || i.ownerEmail === user.email || i.owner === user.name);
  const reviews = (db.reviews || []).filter((r) => r.targetUserId === user.id);
  res.json({
    id: user.id,
    name: user.name,
    city: user.city,
    neighborhood: user.neighborhood,
    photoUrl: user.photoUrl || "",
    memberSince: user.createdAt,
    reputation: user.reputation,
    ...stats,
    items: items.map((item) => withItemMeta(item, db, user)),
    reviews
  });
});

app.get("/api/owner/dashboard", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const items = db.items.filter((i) => i.ownerEmail === user.email || i.owner === user.name || i.ownerUserId === user.id);
  const itemIds = new Set(items.map((i) => i.id));
  const bookings = db.bookings.filter((b) => itemIds.has(b.itemId) || b.ownerUserId === user.id);
  const gross = bookings.filter((b) => b.status !== "cancelado").reduce((sum, b) => sum + Number(b.rentalAmount || 0), 0);
  const commission = bookings.filter((b) => b.status !== "cancelado").reduce((sum, b) => sum + Number(b.commission || 0), 0);
  const net = bookings.filter((b) => b.status !== "cancelado").reduce((sum, b) => sum + Number(b.ownerPayout || 0), 0);
  const available = bookings.filter((b) => b.payoutStatus === "disponível").reduce((sum, b) => sum + Number(b.ownerPayout || 0), 0);
  const processing = bookings.filter((b) => b.payoutStatus === "em_processamento").reduce((sum, b) => sum + Number(b.ownerPayout || 0), 0);
  const held = bookings.filter((b) => b.payoutStatus === "retido").reduce((sum, b) => sum + Number(b.ownerPayout || 0), 0);
  res.json({
    gross,
    commission,
    net,
    available,
    processing,
    held,
    rentals: bookings.length,
    activeItems: items.filter((i) => i.listingStatus === "ativo").length,
    rentedItems: items.filter((i) => availabilityOf(i, db.bookings) === "alugado").length,
    cancellations: bookings.filter((b) => b.status === "cancelado").length,
    incidents: (db.incidents || []).filter((i) => itemIds.has(i.itemId)).length,
    items: items.map((item) => withItemMeta(item, db, user)),
    bookings: bookings.map((b) => withBooking(db, b)),
    listingRequests: (db.listingRequests || [])
      .filter((r) => listingOwnedBy(user, r))
      .map(withListingPhotos)
  });
});

app.get("/api/notifications", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const list = (db.notifications || []).filter((n) => n.userId === user.id);
  res.json(list);
});

app.post("/api/listing-requests/:id/approve", maybeListingPhotos, (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const { db } = auth;
  const request = (db.listingRequests || []).find((r) => r.id === req.params.id);
  if (!request) return res.status(404).json({ error: "Solicitacao não encontrada" });
  if (request.status !== "aguardando_analise") {
    return res.status(400).json({ error: "Esta solicitação já foi analisada." });
  }
  const result = applyListingRequestEdits(db, request, req.body || {}, req.files || []);
  if (result.error) return res.status(400).json({ error: result.error });
  const item = listingToItem(request);
  db.items.unshift(item);
  request.status = "aprovado";
  request.published = true;
  request.itemId = item.id;
  addAudit(db, { action: "listing.approve", requestId: request.id, itemId: item.id });
  writeDb(db);
  res.json({ ok: true, item, request: withListingPhotos(request) });
});

app.post("/api/listing-requests/:id/reject", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const { db } = auth;
  const request = (db.listingRequests || []).find((r) => r.id === req.params.id);
  if (!request) return res.status(404).json({ error: "Solicitacao não encontrada" });
  if (request.status !== "aguardando_analise") {
    return res.status(400).json({ error: "Esta solicitação já foi analisada." });
  }
  const comment = requiredText(req.body?.comment || req.body?.reason);
  if (comment.length < 8) {
    return res.status(400).json({ error: "Descreva o que o anunciante precisa alterar (mínimo 8 caracteres)." });
  }
  request.status = "rejeitado";
  request.published = false;
  request.rejectionComment = comment;
  request.rejectedAt = nowIso();
  request.rejectedBy = auth.user.id;
  request.reviewNotes = request.reviewNotes || [];
  request.reviewNotes.unshift({ at: nowIso(), by: auth.user.id, comment, action: "reject" });
  addNotification(db, {
    userId: request.ownerUserId || "",
    role: "proprietario",
    requestId: request.id,
    type: "anuncio_devolvido",
    title: "Anúncio devolvido para correção",
    body: `O anúncio “${request.title}” precisa de ajustes: ${comment}`
  });
  addAudit(db, { action: "listing.reject", requestId: request.id, comment });
  writeDb(db);
  res.json({ ok: true, request: withListingPhotos(request) });
});

app.get("/api/my/listing-requests", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const list = (auth.db.listingRequests || [])
    .filter((r) => listingOwnedBy(auth.user, r))
    .map(withListingPhotos);
  res.json(list);
});

app.get("/api/my/listing-requests/:id", (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const request = (auth.db.listingRequests || []).find((r) => r.id === req.params.id);
  if (!request || !listingOwnedBy(auth.user, request)) {
    return res.status(404).json({ error: "Solicitacao não encontrada" });
  }
  res.json(withListingPhotos(request));
});

app.post("/api/my/listing-requests/:id/resubmit", maybeListingPhotos, (req, res) => {
  const auth = requireUser(req, res);
  if (!auth.user) return;
  const { db, user } = auth;
  const request = (db.listingRequests || []).find((r) => r.id === req.params.id);
  if (!request || !listingOwnedBy(user, request)) {
    return res.status(404).json({ error: "Solicitacao não encontrada" });
  }
  if (request.status !== "rejeitado") {
    return res.status(400).json({ error: "Só é possível reenviar anúncios devolvidos para correção." });
  }
  const result = applyListingRequestEdits(db, request, req.body || {}, req.files || []);
  if (result.error) return res.status(400).json({ error: result.error });
  if ((request.photos || []).length < 6) {
    return res.status(400).json({ error: "O anúncio precisa de no mínimo 6 fotos." });
  }
  request.lastRejectionComment = request.rejectionComment || request.lastRejectionComment || "";
  request.rejectionComment = "";
  request.status = "aguardando_analise";
  request.published = false;
  request.resubmittedAt = nowIso();
  request.resubmitCount = Number(request.resubmitCount || 0) + 1;
  addAudit(db, { action: "listing.resubmit", requestId: request.id, userId: user.id });
  addNotification(db, {
    userId: user.id,
    role: "proprietario",
    requestId: request.id,
    type: "anuncio_reenviado",
    title: "Anúncio reenviado",
    body: `O anúncio “${request.title}” voltou para análise da DIUSO.`
  });
  writeDb(db);
  res.json({ ok: true, request: withListingPhotos(request) });
});

app.get("/api/favorites", (_req, res) => {
  const db = readDb();
  const items = (db.favorites || [])
    .map((id) => db.items.find((i) => i.id === id))
    .filter((item) => item && item.listingStatus !== "excluido")
    .map((item) => withItemMeta(item, db, currentUser(_req, db)));
  res.json(items);
});

app.post("/api/favorites/:id", (req, res) => {
  const db = readDb();
  const exists = db.items.some((i) => i.id === req.params.id);
  if (!exists) return res.status(404).json({ error: "Item não encontrado" });
  const user = currentUser(req, db);
  db.favorites = db.favorites || [];
  if (!db.favorites.includes(req.params.id)) db.favorites.push(req.params.id);
  recordLike(db, { itemId: req.params.id, visitorId: visitorIdOf(req) });
  recordEvent(db, { type: "favorite_add", userId: user?.id || null, itemId: req.params.id });
  writeDb(db);
  res.json({ ok: true, favorites: db.favorites });
});

app.post("/api/favorites/:id/remove", (req, res) => {
  const db = readDb();
  const user = currentUser(req, db);
  db.favorites = (db.favorites || []).filter((id) => id !== req.params.id);
  recordLike(db, { itemId: req.params.id, visitorId: visitorIdOf(req), action: "remove" });
  recordEvent(db, { type: "favorite_remove", userId: user?.id || null, itemId: req.params.id });
  writeDb(db);
  res.json({ ok: true, favorites: db.favorites });
});

app.get("/api/admin/overview", (req, res) => {
  const auth = requireAdmin(req, res);
  if (!auth.user) return;
  const { db } = auth;
  const settings = settingsOf(db);
  db.bookings.forEach((b) => applyLateIfNeeded(db, b, settings));
  const window = revenueWindow(req, auth.user);
  const paid = db.bookings.filter((b) => b.status !== "cancelado" && bookingInWindow(b, window.from, window.to));
  const commissions = paid.reduce((sum, b) => sum + Number(b.commission || 0), 0);
  const protection = paid.reduce((sum, b) => sum + Number(b.protectionFee || 0), 0);
  const lateFees = paid.reduce((sum, b) => sum + Number(b.lateFee || 0), 0);
  const heldDeposits = db.bookings
    .filter((b) => b.depositStatus === "retido" && bookingInWindow(b, window.from, window.to))
    .reduce((sum, b) => sum + Number(b.deposit || 0), 0);
  const byStatus = (status) => db.bookings.filter((b) => b.status === status).length;
  const availability = db.items.reduce(
    (acc, item) => {
      const key = availabilityOf(item, db.bookings);
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    },
    { disponivel: 0, alugado: 0, manutencao: 0, indisponivel: 0 }
  );

  res.json({
    brand: PLATFORM.name,
    settings: publicSettings(settings),
    period: window.period,
    periodFrom: window.from,
    periodTo: window.to,
    periodLimited: Boolean(window.limited),
    revenue: commissions + protection + lateFees,
    commissions,
    protectionFees: protection,
    lateFees,
    otherRevenue: 0,
    heldDeposits,
    depositsAreNotRevenue: true,
    payoutsHeld: paid.filter((b) => b.payoutStatus === "retido").reduce((sum, b) => sum + Number(b.ownerPayout || 0), 0),
    payoutsProcessing: paid.filter((b) => b.payoutStatus === "em_processamento").reduce((sum, b) => sum + Number(b.ownerPayout || 0), 0),
    activeRentals: db.bookings.filter((b) =>
      ["confirmado", "preparando", "em_entrega", "ativo", "aguardando_devolucao", "reembolsado"].includes(b.status)
    ).length,
    available: availability.disponivel,
    rented: availability.alugado,
    maintenance: availability.manutencao,
    late: byStatus("atrasado"),
    deliveries: byStatus("em_entrega"),
    returns: byStatus("aguardando_devolucao"),
    clients: (db.users || []).filter((u) => u.email).length,
    products: db.items.length,
    bookings: db.bookings.length,
    listingRequests: (db.listingRequests || []).length,
    pendingListings: (db.listingRequests || []).filter((r) => r.status === "aguardando_analise").length,
    incidentsOpen: (db.incidents || []).filter((i) => !["resolvido", "rejeitado"].includes(i.status)).length
  });
});

app.get("/api/admin/finance", (req, res) => {
  const auth = requireMaster(req, res);
  if (!auth.user) return;
  const { db } = auth;
  const settings = settingsOf(db);
  db.bookings.forEach((b) => applyLateIfNeeded(db, b, settings));
  writeDb(db);
  res.json(financialDashboard(db, settings));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`DIUSO API on ${PORT}`);
});
