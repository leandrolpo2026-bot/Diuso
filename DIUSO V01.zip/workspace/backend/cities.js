export const SERVICE_CITIES = [
  "Corinto",
  "Morro da Garça",
  "Santo Hipólito",
  "Monjolos",
  "Augusto de Lima",
  "Inimutaba",
  "Curvelo",
  "Presidente Juscelino",
  "Lassance",
  "Felixlândia",
  "Buenópolis",
  "Três Marias",
  "Joaquim Felício",
  "Gouveia",
  "Várzea da Palma",
  "Diamantina",
  "Paraopeba",
  "Santana de Pirapama",
  "Morada Nova de Minas",
  "Pompéu",
  "Cordisburgo",
  "Jequitaí",
  "Datas",
  "Presidente Kubitschek",
  "São Gonçalo do Abaeté",
  "Abaeté",
  "Paineiras",
  "Biquinhas",
  "Martinho Campos"
];

export const DEFAULT_ACTIVE_CITIES = ["Corinto"];

export function normalizeCity(name) {
  return String(name || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

export function titleCity(name) {
  return String(name || "").trim().replace(/\s+/g, " ");
}

export function mergeCityCatalog(extra = []) {
  const extras = (Array.isArray(extra) ? extra : []).map(titleCity).filter(Boolean);
  const map = new Map();
  for (const city of [...SERVICE_CITIES, ...extras]) {
    const key = normalizeCity(city);
    if (key && !map.has(key)) map.set(key, city);
  }
  return [...map.values()];
}

export function mergeActiveCities(saved, extra = []) {
  const catalog = mergeCityCatalog(extra);
  const selected = [];
  const seen = new Set();
  for (const city of (Array.isArray(saved) ? saved : [])) {
    const named = titleCity(city);
    if (!named) continue;
    const key = normalizeCity(named);
    const value = catalog.find((name) => normalizeCity(name) === key) || named;
    if (seen.has(normalizeCity(value))) continue;
    seen.add(normalizeCity(value));
    selected.push(value);
  }
  return selected.length ? selected : [...DEFAULT_ACTIVE_CITIES];
}

export function isActiveCity(city, activeCities, extra = []) {
  const n = normalizeCity(city);
  return mergeActiveCities(activeCities, extra).some((name) => normalizeCity(name) === n);
}
