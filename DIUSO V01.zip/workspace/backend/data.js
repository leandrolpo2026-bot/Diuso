export const PLATFORM = {
  id: "diuso",
  name: "DIUSO",
  slogan: "Você precisa. A gente resolve."
};

export const categories = [
  { id: "festas", name: "Festas e Eventos", icon: "party" },
  { id: "eletrônicos", name: "Som e Eletrônicos", icon: "chip" },
  { id: "ferramentas", name: "Ferramentas", icon: "wrench" },
  { id: "casa", name: "Casa", icon: "home" },
  { id: "automotivo", name: "Automotivo", icon: "car" },
  { id: "esportes", name: "Esportes e Lazer", icon: "ball" },
  { id: "cameras", name: "Foto e Vídeo", icon: "camera" },
  { id: "construção", name: "Construção", icon: "build" },
  { id: "móveis", name: "Móveis", icon: "chair" },
  { id: "outros", name: "Outros", icon: "box" },
  { id: "musica", name: "Música", icon: "music" },
  { id: "mobilidade", name: "Mobilidade", icon: "bike" }
];

export const deliveryByCategory = {
  ferramentas: 20,
  eletronicos: 30,
  esportes: 25,
  festas: 50,
  casa: 30,
  cameras: 25,
  musica: 20,
  mobilidade: 15,
  automotivo: 35,
  construcao: 40,
  moveis: 45,
  outros: 25
};

export function ownerIdFromName(name) {
  return String(name || "diuso")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "") || "diuso";
}

export const seedItems = [
  {
    id: "itm-01",
    title: "Furadeira Bosch Professional GSB 13 RE",
    category: "ferramentas",
    pricePerDay: 28,
    deposit: 150,
    city: "Corinto",
    neighborhood: "Pinheiros",
    owner: "Marcos Oliveira",
    rating: 4.9,
    reviews: 42,
    available: true,
    condition: "Excelente",
    description:
      "Use pelo tempo da obra e devolva. Furadeira de impacto profissional com maleta, jogo de brocas e extensao. Ideal para instalacoes em alvenaria e madeira.",
    specs: ["650W", "Mandril 13mm", "Maleta inclusa", "Jogo de 13 brocas"],
    image: "drill"
  },
  {
    id: "itm-02",
    title: "Projetor Epson Full HD 3600 lumens",
    category: "eletrônicos",
    pricePerDay: 95,
    deposit: 600,
    city: "Corinto",
    neighborhood: "Vila Madalena",
    owner: "Ana Costa",
    rating: 4.8,
    reviews: 31,
    available: true,
    condition: "Como novo",
    description:
      "Por que comprar se você só precisa usar nesta apresentacao? Projetor Full HD com HDMI, tela de 120 polegadas e caixa de som bluetooth.",
    specs: ["Full HD", "3600 lumens", "Tela 120\"", "HDMI + Bluetooth"],
    image: "projector"
  },
  {
    id: "itm-03",
    title: "Bicicleta mountain bike Caloi Aro 29",
    category: "esportes",
    pricePerDay: 45,
    deposit: 400,
    city: "Corinto",
    neighborhood: "Itaim Bibi",
    owner: "Pedro Santos",
    rating: 4.7,
    reviews: 18,
    available: true,
    condition: "Muito bom",
    description:
      "Use no fim de semana e devolva. MTB aro 29, 21 marchas, freio a disco. Entrego com capacete e kit de reparo.",
    specs: ["Aro 29", "21 marchas", "Freio a disco", "Capacete incluso"],
    image: "bike"
  },
  {
    id: "itm-04",
    title: "Kit festa completo 50 pessoas",
    category: "festas",
    pricePerDay: 180,
    deposit: 350,
    city: "Corinto",
    neighborhood: "Moema",
    owner: "Juliana Ferreira",
    rating: 5.0,
    reviews: 67,
    available: true,
    condition: "Excelente",
    description:
      "Monte a festa, use e devolva. Mesas, cadeiras, toalhas, cooler, copos, pratos e decoracao basica. Entrega e retirada no período combinado.",
    specs: ["6 mesas", "50 cadeiras", "Cooler 60L", "Kit copos/pratos"],
    image: "party"
  },
  {
    id: "itm-05",
    title: "Cortador de grama eletrico Trapp 1800W",
    category: "casa",
    pricePerDay: 35,
    deposit: 200,
    city: "Corinto",
    neighborhood: "Brooklin",
    owner: "Roberto Lima",
    rating: 4.6,
    reviews: 22,
    available: true,
    condition: "Bom",
    description:
      "Use no jardim e devolva. Cortador eletrico com coletor, cabo de 15m e oculos de protecao. Ideal para jardins residenciais.",
    specs: ["1800W", "Coletor incluso", "Cabo 15m", "Corte 32cm"],
    image: "mower"
  },
  {
    id: "itm-06",
    title: "Sony A7 III + lente 24-70mm",
    category: "cameras",
    pricePerDay: 160,
    deposit: 2500,
    city: "Corinto",
    neighborhood: "Jardins",
    owner: "Camila Rocha",
    rating: 4.9,
    reviews: 54,
    available: true,
    condition: "Como novo",
    description:
      "Tenha acesso sem precisar possuir. Camera mirrorless full frame com lente 24-70 f/2.8, dois cartoes SD, tripe compacto e bateria extra.",
    specs: ["Full frame", "24-70mm f/2.8", "2 baterias", "Tripé incluso"],
    image: "camera"
  },
  {
    id: "itm-07",
    title: "Violao Takamine GD11M",
    category: "musica",
    pricePerDay: 40,
    deposit: 300,
    city: "Corinto",
    neighborhood: "Perdizes",
    owner: "Lucas Mendes",
    rating: 4.8,
    reviews: 15,
    available: true,
    condition: "Excelente",
    description:
      "Use pelo ensaio, show ou viagem e devolva. Violao acustico mahogany com capa, palhetas e afinador.",
    specs: ["Mahogany", "Capa rigida", "Afinador", "Cordas novas"],
    image: "guitar"
  },
  {
    id: "itm-08",
    title: "Patinete eletrico Xiaomi Pro 2",
    category: "mobilidade",
    pricePerDay: 55,
    deposit: 700,
    city: "Corinto",
    neighborhood: "Centro",
    owner: "Fernanda Alves",
    rating: 4.7,
    reviews: 39,
    available: true,
    condition: "Muito bom",
    description:
      "Seu deslocamento, seu período. Patinete com autonomia de 45km, velocidade ate 25km/h e trava. Entrego carregado e com capacete.",
    specs: ["45km autonomia", "25km/h", "Capacete", "Trava inclusa"],
    image: "scooter"
  },
  {
    id: "itm-09",
    title: "Serra circular Makita 185mm",
    category: "ferramentas",
    pricePerDay: 32,
    deposit: 180,
    city: "Corinto",
    neighborhood: "Lapa",
    owner: "Marcos Oliveira",
    rating: 4.8,
    reviews: 27,
    available: true,
    condition: "Excelente",
    description:
      "Use na reforma e devolva. Serra circular profissional com disco extra, guia e oculos.",
    specs: ["185mm", "1800W", "Disco extra", "Guia de corte"],
    image: "saw"
  },
  {
    id: "itm-10",
    title: "Caixa de som JBL PartyBox 310",
    category: "festas",
    pricePerDay: 120,
    deposit: 800,
    city: "Corinto",
    neighborhood: "Vila Olimpia",
    owner: "Thiago Nunes",
    rating: 4.9,
    reviews: 88,
    available: true,
    condition: "Como novo",
    description:
      "Encontre. Alugue. Use. Devolva. Caixa potente com luzes, bluetooth, entrada de microfone e bateria de 18h.",
    specs: ["240W RMS", "Bluetooth", "Luzes LED", "18h bateria"],
    image: "speaker"
  },
  {
    id: "itm-11",
    title: "GoPro Hero 12 Black + acessorios",
    category: "cameras",
    pricePerDay: 70,
    deposit: 900,
    city: "Corinto",
    neighborhood: "Pinheiros",
    owner: "Camila Rocha",
    rating: 4.8,
    reviews: 41,
    available: true,
    condition: "Excelente",
    description:
      "Use na trilha ou viagem e devolva. Action cam 5.3K com bastao, chest mount, case a prova d'agua e cartao 128GB.",
    specs: ["5.3K", "A prova d'agua", "Bastao", "Cartao 128GB"],
    image: "gopro"
  },
  {
    id: "itm-12",
    title: "Kayak inflavel 2 pessoas",
    category: "esportes",
    pricePerDay: 85,
    deposit: 450,
    city: "Corinto",
    neighborhood: "Alto de Pinheiros",
    owner: "Pedro Santos",
    rating: 4.6,
    reviews: 12,
    available: true,
    condition: "Muito bom",
    description:
      "Use no fim de semana e devolva. Kayak inflavel para 2 pessoas com remos, coletes e bomba.",
    specs: ["2 pessoas", "2 remos", "Coletes", "Bomba inclusa"],
    image: "kayak"
  }
];
