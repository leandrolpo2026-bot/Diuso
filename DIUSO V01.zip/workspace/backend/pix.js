function emv(id, value) {
  const text = String(value ?? "");
  return `${id}${String(text.length).padStart(2, "0")}${text}`;
}

function crc16(payload) {
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i += 1) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

function sanitize(value, max) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^A-Za-z0-9 .,-/@]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, max);
}

export function pixPayload({ key, name, city, amount, txid }) {
  const merchant = emv("00", "BR.GOV.BCB.PIX") + emv("01", String(key || "").trim());
  const additional = emv("05", sanitize(txid || "***", 25) || "***");
  const amountText = Number(amount || 0).toFixed(2);
  const payload = [
    emv("00", "01"),
    emv("26", merchant),
    emv("52", "0000"),
    emv("53", "986"),
    emv("54", amountText),
    emv("58", "BR"),
    emv("59", sanitize(name || "DIUSO", 25).toUpperCase() || "DIUSO"),
    emv("60", sanitize(city || "SAO PAULO", 15).toUpperCase() || "SAO PAULO"),
    emv("62", additional),
    "6304"
  ].join("");
  return payload + crc16(payload);
}

export function moneyBr(value) {
  return Number(value || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function formatDateBr(iso) {
  if (!iso) return "—";
  const [y, m, d] = String(iso).split("-");
  if (!d) return iso;
  return `${d}/${m}/${y}`;
}

export function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

const DOC_CSS = `
    :root { color-scheme: light; }
    body { font-family: Arial, sans-serif; color: #0b1220; margin: 24px; }
    h1, h2 { margin: 0 0 8px; }
    .muted { color: #5b6578; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin: 18px 0; }
    .card { border: 1px solid #d7dee8; border-radius: 12px; padding: 14px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { text-align: left; padding: 7px 0; border-bottom: 1px solid #e6ebf2; vertical-align: top; }
    th { width: 42%; color: #5b6578; font-weight: 600; }
    .pix { display: flex; gap: 16px; align-items: center; }
    .pix img { width: 180px; height: 180px; border: 1px solid #e6ebf2; border-radius: 8px; }
    .code { font-size: 11px; word-break: break-all; background: #f3f6fb; padding: 8px; border-radius: 8px; }
    .total { font-size: 20px; font-weight: 800; }
    .actions { margin-top: 18px; }
    .brand { letter-spacing: .12em; font-weight: 800; }
    @media print { .actions { display: none; } body { margin: 12px; } }
`;

function row(label, value) {
  return `<tr><th>${escapeHtml(label)}</th><td>${value}</td></tr>`;
}

function partiesHtml(order) {
  return `<div class="grid">
    <div class="card">
      <h2>Locador</h2>
      <table>
        ${row("Nome", escapeHtml(order.owner.name))}
        ${row("E-mail", escapeHtml(order.owner.email || "—"))}
        ${row("Telefone", escapeHtml(order.owner.phone || "—"))}
        ${row("Cidade", escapeHtml(order.owner.city || "—"))}
      </table>
    </div>
    <div class="card">
      <h2>Locatario</h2>
      <table>
        ${row("Nome", escapeHtml(order.renter.name))}
        ${row("CPF", escapeHtml(order.renter.cpf || "—"))}
        ${row("Documento", escapeHtml(order.renter.document || "—"))}
        ${row("E-mail", escapeHtml(order.renter.email || "—"))}
        ${row("Telefone", escapeHtml(order.renter.phone || "—"))}
        ${row("Endereco", escapeHtml(order.renter.address || "—"))}
      </table>
    </div>
  </div>`;
}

function wrapHtml(title, body) {
  return `<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(title)}</title>
  <style>${DOC_CSS}</style>
</head>
<body>
  ${body}
  <div class="actions">
    <button onclick="window.print()">Imprimir / salvar PDF</button>
  </div>
</body>
</html>`;
}

export function serviceOrderHtml(order) {
  return wrapHtml(`Ordem de servico ${order.id}`, `
  <div class="brand">DIUSO</div>
  <h1>Ordem de servico</h1>
  <p class="muted">${escapeHtml(order.id)} · gerada em ${escapeHtml(order.generatedAtLabel)}</p>
  <p>Produto: <strong>${escapeHtml(order.item.title)}</strong> · ${escapeHtml(order.item.period)}</p>
  ${partiesHtml(order)}
  <div class="card">
    <h2>Resumo operacional</h2>
    <table>
      ${row("Aluguel", escapeHtml(order.billing.rentalAmount))}
      ${row("Protecao Diuso", escapeHtml(order.billing.protectionFee))}
      ${row("Entrega", escapeHtml(order.billing.deliveryFee))}
      ${row("Valor da locacao", escapeHtml(order.billing.rentalDue))}
      ${row("Caucao reembolsavel", escapeHtml(order.billing.deposit))}
      ${row("Total inicial", `<span class="total">${escapeHtml(order.billing.initialCharge)}</span>`)}
      ${row("Comissao Diuso", escapeHtml(order.billing.commission))}
      ${row("Repasse ao locador", escapeHtml(order.billing.ownerPayout))}
    </table>
    <p class="muted">Documento interno. A caução não e receita do Diuso.</p>
  </div>`);
}

export function chargeNoteHtml(order) {
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(order.pix.payload)}`;
  return wrapHtml(`Nota de cobranca ${order.id}`, `
  <div class="brand">DIUSO</div>
  <h1>Nota de cobranca</h1>
  <p class="muted">${escapeHtml(order.id)} · gerada em ${escapeHtml(order.generatedAtLabel)}</p>
  <p>Produto: <strong>${escapeHtml(order.item.title)}</strong> · ${escapeHtml(order.item.period)}</p>
  ${partiesHtml(order)}
  <div class="card">
    <h2>Cobranca</h2>
    <table>
      ${row("Aluguel", escapeHtml(order.billing.rentalAmount))}
      ${row("Protecao Diuso", escapeHtml(order.billing.protectionFee))}
      ${row("Entrega", escapeHtml(order.billing.deliveryFee))}
      ${row("Valor da locacao", escapeHtml(order.billing.rentalDue))}
      ${row("Caucao reembolsavel", escapeHtml(order.billing.deposit))}
      ${row("Total a pagar", `<span class="total">${escapeHtml(order.billing.initialCharge)}</span>`)}
    </table>
    <p class="muted">A caução não e receita do Diuso. Ela e retida e devolvida apos a inspecao.</p>
  </div>
  <div class="card" style="margin-top:16px">
    <h2>PIX</h2>
    <div class="pix">
      <img alt="QR Code PIX" src="${qrUrl}" />
      <div>
        <p><strong>Chave:</strong> ${escapeHtml(order.pix.key)}</p>
        <p><strong>Valor:</strong> ${escapeHtml(order.pix.amountLabel)}</p>
        <p class="muted">Copia e cola</p>
        <div class="code">${escapeHtml(order.pix.payload)}</div>
      </div>
    </div>
  </div>`);
}
