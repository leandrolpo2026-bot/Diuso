import { maskIp } from "./geo.js";

const LIMITS = {
  visits: 8000,
  searches: 4000,
  itemViews: 8000,
  events: 6000,
  likes: 20000
};

export function emptyAnalytics() {
  return { visits: [], searches: [], itemViews: [], events: [], likes: [], geoCache: {} };
}

export function ensureAnalytics(db) {
  db.analytics = db.analytics || {};
  ["visits", "searches", "itemViews", "events", "likes"].forEach((key) => {
    if (!Array.isArray(db.analytics[key])) db.analytics[key] = [];
  });
  if (!db.analytics.geoCache || typeof db.analytics.geoCache !== "object" || Array.isArray(db.analytics.geoCache)) {
    db.analytics.geoCache = {};
  }
  return db.analytics;
}

function cap(list, limit) {
  if (list.length > limit) list.splice(0, list.length - limit);
  return list;
}

function id(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(16).slice(2, 8)}`;
}

export function parseUserAgent(userAgent = "") {
  const ua = String(userAgent).toLowerCase();
  const bot = /bot|crawl|spider|slurp|bingpreview|facebookexternalhit|kakaotalk|whatsapp/.test(ua);

  const isTablet = !bot && (/ipad|tablet|playbook|silk/.test(ua) || (/android/.test(ua) && !/mobile/.test(ua)));
  const isMobile = !bot && !isTablet && /mobile|iphone|ipod|android|blackberry|windows phone/.test(ua);
  const device = bot ? "bot" : isTablet ? "tablet" : isMobile ? "mobile" : "desktop";

  let browser = "Outro";
  if (bot) browser = "Bot";
  else if (/edg\//.test(ua)) browser = "Edge";
  else if (/opr\/|opera/.test(ua)) browser = "Opera";
  else if (/chrome|crios|chromium/.test(ua)) browser = "Chrome";
  else if (/firefox|fxios/.test(ua)) browser = "Firefox";
  else if (/safari/.test(ua)) browser = "Safari";
  else if (/curl|wget|python|node-fetch|axios|postman/.test(ua)) browser = "API/Bot";

  let os = "Outro";
  if (/windows/.test(ua)) os = "Windows";
  else if (/android/.test(ua)) os = "Android";
  else if (/iphone|ipad|ipod|ios/.test(ua)) os = "iOS";
  else if (/mac os|macintosh/.test(ua)) os = "macOS";
  else if (/linux/.test(ua)) os = "Linux";

  return { device, browser, os };
}

function sourceOf(referrer, host) {
  const ref = String(referrer || "").trim();
  if (!ref) return "Direto";
  const self = String(host || "").trim();
  try {
    const url = new URL(ref.startsWith("http") ? ref : `https://${ref}`);
    if (self && url.host === self) return "Interno";
    return url.host.replace(/^www\./, "");
  } catch {
    return "Outros";
  }
}

function visitorOf(req, payload) {
  return String(payload?.visitorId || req.headers["x-diuso-visitor"] || "").slice(0, 64);
}

function dayKey(date) {
  const d = new Date(date);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function recordVisit(db, payload = {}, req = { headers: {} }) {
  const analytics = ensureAnalytics(db);
  const { device, browser, os } = parseUserAgent(req.headers["user-agent"]);
  const visit = {
    id: id("vst"),
    at: new Date().toISOString(),
    date: dayKey(new Date()),
    path: String(payload.path || "/").slice(0, 200),
    referrer: sourceOf(payload.referrer, req.headers.host),
    visitorId: visitorOf(req, payload),
    userId: payload.userId || null,
    device,
    browser,
    os,
    screen: String(payload.screen || "").slice(0, 20),
    language: String(payload.language || "").slice(0, 16),
    timezone: String(payload.timezone || "").slice(0, 48),
    ip: String(payload.ip || "").slice(0, 64),
    geo: payload.geo || null
  };
  analytics.visits.push(visit);
  cap(analytics.visits, LIMITS.visits);
  return visit;
}

export function recordSearch(db, { term, category, location, results, params, userId } = {}) {
  const analytics = ensureAnalytics(db);
  const clean = (value, max = 80) => String(value || "").trim().slice(0, max);
  const entry = {
    id: id("sch"),
    at: new Date().toISOString(),
    date: dayKey(new Date()),
    term: clean(term),
    category: clean(category, 40),
    location: clean(location),
    results: Number(results || 0),
    params: clean(params, 160),
    userId: userId || null
  };
  analytics.searches.push(entry);
  cap(analytics.searches, LIMITS.searches);
  return entry;
}

export function recordItemView(db, { itemId, userId, visitorId } = {}) {
  const analytics = ensureAnalytics(db);
  analytics.itemViews.push({
    id: id("viw"),
    at: new Date().toISOString(),
    date: dayKey(new Date()),
    itemId: String(itemId || ""),
    userId: userId || null,
    visitorId: String(visitorId || "").slice(0, 64)
  });
  cap(analytics.itemViews, LIMITS.itemViews);
}

export function recordEvent(db, { type, userId, itemId, meta } = {}) {
  const analytics = ensureAnalytics(db);
  analytics.events.push({
    id: id("evt"),
    at: new Date().toISOString(),
    date: dayKey(new Date()),
    type: String(type || "event"),
    userId: userId || null,
    itemId: itemId || null,
    meta: meta || null
  });
  cap(analytics.events, LIMITS.events);
}

export function recordLike(db, { itemId, visitorId, action = "add" } = {}) {
  const analytics = ensureAnalytics(db);
  const vid = String(visitorId || "").slice(0, 64);
  const target = String(itemId || "");
  if (!target) return;
  const index = analytics.likes.findIndex((l) => l.itemId === target && l.visitorId === vid);
  if (action === "remove") {
    if (index >= 0) analytics.likes.splice(index, 1);
  } else if (index < 0) {
    analytics.likes.push({ itemId: target, visitorId: vid, at: new Date().toISOString() });
  }
  cap(analytics.likes, LIMITS.likes);
}

function tally(list, keyOf) {
  const map = new Map();
  list.forEach((entry) => {
    const key = keyOf(entry);
    if (!key) return;
    map.set(key, (map.get(key) || 0) + 1);
  });
  return [...map.entries()]
    .map(([label, count]) => ({ label, count }))
    .sort((a, b) => b.count - a.count || String(a.label).localeCompare(String(b.label)));
}

function sinceDays(days) {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() - Math.max(0, Number(days) - 1));
  return date;
}

export function buildAnalytics(db, { days = 30 } = {}) {
  const analytics = ensureAnalytics(db);
  const total = Number(days) || 30;
  const start = sinceDays(total);
  const startIso = start.toISOString();
  const today = dayKey(new Date());

  const inRange = (iso) => String(iso || "") >= startIso;
  const visits = analytics.visits.filter((v) => inRange(v.at));
  const searches = analytics.searches.filter((s) => inRange(s.at));
  const itemViews = analytics.itemViews.filter((v) => inRange(v.at));
  const events = analytics.events.filter((e) => inRange(e.at));
  const likes = analytics.likes.filter((l) => inRange(l.at));

  const itemsById = Object.fromEntries((db.items || []).map((i) => [i.id, i]));
  const titleOf = (itemId) => itemsById[itemId]?.title || itemId;
  const categoryOf = (itemId) => itemsById[itemId]?.category || "outros";

  const visitorCount = (list) => new Set(list.map((v) => v.visitorId).filter(Boolean)).size;

  const uniqueVisitors = visitorCount(visits);
  const humanVisits = visits.filter((v) => v.device !== "bot");

  const firstSeen = new Map();
  analytics.visits.forEach((v) => {
    if (!v.visitorId) return;
    const current = firstSeen.get(v.visitorId);
    if (!current || v.at < current) firstSeen.set(v.visitorId, v.at);
  });
  const newVisitors = [...firstSeen.entries()].filter(([, at]) => at >= startIso).length;
  const returningVisitors = Math.max(0, uniqueVisitors - newVisitors);

  const timeline = [];
  for (let i = total - 1; i >= 0; i -= 1) {
    const date = new Date();
    date.setHours(12, 0, 0, 0);
    date.setDate(date.getDate() - i);
    const key = dayKey(date);
    const dayVisits = visits.filter((v) => v.date === key);
    timeline.push({
      date: key,
      label: `${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}`,
      visits: dayVisits.length,
      visitors: new Set(dayVisits.map((v) => v.visitorId).filter(Boolean)).size
    });
  }

  const byHour = Array.from({ length: 24 }, (_, hour) => ({
    hour,
    label: `${String(hour).padStart(2, "0")}h`,
    count: visits.filter((v) => new Date(v.at).getHours() === hour).length
  }));

  const locatedVisits = visits.filter((v) => v.geo);
  const countryNames = {
    BR: "Brasil",
    US: "Estados Unidos",
    AR: "Argentina",
    CL: "Chile",
    CO: "Colombia",
    MX: "Mexico",
    PT: "Portugal",
    ES: "Espanha",
    PY: "Paraguai",
    UY: "Uruguai",
    PE: "Peru",
    BO: "Bolivia"
  };
  const countryAliases = {
    brazil: "Brasil",
    "united states": "Estados Unidos",
    "united states of america": "Estados Unidos"
  };
  const countryLabel = (geo) => {
    const code = String(geo.countryCode || "").toUpperCase();
    const raw = String(geo.country || "").trim();
    if (countryNames[code]) return countryNames[code];
    if (countryAliases[raw.toLowerCase()]) return countryAliases[raw.toLowerCase()];
    if (raw.length === 2 && countryNames[raw.toUpperCase()]) return countryNames[raw.toUpperCase()];
    return raw || code || "";
  };
  const regionLabel = (geo) => [`${geo.region || "Regiao não informada"}`, countryLabel(geo)].filter(Boolean).join(" — ");
  const cityLabel = (geo) => [`${geo.city || "Cidade não informada"}`, geo.region || countryLabel(geo)].filter(Boolean).join(" — ");

  const uniqueBy = (list, keyOf) => {
    const map = new Map();
    list.forEach((entry) => {
      const key = keyOf(entry);
      if (!key) return;
      if (!map.has(key)) map.set(key, new Set());
      map.get(key).add(entry.visitorId || entry.ip || "anon");
    });
    return [...map.entries()]
      .map(([label, set]) => ({ label, count: set.size }))
      .sort((a, b) => b.count - a.count || String(a.label).localeCompare(String(b.label)));
  };

  const bookingDates = (db.bookings || []).map((b) => b.createdAt).filter(Boolean);
  const bookingsInRange = bookingDates.filter(inRange).length;
  const paidInRange = (db.bookings || []).filter(
    (b) => inRange(b.createdAt) && (b.paymentStatus === "pago" || b.status === "finalizado")
  ).length;
  const registeredInRange = (db.users || []).filter((u) => u.email && inRange(u.createdAt)).length;
  const loginsInRange = events.filter((e) => e.type === "login").length;

  const funnel = [
    { id: "visits", label: "Acessos", count: visits.length },
    { id: "visitors", label: "Visitantes unicos", count: uniqueVisitors },
    { id: "views", label: "Anúncios vistos", count: itemViews.length },
    { id: "searches", label: "Buscas", count: searches.length },
    { id: "likes", label: "Itens curtidos", count: likes.length },
    { id: "bookings", label: "Reservas solicitadas", count: bookingsInRange },
    { id: "registrations", label: "Cadastros", count: registeredInRange },
    { id: "paid", label: "Locações pagas", count: paidInRange }
  ];

  return {
    generatedAt: new Date().toISOString(),
    rangeDays: total,
    totals: {
      visitsTotal: analytics.visits.length,
      visits: visits.length,
      uniqueVisitors,
      newVisitors,
      returningVisitors,
      humanVisits: humanVisits.length,
      botVisits: visits.length - humanVisits.length,
      today: visits.filter((v) => v.date === today).length,
      last7: visits.filter((v) => inRange(v.at) && v.at >= new Date(Date.now() - 7 * 86400000).toISOString()).length,
      views: itemViews.length,
      searches: searches.length,
      likes: likes.length,
      registrations: registeredInRange,
      logins: loginsInRange,
      bookings: bookingsInRange,
      paid: paidInRange,
      viewsPerVisitor: uniqueVisitors ? Math.round((visits.length / uniqueVisitors) * 10) / 10 : 0,
      viewToBooking: itemViews.length ? Math.round((bookingsInRange / itemViews.length) * 1000) / 10 : 0,
      visitToBooking: visits.length ? Math.round((bookingsInRange / visits.length) * 1000) / 10 : 0
    },
    timeline,
    byHour,
    devices: tally(visits, (v) => v.device),
    browsers: tally(visits, (v) => v.browser),
    operatingSystems: tally(visits, (v) => v.os),
    sources: tally(visits, (v) => v.referrer),
    pages: tally(visits, (v) => v.path),
    geography: {
      located: locatedVisits.length,
      unknown: visits.length - locatedVisits.length,
      countries: tally(locatedVisits, (v) => countryLabel(v.geo)),
      regions: tally(locatedVisits, (v) => regionLabel(v.geo)),
      cities: tally(locatedVisits, (v) => cityLabel(v.geo)),
      networks: tally(locatedVisits, (v) => v.geo.isp),
      visitorsByCountry: uniqueBy(
        locatedVisits.filter((v) => v.visitorId),
        (v) => countryLabel(v.geo)
      )
    },
    topSearches: tally(searches.filter((s) => s.term), (s) => s.term.toLowerCase()),
    topLocations: tally(searches.filter((s) => s.location), (s) => s.location.toLowerCase()),
    topCategories: tally(
      [...searches.filter((s) => s.category), ...itemViews.map((v) => ({ category: categoryOf(v.itemId) }))],
      (entry) => entry.category
    ),
    topItems: tally(itemViews, (v) => v.itemId).slice(0, 12).map((row) => ({
      itemId: row.label,
      title: titleOf(row.label),
      category: categoryOf(row.label),
      count: row.count
    })),
    topLiked: tally(likes, (l) => l.itemId).slice(0, 12).map((row) => ({
      itemId: row.label,
      title: titleOf(row.label),
      category: categoryOf(row.label),
      count: row.count
    })),
    searchStats: {
      total: searches.length,
      uniqueTerms: new Set(searches.filter((s) => s.term).map((s) => s.term.toLowerCase())).size,
      zeroResults: searches.filter((s) => !s.results).length,
      avgResults: searches.length
        ? Math.round((searches.reduce((sum, s) => sum + Number(s.results || 0), 0) / searches.length) * 10) / 10
        : 0
    },
    funnel,
    events: tally(events, (e) => e.type),
    recent: analytics.visits.slice(-40).reverse().map((v) => ({
      at: v.at,
      path: v.path,
      device: v.device,
      browser: v.browser,
      os: v.os,
      source: v.referrer,
      screen: v.screen,
      language: v.language,
      visitorId: v.visitorId ? v.visitorId.slice(-6) : "",
      location: v.geo ? [v.geo.city, v.geo.region, countryLabel(v.geo)].filter(Boolean).join(", ") : "",
      countryCode: v.geo?.countryCode || "",
      network: v.geo?.isp || "",
      ip: v.ip ? maskIp(v.ip) : ""
    }))
  };
}
