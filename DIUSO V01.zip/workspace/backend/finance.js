import { DEFAULT_ACTIVE_CITIES, mergeActiveCities, mergeCityCatalog, SERVICE_CITIES, normalizeCity } from "./cities.js";

export const DEFAULT_SETTINGS = {
  commissionRate: 0.2,
  protectionRate: 0.05,
  lateFeeMultiplier: 1.5,
  lateToleranceHours: 2,
  depositRules: [
    { maxValue: 100, minRate: 0, maxRate: 0, defaultRate: 0 },
    { maxValue: 300, minRate: 0.3, maxRate: 0.3, defaultRate: 0.3 },
    { maxValue: 1000, minRate: 0.3, maxRate: 0.5, defaultRate: 0.4 },
    { maxValue: 3000, minRate: 0.5, maxRate: 0.5, defaultRate: 0.5 },
    { maxValue: null, minRate: 0.5, maxRate: 1, defaultRate: 0.75 }
  ],
  cancellation: {
    over48h: 1,
    between24and48h: 0.9,
    under24h: 0.7,
    afterStart: 0
  },
  ownerCancel: {
    first: "advertencia",
    second: "penalidade",
    repeat: "suspensao"
  },
  payoutHoldUntil: "inspecao_aprovada",
  deliveryFee: 25,
  pix: {
    key: "pix@diuso.com",
    name: "DIUSO",
    city: "SAO PAULO"
  },
  renterLevels: {
    bronze: { id: "bronze", label: "Bronze", depositRate: 1, minSpend: 0 },
    prata: { id: "prata", label: "Prata", depositRate: 0.5, minSpend: 1000 },
    ouro: { id: "ouro", label: "Ouro", depositRate: 0, minSpend: 2000 },
    minPaidRentalsToUpgrade: 3
  },
    activeCities: [...DEFAULT_ACTIVE_CITIES],
    extraCities: []
  };

export function moneyRound(value) {
  return Math.round((Number(value) || 0) * 100) / 100;
}

export function mergeSettings(saved) {
  return {
    ...DEFAULT_SETTINGS,
    ...(saved || {}),
    depositRules: Array.isArray(saved?.depositRules) && saved.depositRules.length
      ? saved.depositRules
      : DEFAULT_SETTINGS.depositRules,
    cancellation: { ...DEFAULT_SETTINGS.cancellation, ...(saved?.cancellation || {}) },
    ownerCancel: { ...DEFAULT_SETTINGS.ownerCancel, ...(saved?.ownerCancel || {}) },
    pix: { ...DEFAULT_SETTINGS.pix, ...(saved?.pix || {}) },
    renterLevels: {
      ...DEFAULT_SETTINGS.renterLevels,
      ...(saved?.renterLevels || {}),
      bronze: { ...DEFAULT_SETTINGS.renterLevels.bronze, ...(saved?.renterLevels?.bronze || {}) },
      prata: { ...DEFAULT_SETTINGS.renterLevels.prata, ...(saved?.renterLevels?.prata || {}) },
      ouro: { ...DEFAULT_SETTINGS.renterLevels.ouro, ...(saved?.renterLevels?.ouro || {}) }
    },
    extraCities: mergeCityCatalog(saved?.extraCities).filter(
      (city) => !SERVICE_CITIES.some((name) => normalizeCity(name) === normalizeCity(city))
    ),
    activeCities: mergeActiveCities(saved?.activeCities, saved?.extraCities)
  };
}

export function daysBetween(start, end) {
  if (!start || !end) return 0;
  const a = new Date(`${start}T00:00:00`);
  const b = new Date(`${end}T00:00:00`);
  if (Number.isNaN(a.getTime()) || Number.isNaN(b.getTime())) return 0;
  return Math.round((b - a) / 86400000) + 1;
}

function timeOrDefault(value, fallback = "08:00") {
  const time = String(value || "").trim();
  return /^\d{2}:\d{2}$/.test(time) ? time : fallback;
}

export function hoursUntilStart(startDate, now = new Date(), startTime = "08:00") {
  const start = new Date(`${startDate}T${timeOrDefault(startTime)}:00`);
  if (Number.isNaN(start.getTime())) return 0;
  return (start.getTime() - now.getTime()) / 3600000;
}

function ruleForValue(settings, estimatedValue) {
  const value = Number(estimatedValue) || 0;
  const rules = settings.depositRules || DEFAULT_SETTINGS.depositRules;
  return rules.find((rule) => rule.maxValue == null || value <= Number(rule.maxValue)) || rules[rules.length - 1];
}

export function suggestedDeposit(settings, estimatedValue, ownerSuggestion) {
  const value = Math.max(0, Number(estimatedValue) || 0);
  const rule = ruleForValue(settings, value);
  const defaultAmount = moneyRound(value * Number(rule.defaultRate || 0));
  const minAmount = moneyRound(value * Number(rule.minRate || 0));
  const maxAmount = moneyRound(value * Number(rule.maxRate || 0));
  if (ownerSuggestion == null || ownerSuggestion === "") {
    return { deposit: defaultAmount, minAmount, maxAmount, rule };
  }
  const suggested = Number(ownerSuggestion);
  const deposit = moneyRound(Math.min(maxAmount, Math.max(minAmount, suggested)));
  return { deposit, minAmount, maxAmount, rule, ownerSuggestion: suggested };
}

export function quoteRental(item, days, delivery, settings, extras = {}) {
  const safeDays = Math.max(Number(days) || 0, 0);
  const pricePerDay = Number(item.pricePerDay || 0);
  const weeklyPrice = Number(item.weeklyPrice || 0);
  const monthlyPrice = Number(item.monthlyPrice || 0);
  let dailyTotal = moneyRound(safeDays * pricePerDay);
  let periodLabel = `${safeDays} dia(s)`;
  if (safeDays >= 30 && monthlyPrice > 0) {
    const months = Math.floor(safeDays / 30);
    const rest = safeDays % 30;
    dailyTotal = moneyRound(months * monthlyPrice + rest * pricePerDay);
    periodLabel = months > 0 ? `${months} mes(es)${rest ? ` + ${rest} dia(s)` : ""}` : periodLabel;
  } else if (safeDays >= 7 && weeklyPrice > 0) {
    const weeks = Math.floor(safeDays / 7);
    const rest = safeDays % 7;
    dailyTotal = moneyRound(weeks * weeklyPrice + rest * pricePerDay);
    periodLabel = `${weeks} semana(s)${rest ? ` + ${rest} dia(s)` : ""}`;
  }

  const deliveryFee = Number(settings.deliveryFee ?? 0);
  const rentalAmount = moneyRound(dailyTotal);
  const commissionRate = Number(settings.commissionRate);
  const protectionRate = Number(settings.protectionRate);
  const commission = moneyRound(rentalAmount * commissionRate);
  const ownerPayout = moneyRound(rentalAmount - commission);
  const protectionFee = moneyRound(rentalAmount * protectionRate);
  const estimatedValue = Number(item.estimatedValue || extras.estimatedValue || 0);
  const depositInfo = suggestedDeposit(settings, estimatedValue, extras.depositSuggestion ?? item.depositSuggested ?? item.deposit);
  const renterLevel = extras.renterLevel || "bronze";
  const deposit = applyDepositByLevel(depositInfo.deposit, renterLevel, settings);
  const rentalDue = moneyRound(rentalAmount + deliveryFee + protectionFee);
  const initialCharge = moneyRound(rentalDue + deposit);

  return {
    days: safeDays,
    periodLabel,
    pricePerDay,
    weeklyPrice,
    monthlyPrice,
    dailyTotal: rentalAmount,
    rentalAmount,
    deliveryFee,
    protectionRate,
    protectionFee,
    commissionRate,
    commission,
    ownerPayout,
    estimatedValue,
    deposit,
    depositBase: depositInfo.deposit,
    depositMin: depositInfo.minAmount,
    depositMax: depositInfo.maxAmount,
    depositRate: renterLevelMeta(renterLevel, settings).depositRate,
    renterLevel,
    rentalDue,
    initialCharge,
    total: rentalDue,
    heldDeposit: deposit,
    revenue: moneyRound(commission + protectionFee),
    depositIsNotRevenue: true
  };
}

export function renterLevelMeta(level, settings = DEFAULT_SETTINGS) {
  const levels = settings.renterLevels || DEFAULT_SETTINGS.renterLevels;
  return levels[level] || levels.bronze;
}

export function applyDepositByLevel(baseDeposit, level, settings = DEFAULT_SETTINGS) {
  const rate = Number(renterLevelMeta(level, settings).depositRate ?? 1);
  return moneyRound(Number(baseDeposit || 0) * rate);
}

export function isPaidRental(booking) {
  if (!booking || ["cancelado", "cancelada"].includes(booking.status)) return false;
  if (booking.paymentProof) return true;
  return ["pago", "comprovante_anexado"].includes(booking.paymentStatus);
}

export function renterSpendStats(bookings, userId) {
  const paid = (bookings || []).filter((b) => b.userId === userId && isPaidRental(b));
  const spent = moneyRound(paid.reduce((sum, b) => sum + Number(b.rentalDue || b.total || 0), 0));
  return { paidCount: paid.length, spent };
}

export function renterLevelFromStats({ paidCount, spent }, settings = DEFAULT_SETTINGS) {
  const rules = settings.renterLevels || DEFAULT_SETTINGS.renterLevels;
  const minPaid = Number(rules.minPaidRentalsToUpgrade || 3);
  if (Number(paidCount || 0) < minPaid) return "bronze";
  if (Number(spent || 0) >= Number(rules.ouro?.minSpend || 2000)) return "ouro";
  if (Number(spent || 0) >= Number(rules.prata?.minSpend || 1000)) return "prata";
  return "bronze";
}

export function syncRenterLevel(user, bookings, settings = DEFAULT_SETTINGS) {
  if (!user) return "bronze";
  const stats = renterSpendStats(bookings, user.id);
  const level = renterLevelFromStats(stats, settings);
  user.renterLevel = level;
  user.renterSpent = stats.spent;
  user.renterPaidCount = stats.paidCount;
  return level;
}

export function cancellationPreview(settings, booking, now = new Date()) {
  const hours = hoursUntilStart(booking.startDate, now, booking.startTime);
  const rentalAmount = Number(booking.rentalAmount || booking.dailyTotal || 0);
  let refundRate = settings.cancellation.afterStart;
  let window = "apos_inicio";
  if (hours > 48) {
    refundRate = settings.cancellation.over48h;
    window = "mais_de_48h";
  } else if (hours >= 24) {
    refundRate = settings.cancellation.between24and48h;
    window = "entre_24h_e_48h";
  } else if (hours > 0) {
    refundRate = settings.cancellation.under24h;
    window = "menos_de_24h";
  }
  const rentalRefund = moneyRound(rentalAmount * refundRate);
  const protectionRefund = hours > 0 ? Number(booking.protectionFee || 0) : 0;
  const deliveryRefund = hours > 0 ? Number(booking.deliveryFee || 0) : 0;
  const depositRefund = Number(booking.deposit || 0);
  return {
    window,
    hoursUntilStart: Math.round(hours * 10) / 10,
    refundRate,
    rentalRefund,
    protectionRefund,
    deliveryRefund,
    depositRefund,
    totalRefund: moneyRound(rentalRefund + protectionRefund + deliveryRefund + depositRefund)
  };
}

export function lateFeeForDays(settings, pricePerDay, extraDays) {
  const days = Math.max(0, Number(extraDays) || 0);
  return moneyRound(days * Number(pricePerDay || 0) * Number(settings.lateFeeMultiplier || 1.5));
}

function monthKey(iso) {
  const raw = String(iso || "").slice(0, 7);
  if (/^\d{4}-\d{2}$/.test(raw)) return raw;
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

export function financialDashboard(db, settings = DEFAULT_SETTINGS) {
  const bookings = db.bookings || [];
  const items = db.items || [];
  const incidents = db.incidents || [];
  const active = bookings.filter((b) => !["cancelado", "cancelada"].includes(b.status));
  const paid = active.filter((b) => isPaidRental(b));
  const cancelled = bookings.filter((b) => ["cancelado", "cancelada"].includes(b.status));
  const late = bookings.filter((b) => b.status === "atrasado");
  const finished = bookings.filter((b) => b.status === "finalizado");
  const commissions = moneyRound(paid.reduce((sum, b) => sum + Number(b.commission || 0), 0));
  const protection = moneyRound(paid.reduce((sum, b) => sum + Number(b.protectionFee || 0), 0));
  const lateFees = moneyRound(paid.reduce((sum, b) => sum + Number(b.lateFee || 0), 0));
  const delivery = moneyRound(paid.reduce((sum, b) => sum + Number(b.deliveryFee || 0), 0));
  const rentalVolume = moneyRound(paid.reduce((sum, b) => sum + Number(b.rentalDue || b.total || 0), 0));
  const revenue = moneyRound(commissions + protection + lateFees);
  const heldDeposits = moneyRound(bookings.filter((b) => b.depositStatus === "retido").reduce((sum, b) => sum + Number(b.deposit || 0), 0));
  const payoutsHeld = moneyRound(active.filter((b) => b.payoutStatus === "retido").reduce((sum, b) => sum + Number(b.ownerPayout || 0), 0));
  const payoutsProcessing = moneyRound(active.filter((b) => b.payoutStatus === "em_processamento").reduce((sum, b) => sum + Number(b.ownerPayout || 0), 0));
  const openIncidents = incidents.filter((i) => !["resolvido", "rejeitado"].includes(i.status));
  const months = [];
  const now = new Date();
  for (let i = 5; i >= 0; i -= 1) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push(`${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`);
  }
  const monthly = months.map((month) => {
    const list = paid.filter((b) => monthKey(b.createdAt || b.startDate) === month);
    const monthRevenue = moneyRound(list.reduce((sum, b) => sum + Number(b.commission || 0) + Number(b.protectionFee || 0) + Number(b.lateFee || 0), 0));
    const monthVolume = moneyRound(list.reduce((sum, b) => sum + Number(b.rentalDue || b.total || 0), 0));
    return { month, revenue: monthRevenue, volume: monthVolume, count: list.length };
  });
  const statusMix = ["aguardando_confirmacao", "confirmado", "preparando", "em_entrega", "ativo", "aguardando_devolucao", "atrasado", "reembolsado", "finalizado", "cancelado"].map((status) => ({
    status,
    count: bookings.filter((b) => b.status === status).length
  }));
  return {
    kpis: {
      revenue,
      rentalVolume,
      takeRate: rentalVolume ? moneyRound(revenue / rentalVolume) : 0,
      paidCount: paid.length,
      unpaidCount: active.length - paid.length,
      avgTicket: paid.length ? moneyRound(rentalVolume / paid.length) : 0,
      occupancy: items.length ? moneyRound(bookings.filter((b) => ["ativo", "em_entrega", "aguardando_devolucao"].includes(b.status)).length / items.length) : 0,
      lateRate: bookings.length ? moneyRound(late.length / bookings.length) : 0,
      cancelRate: bookings.length ? moneyRound(cancelled.length / bookings.length) : 0,
      completionRate: bookings.length ? moneyRound(finished.length / bookings.length) : 0,
      heldDeposits,
      payoutsPending: moneyRound(payoutsHeld + payoutsProcessing),
      openIncidents: openIncidents.length,
      depositCoverage: revenue ? moneyRound(heldDeposits / Math.max(revenue, 1)) : 0
    },
    mix: [
      { id: "commission", label: "Comissoes", value: commissions },
      { id: "protection", label: "Protecao", value: protection },
      { id: "late", label: "Atraso", value: lateFees },
      { id: "delivery", label: "Entrega", value: delivery }
    ],
    monthly,
    statusMix,
    settings: {
      commissionRate: settings.commissionRate,
      protectionRate: settings.protectionRate,
      deliveryFee: settings.deliveryFee
    }
  };
}

export function publicSettings(settings) {
  return {
    commissionRate: settings.commissionRate,
    protectionRate: settings.protectionRate,
    lateFeeMultiplier: settings.lateFeeMultiplier,
    lateToleranceHours: settings.lateToleranceHours,
    depositRules: settings.depositRules,
    cancellation: settings.cancellation,
    pix: settings.pix,
    deliveryFee: settings.deliveryFee,
    renterLevels: settings.renterLevels,
    activeCities: mergeActiveCities(settings.activeCities, settings.extraCities)
  };
}
