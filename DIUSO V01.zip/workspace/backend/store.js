import fs from "fs";
import path from "path";
import { hashPassword } from "./auth.js";
import { emptyAnalytics } from "./analytics.js";
import { ownerIdFromName, seedItems } from "./data.js";
import { DEFAULT_SETTINGS, mergeSettings, moneyRound } from "./finance.js";

const dataDir = path.join(process.cwd(), "storage");
const filePath = path.join(dataDir, "db.json");

function estimatedValueOf(item) {
  if (Number(item.estimatedValue) > 0) return Number(item.estimatedValue);
  if (Number(item.deposit) > 0) return moneyRound(Number(item.deposit) / 0.4);
  return moneyRound((item.pricePerDay || 0) * 20);
}

function enrichItem(item) {
  const ownerName = item.owner || "DIUSO";
  const ownerId = item.ownerId || ownerIdFromName(ownerName);
  const estimatedValue = estimatedValueOf(item);
  return {
    quantity: 1,
    unitId: item.unitId || `${item.id}-u1`,
    ownerId,
    ownerType: item.ownerType || (ownerId === "diuso" ? "platform" : "partner"),
    deliveryFee: item.deliveryFee ?? DEFAULT_SETTINGS.deliveryFee,
    maintenanceStatus: item.maintenanceStatus || "ok",
    rentalHistoryCount: item.rentalHistoryCount || item.reviews || 0,
    estimatedValue,
    weeklyPrice: item.weeklyPrice ?? moneyRound((item.pricePerDay || 0) * 6),
    monthlyPrice: item.monthlyPrice ?? moneyRound((item.pricePerDay || 0) * 22),
    usageRules: item.usageRules || "Use o item apenas no período contratado. Devolva no mesmo estado da retirada, com acessorios.",
    pickupOrDelivery: item.pickupOrDelivery || "entrega_plataforma",
    listingStatus: item.listingStatus || (item.available === false ? "pausado" : "ativo"),
    protectionEligible: item.protectionEligible !== false,
    serialNumber: item.serialNumber || "",
    ...item,
    owner: ownerName,
    ownerId,
    quantity: item.quantity || 1,
    unitId: item.unitId || `${item.id}-u1`,
    deliveryFee: item.deliveryFee ?? DEFAULT_SETTINGS.deliveryFee,
    maintenanceStatus: item.maintenanceStatus || "ok",
    estimatedValue,
    weeklyPrice: item.weeklyPrice ?? moneyRound((item.pricePerDay || 0) * 6),
    monthlyPrice: item.monthlyPrice ?? moneyRound((item.pricePerDay || 0) * 22),
    protectionEligible: item.protectionEligible !== false
  };
}

function enrichBooking(booking, items) {
  const item = items.find((i) => i.id === booking.itemId);
  const days = booking.days || 1;
  const dailyTotal = booking.dailyTotal ?? booking.rentalAmount ?? days * (item?.pricePerDay || 0);
  const deliveryFee = booking.deliveryFee ?? (booking.delivery ? Number(item?.deliveryFee || DEFAULT_SETTINGS.deliveryFee || 0) : 0);
  const deposit = booking.deposit ?? item?.deposit ?? 0;
  const protectionFee = booking.protectionFee ?? 0;
  const rentalAmount = booking.rentalAmount ?? dailyTotal;
  const rentalDue = booking.rentalDue ?? moneyRound(rentalAmount + deliveryFee + protectionFee);
  const commissionRate = booking.commissionRate ?? DEFAULT_SETTINGS.commissionRate;
  const commission = booking.commission ?? moneyRound(rentalAmount * commissionRate);
  return {
    renterEmail: booking.renterEmail || "",
    delivery: Boolean(booking.delivery),
    contractAccepted: booking.contractAccepted ?? true,
    paymentStatus: booking.paymentStatus || (booking.status === "aguardando_confirmacao" ? "pendente" : "pago"),
    paymentProvider: booking.paymentProvider || "gateway_pendente",
    deliveryFee,
    deposit,
    depositStatus: booking.depositStatus || (booking.status === "reembolsado" ? "reembolsado" : booking.status === "finalizado" ? "liberado" : "retido"),
    payoutStatus: booking.payoutStatus || (booking.status === "finalizado" ? "em_processamento" : "retido"),
    subtotal: booking.subtotal ?? rentalAmount,
    dailyTotal,
    rentalAmount,
    protectionFee,
    protectionRate: booking.protectionRate ?? DEFAULT_SETTINGS.protectionRate,
    rentalDue,
    initialCharge: booking.initialCharge ?? moneyRound(rentalDue + deposit),
    total: booking.total ?? rentalDue,
    commissionRate,
    commission,
    ownerPayout: booking.ownerPayout ?? moneyRound(rentalAmount - commission),
    lateFee: booking.lateFee || 0,
    lateReason: booking.lateReason || "",
    checkIn: booking.checkIn || null,
    checkOut: booking.checkOut || null,
    contract: booking.contract || null,
    cancellation: booking.cancellation || null,
    ...booking,
    deliveryFee,
    deposit,
    subtotal: booking.subtotal ?? rentalAmount,
    dailyTotal,
    rentalAmount,
    rentalDue,
    total: booking.total ?? rentalDue,
    commission,
    ownerPayout: booking.ownerPayout ?? moneyRound(rentalAmount - commission)
  };
}

function enrichUser(user) {
  return {
    role: user.role || "client",
    reputation: user.reputation || "regular",
    renterLevel: user.renterLevel || "bronze",
    renterSpent: user.renterSpent || 0,
    renterPaidCount: user.renterPaidCount || 0,
    ownerCancelCount: user.ownerCancelCount || 0,
    identityVerified: Boolean(user.documentPhoto),
    paymentVerified: Boolean(user.paymentVerified),
    blocked: Boolean(user.blocked),
    quarantined: Boolean(user.quarantined),
    quarantinedAt: user.quarantinedAt || null,
    quarantineReason: user.quarantineReason || "",
    photoUrl: user.photoUrl || "",
    mustChangePassword: Boolean(user.mustChangePassword),
    ...user
  };
}

function mapLegacyStatus(status) {
  const map = {
    pendente: "aguardando_confirmacao",
    confirmada: "confirmado",
    concluida: "finalizado",
    cancelada: "cancelado"
  };
  return map[status] || status;
}

export const STATUSES = [
  "aguardando_confirmacao",
  "confirmado",
  "preparando",
  "em_entrega",
  "ativo",
  "aguardando_devolucao",
  "atrasado",
  "reembolsado",
  "finalizado",
  "cancelado"
];

function migrate(db) {
  const items = (db.items || []).map(enrichItem);
  const bookings = (db.bookings || []).map((b) =>
    enrichBooking({ ...b, status: mapLegacyStatus(b.status) }, items)
  );
  return {
    favorites: db.favorites || [],
    listingRequests: db.listingRequests || [],
    users: (db.users || [
      { id: "usr-beatriz", name: "Beatriz Souza", phone: "(11) 98888-1122", role: "client" }
    ]).map(enrichUser),
    sessions: db.sessions || [],
    incidents: db.incidents || [],
    reviews: db.reviews || [],
    notifications: db.notifications || [],
    auditLog: db.auditLog || [],
    analytics: db.analytics || emptyAnalytics(),
    passwordResets: db.passwordResets || [],
    settings: mergeSettings(db.settings),
    ...db,
    items,
    bookings,
    listingRequests: db.listingRequests || [],
    sessions: db.sessions || [],
    users: (db.users || []).map(enrichUser),
    incidents: db.incidents || [],
    reviews: db.reviews || [],
    notifications: db.notifications || [],
    auditLog: db.auditLog || [],
    analytics: db.analytics || emptyAnalytics(),
    passwordResets: db.passwordResets || [],
    settings: mergeSettings(db.settings)
  };
}

function staffUser({ id, name, email, password, role }) {
  return {
    id,
    name,
    email,
    phone: "",
    role,
    reputation: "regular",
    renterLevel: "bronze",
    renterSpent: 0,
    renterPaidCount: 0,
    passwordHash: hashPassword(password),
    createdAt: new Date().toISOString()
  };
}

function ensureStaffUsers(db) {
  const users = db.users || [];
  if (!users.some((u) => u.role === "admin")) {
    users.unshift(staffUser({
      id: "usr-admin",
      name: "Administrador DIUSO",
      email: String(process.env.DIUSO_ADMIN_EMAIL || "admin@diuso.com").toLowerCase(),
      password: process.env.DIUSO_ADMIN_PASSWORD || "Diuso@2026",
      role: "admin"
    }));
  }
  if (!users.some((u) => u.role === "master")) {
    users.unshift(staffUser({
      id: "usr-master",
      name: "Administrador Master DIUSO",
      email: String(process.env.DIUSO_MASTER_EMAIL || "master@diuso.com").toLowerCase(),
      password: process.env.DIUSO_MASTER_PASSWORD || "DiusoMaster@2026",
      role: "master"
    }));
  }
  db.users = users;
  return db;
}

function ensure() {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  if (!fs.existsSync(filePath)) {
    const initial = migrate({
      items: seedItems,
      bookings: [
        {
          id: "bkg-01",
          itemId: "itm-10",
          renterName: "Beatriz Souza",
          renterPhone: "(11) 98888-1122",
          renterEmail: "beatriz@email.com",
          startDate: "2026-09-12",
          endDate: "2026-09-14",
          days: 3,
          delivery: true,
          status: "confirmado",
          createdAt: "2026-09-05T14:20:00.000Z",
          note: "Churrasco no domingo",
          contractAccepted: true,
          paymentStatus: "pago"
        }
      ],
      favorites: [],
      users: [{ id: "usr-beatriz", name: "Beatriz Souza", phone: "(11) 98888-1122", role: "client" }],
      settings: DEFAULT_SETTINGS
    });
    fs.writeFileSync(filePath, JSON.stringify(ensureStaffUsers(initial), null, 2));
    return;
  }

  const raw = JSON.parse(fs.readFileSync(filePath, "utf8"));
  const migrated = ensureStaffUsers(migrate(raw));
  fs.writeFileSync(filePath, JSON.stringify(migrated, null, 2));
}

export function readDb() {
  ensure();
  return migrate(JSON.parse(fs.readFileSync(filePath, "utf8")));
}

export function writeDb(db) {
  ensure();
  fs.writeFileSync(filePath, JSON.stringify(migrate(db), null, 2));
}
