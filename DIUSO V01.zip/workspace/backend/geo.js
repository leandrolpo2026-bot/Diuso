const GEO_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const CACHE_LIMIT = 3000;
const LOOKUP_TIMEOUT_MS = 2500;
const MAX_CONCURRENT = 4;
const GEO_API = String(process.env.DIUSO_GEO_API_URL || "http://ip-api.com/json").replace(/\/$/, "");

const inflight = new Map();
let active = 0;

export function normalizeIp(value) {
  let ip = String(value || "").trim();
  if (!ip) return "";
  if (ip.startsWith("::ffff:")) ip = ip.slice(7);
  if (ip === "::1") return "127.0.0.1";
  if (ip.startsWith("[")) {
    const end = ip.indexOf("]");
    if (end > 0) ip = ip.slice(1, end);
  }
  if (/:\d+$/.test(ip) && ip.includes(".")) ip = ip.replace(/:\d+$/, "");
  return ip.slice(0, 64);
}

export function isPrivateIp(ip) {
  const value = normalizeIp(ip);
  if (!value) return true;
  if (value === "127.0.0.1" || value === "localhost") return true;
  if (/^10\./.test(value)) return true;
  if (/^192\.168\./.test(value)) return true;
  if (/^172\.(1[6-9]|2\d|3[01])\./.test(value)) return true;
  if (/^169\.254\./.test(value)) return true;
  if (/^100\.(6[4-9]|[7-9]\d|1[0-1]\d|12[0-7])\./.test(value)) return true;
  if (/^(fc|fd|fe80)/i.test(value)) return true;
  return false;
}

export function maskIp(ip) {
  const value = normalizeIp(ip);
  if (!value) return "";
  if (value.includes(":")) {
    const parts = value.split(":").filter(Boolean);
    return `${parts.slice(0, 2).join(":")}::…`;
  }
  const parts = value.split(".");
  if (parts.length !== 4) return value;
  return `${parts[0]}.${parts[1]}.${parts[2]}.x`;
}

export function requestIp(req) {
  const headers = req.headers || {};
  const forwarded = String(headers["x-forwarded-for"] || "")
    .split(",")
    .map((part) => normalizeIp(part))
    .filter(Boolean);
  const candidates = [
    headers["cf-connecting-ip"],
    headers["true-client-ip"],
    headers["x-real-ip"],
    headers["x-client-ip"],
    ...forwarded,
    req.socket?.remoteAddress
  ];
  for (const candidate of candidates) {
    const ip = normalizeIp(candidate);
    if (ip) return ip;
  }
  return "";
}

export function geoFromHeaders(headers = {}) {
  const country =
    headers["cf-ipcountry"] ||
    headers["x-vercel-ip-country"] ||
    headers["x-geo-country"] ||
    headers["x-country-code"] ||
    "";
  const region =
    headers["x-vercel-ip-country-region"] ||
    headers["x-geo-region"] ||
    headers["x-region"] ||
    "";
  const city = headers["x-vercel-ip-city"] || headers["x-geo-city"] || headers["x-city"] || "";
  const isp = headers["x-isp"] || "";
  let decodedCity = "";
  try {
    decodedCity = city ? decodeURIComponent(String(city)) : "";
  } catch {
    decodedCity = String(city || "");
  }
  if (!country && !region && !decodedCity && !isp) return null;
  return {
    country: country ? String(country).toUpperCase() : "",
    countryCode: country ? String(country).toUpperCase() : "",
    region: String(region || ""),
    city: decodedCity,
    isp: String(isp || ""),
    lat: null,
    lon: null,
    source: "header"
  };
}

export function readCache(db, ip) {
  const cache = db.analytics?.geoCache;
  if (!cache) return null;
  const entry = cache[normalizeIp(ip)];
  if (!entry) return null;
  if (Date.now() - Number(entry.cachedAt || 0) > GEO_TTL_MS) return null;
  return entry.geo || null;
}

export function writeCache(db, ip, geo) {
  if (!db.analytics) return;
  db.analytics.geoCache = db.analytics.geoCache || {};
  db.analytics.geoCache[normalizeIp(ip)] = { geo, cachedAt: Date.now() };
  const keys = Object.keys(db.analytics.geoCache);
  if (keys.length > CACHE_LIMIT) {
    const sorted = keys.sort((a, b) => Number(db.analytics.geoCache[a].cachedAt || 0) - Number(db.analytics.geoCache[b].cachedAt || 0));
    sorted.slice(0, keys.length - CACHE_LIMIT).forEach((key) => delete db.analytics.geoCache[key]);
  }
}

async function fetchGeo(ip) {
  if (active >= MAX_CONCURRENT) return null;
  active += 1;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), LOOKUP_TIMEOUT_MS);
  try {
    const res = await fetch(`${GEO_API}/${encodeURIComponent(ip)}?fields=status,message,country,countryCode,region,regionName,city,isp,lat,lon`, {
      signal: controller.signal
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.status && data.status !== "success") return null;
    return {
      country: data.country || "",
      countryCode: data.countryCode || "",
      region: data.regionName || data.region || "",
      city: data.city || "",
      isp: data.isp || "",
      lat: typeof data.lat === "number" ? data.lat : null,
      lon: typeof data.lon === "number" ? data.lon : null,
      source: "ip"
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
    active -= 1;
  }
}

export async function resolveGeo(ip) {
  const value = normalizeIp(ip);
  if (!value || isPrivateIp(value)) return null;
  if (inflight.has(value)) return inflight.get(value);
  const promise = (async () => {
    const geo = await fetchGeo(value);
    return geo;
  })();
  inflight.set(value, promise);
  try {
    const geo = await promise;
    return geo;
  } finally {
    inflight.delete(value);
  }
}

export function mergeGeo(primary, fallback) {
  if (!primary) return fallback || null;
  if (!fallback) return primary;
  const pick = (key) => {
    const a = primary[key];
    const b = fallback[key];
    if (a !== undefined && a !== null && a !== "") return a;
    return b === undefined ? null : b;
  };
  return {
    country: pick("country"),
    countryCode: pick("countryCode"),
    region: pick("region"),
    city: pick("city"),
    isp: pick("isp"),
    lat: pick("lat"),
    lon: pick("lon"),
    source: primary.source === "header" && fallback.source === "ip" ? "header+ip" : primary.source || fallback.source
  };
}

export function locationLabel(geo) {
  if (!geo) return "";
  const parts = [geo.city, geo.region, geo.country].filter(Boolean);
  return parts.join(", ");
}

export function resetInflightForTests() {
  inflight.clear();
  active = 0;
}
